# Network Monitoring Architecture Analysis - NetworkStatus Unknown Issue

## Executive Summary
**CRITICAL FINDING**: NetworkStatus remains "Unknown" due to architectural race conditions and initialization timing issues in `src/core/segments/network/segment.rs:46-58`.

## Root Cause Analysis

### Primary Issue: Initialization Race Condition
**Location**: `NetworkSegment::new_sync()` in `src/core/segments/network/segment.rs:46-58`
- **Problem**: 100ms timeout for background initialization is insufficient
- **Impact**: Status remains Unknown if credential retrieval or MonitoringEngine setup takes >100ms
- **Frequency**: High - affects most initialization attempts

### Secondary Issues
1. **Feature Flag Dependency**: `#[cfg(feature = "network-monitoring")]` can silently disable functionality
2. **Credential Chain Complexity**: Multi-source credential lookup (env vars → shell configs → Claude configs)
3. **Background Task Opacity**: No visibility into monitoring thread health

## Architecture Components

### Core Types (`src/core/segments/network/types.rs`)
```rust
pub enum NetworkStatus {
    Healthy,
    Degraded { reason: String, details: String },
    Error { error_type: String, details: String },
    Unknown,    // Default state - THE PROBLEM
    Disabled,
}

impl Default for NetworkStatus {
    fn default() -> Self { Self::Unknown }  // This is why it stays Unknown
}
```

### Status Update Flow
1. **Default**: NetworkStatus::Unknown (types.rs:93)
2. **Initialization**: 100ms window for status update  
3. **Credential Check**: Disabled if credentials missing
4. **Health Check Loop**: Anthropic API monitoring → status updates
5. **Display**: Non-blocking read via `collect()` method

## Immediate Fixes Required

### Fix 1: Increase Timeout (Critical)
```rust
// In NetworkSegment::new_sync() - line ~58
if let Ok(_) = init_rx.recv_timeout(std::time::Duration::from_millis(500)) {
    // Changed from 100ms to 500ms
}
```

### Fix 2: Add Status Visibility
```rust
// Add to impl NetworkSegment
pub fn get_initialization_status(&self) -> InitializationStatus {
    // Return details about why status is Unknown
}
```

### Fix 3: Graceful Credential Handling
```rust
// Better error reporting when credentials missing
NetworkStatus::Error {
    error_type: "NO_CREDENTIALS".to_string(),
    details: "Configure ANTHROPIC_BASE_URL and ANTHROPIC_AUTH_TOKEN".to_string(),
}
```

## Credential Sources (Priority Order)
1. **Environment**: `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`
2. **Shell Configs**: `.zshrc`, `.bashrc`, PowerShell profiles  
3. **Claude Configs**: `.claude/settings.json`, `.claude/settings.local.json`

## Monitoring Architecture
- **NetworkSegment**: Main interface with `Arc<RwLock<NetworkStatus>>`
- **MonitoringEngine**: Background health checker
- **HttpMonitor**: Anthropic API communication
- **CredentialManager**: Multi-source auth handling
- **StateMachine**: Interval and retry logic

## Testing Insights
Found test cases in `segment.rs` showing expected behavior:
- `test_disabled_segment_creation()` - shows Disabled status works
- `test_disabled_segment_collect()` - shows proper status handling
- Missing tests for Unknown status persistence scenarios

## Recommendations Priority
1. **High**: Fix initialization timeout race condition
2. **High**: Add status transition logging for debugging
3. **Medium**: Implement initialization health checks
4. **Medium**: Add configuration validation pre-flight
5. **Low**: Consider making network monitoring non-optional

## Related Files for Future Work
- `src/core/segments/network/segment.rs` - Main logic
- `src/core/segments/network/types.rs` - Status definitions  
- `src/core/segments/network/credential_manager.rs` - Auth handling
- `src/core/segments/network/http_monitor.rs` - API monitoring
- `src/core/segments/mod.rs` - Feature flag integration

Date: 2025-08-19
Branch: feature/network-monitoring