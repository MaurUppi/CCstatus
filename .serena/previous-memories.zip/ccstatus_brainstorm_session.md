# CCstatus Development Brainstorm Session - Updated Architecture

## Project Overview
**CCstatus** is a fork of CCometixLine transformed into a Claude Code Network Monitor and StatusLine tool. The project provides real-time monitoring of Claude API connectivity with visual status indicators in terminal prompts.

## Key Architectural Decisions - Updated

### 1. Universal Monitoring Method
**DECISION: Lightweight POST Method for All Endpoints**
- **Method**: POST {base_url}/v1/messages with minimal payload
- **Payload**: `{"model":"claude-3-haiku-20240307","max_tokens":1,"messages":[{"role":"user","content":"ping"}]}`
- **Why**: Works for both official Anthropic API and proxy services (e.g., https://as.ctok.ai/api/)
- **Benefits**: Real error detection (401, 403, 429, 500, 502, 504), validates full auth pipeline
- **Rejected**: HEAD/OPTIONS requests (not supported by proxies, miss auth validation)

### 2. Adaptive Frequency Algorithm
```rust
enum MonitoringState {
    Healthy,     // 30s initially → 5min after 10 consecutive successes
    Degraded,    // 5s when errors detected (quick recovery detection)  
    Failed,      // 1min after 10 consecutive failures (respectful backoff)
}

// State transitions:
// Healthy --[error]--> Degraded --[10 errors]--> Failed
// Degraded --[success]--> Healthy  
// Failed --[success]--> Degraded --[10 successes]--> Healthy
```

**Benefits**: Responsive when errors occur, efficient when stable, respectful when services are down.

### 3. Smart Visual Display Mode
**DECISION: Context-Sensitive Detail Level**

**Healthy State** (200 OK, <500ms):
```bash
🟢  # Simple green light, no clutter
```

**Error States** (any problem):
```bash
🔴 DNS:timeout|TCP:-|TLS:-|TTFB:-|Total:5000ms
🟡 DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms  # Slow
🔴 DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms [401 Unauthorized]
```

**Benefits**: Clean when working, diagnostic when broken, actionable information.

### 4. Enhanced Latency Breakdown
**Format**: `DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms`

**Key Points**:
- Show **"reuse"** for connection pooling (not "0ms") 
- Show **"timeout"** for failed phases
- **Total** = actual measured end-to-end time (NOT sum of parts)
- **Separator**: Use `|` (pipe) for compact display

**Examples**:
- Fresh connection: `DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms`
- Reused connection: `DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms`
- DNS failure: `DNS:timeout|TCP:-|TLS:-|TTFB:-|Total:5000ms`

### 5. Secure Credential Management
**DECISION: Read-Only, Never Store Sensitive Data**

**Priority Order**:
1. **Environment Variables** (in memory):
   - `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`

2. **Claude Code Config Files**:
   - `~/.claude/settings.json` (user settings)
   - `.claude/settings.local.json` (project personal)
   - `.claude/settings.json` (project shared)

**Platform-Specific Env File Locations**:
- **macOS/Linux/WSL**: `~/.zshrc`, `~/.bash_profile`, `~/.bashrc`
- **Windows PowerShell**: `$PROFILE` (`%USERPROFILE%\Documents\PowerShell\Microsoft.PowerShell_profile.ps1`)
- **Windows CMD**: System Environment Variables (Registry)

**Security**: CCstatus NEVER stores credentials, only reads from user's existing configuration.

### 6. Simplified Status File Format
```json
{
  "status": "healthy|degraded|error|disabled",
  "monitoring_enabled": true,
  "api_config": {
    "endpoint": "https://as.ctok.ai/api/v1/messages",
    "source": "ANTHROPIC_BASE_URL"
  },
  "network": {
    "latency_ms": 156,
    "breakdown": "DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms",
    "last_error_code": null,
    "error_type": null
  },
  "monitoring_state": {
    "current": "healthy",
    "interval_seconds": 30,
    "consecutive_successes": 3,
    "consecutive_failures": 0
  },
  "timestamp": "2025-08-19T14:30:00Z"
}
```

### 7. Visual Status Indicators - Updated
- **🟢 Healthy**: 200 OK, latency < 500ms
- **🟡 Degraded**: 429 rate limit OR latency > 500ms  
- **🔴 Error**: 4xx/5xx errors OR connection failures
- **⚪ Unknown**: No configuration found
- **⚫ Disabled**: Monitoring explicitly disabled

### 8. Error Categorization
```rust
enum ErrorType {
    Authentication,  // 401, 403 - API key issues
    RateLimit,      // 429 - Too many requests  
    ServerError,    // 500, 502, 504 - Backend issues
    Network,        // Connection failures, timeouts
}
```

### 9. Project Structure - Updated
```
~/.claude/ccstatus/
├── ccstatus-monitoring.json     # Main status file (no credentials)
├── cache/                       # Session monitoring cache
└── logs/                        # Debug logs (optional)
```

**Note**: No config.toml with credentials - security by design.

### 10. Implementation Dependencies
```toml
# Network monitoring
isahc = { version = "1.7", features = ["json"] }
notify = "6.0"  
tokio = { version = "1.0", features = ["full"] }

# Latency breakdown
isahc = { version = "1.7", features = ["timing"] }

# Existing dependencies
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
clap = { version = "4.0", features = ["derive"] }
```

## Implementation Roadmap - Updated

### Phase 1: Core Monitoring (Week 1)
- [x] Project rename complete
- [ ] Implement lightweight POST method for health checks
- [ ] Add adaptive frequency algorithm
- [ ] Create secure credential reading system
- [ ] Basic status file with simplified format

### Phase 2: Enhanced Metrics (Week 2)  
- [ ] Implement multi-phase latency breakdown
- [ ] Add connection reuse detection ("reuse" vs timing)
- [ ] Smart visual display mode (green light vs detailed breakdown)
- [ ] Error categorization and handling

### Phase 3: Cross-Platform Integration (Week 3)
- [ ] Shell integration with context-aware display
- [ ] Windows PowerShell profile support
- [ ] macOS/Linux shell integration  
- [ ] Testing across all platforms

### Phase 4: Production Ready (Week 4)
- [ ] Performance optimization and resource usage
- [ ] Comprehensive error handling
- [ ] Documentation and examples
- [ ] Claude session file monitoring integration

## Validation Results

**Real-World Confirmation**: Studied production implementations (ruvnet/claude-flow) - confirmed lightweight POST is the standard approach for Claude API health checks.

**Proxy Compatibility**: Confirmed approach works with both official Anthropic API and proxy services like `https://as.ctok.ai/api/`.

**Security**: Follows Claude Code's official credential management patterns from documentation.

## Key Benefits - Refined
- **Universal**: One implementation works with any Claude-compatible endpoint
- **Intelligent**: Adaptive monitoring reduces load when stable, increases when needed
- **Secure**: Never stores credentials, reads from user's existing configuration  
- **User-Friendly**: Clean display when working, detailed diagnostics when broken
- **Actionable**: Clear breakdown shows exactly where issues occur
- **Respectful**: Backs off appropriately when services are down
- **Efficient**: Connection pooling reduces overhead, minimal API costs

## Success Metrics
- **Performance**: <50ms status check, <10MB memory usage
- **Reliability**: >99% uptime for background monitoring  
- **Compatibility**: Works across macOS, Linux, Windows with all shell types
- **Security**: Zero credential exposure, follows platform security best practices
- **User Experience**: Immediate error visibility, minimal false positives
- **Value**: Quick identification of connectivity issues with actionable diagnostics

This updated architecture provides a production-ready, secure, and user-friendly Claude Code network monitoring solution.