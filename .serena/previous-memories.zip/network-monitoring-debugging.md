# Network Monitoring Feature - Debugging Guide

## Common Issues and Solutions

### 1. Network Status Shows as "Disabled"

**Symptom**: Status file shows `"status": "disabled"` and no network indicator appears in statusline.

**Root Cause**: Credentials not being detected properly.

**Solutions**:
- Ensure environment variables are **exported** (not just set) in shell config
- Check credential priority: Environment vars → Claude config → fail-silent
- Verify variables are available: `echo $ANTHROPIC_BASE_URL $ANTHROPIC_AUTH_TOKEN`

### 2. Credential Configuration

**Environment Variables (Recommended)**:
```bash
# Option 1: Base URL + Auth Token
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN="your-api-key"

# Option 2: Standard API Key
export ANTHROPIC_API_KEY="your-api-key"
```

**Claude Config File** (`~/.claude/settings.json`):
```json
{
  "api_base_url": "https://api.anthropic.com",
  "api_key": "your-api-key"
}
```

### 3. Build Commands

```bash
# Build with network monitoring
cargo build --features network-monitoring --release

# Run tests
cargo test --features network-monitoring

# Install
cp target/release/ccstatus ~/.claude/ccstatus/
chmod +x ~/.claude/ccstatus/ccstatus
```

### 4. Testing Network Monitoring

```bash
# Test with explicit credentials
ANTHROPIC_API_KEY="your-key" ~/.claude/ccstatus/ccstatus

# Check status file
cat ~/.claude/ccstatus/ccstatus-monitoring.json

# Watch real-time updates
watch -n 1 'cat ~/.claude/ccstatus/ccstatus-monitoring.json'
```

### 5. Status File Location

`~/.claude/ccstatus/ccstatus-monitoring.json`

**Healthy Status**:
```json
{
  "status": "healthy",
  "last_updated": "2025-01-19T...",
  "details": "89ms",
  "credential_source": "environment"
}
```

### 6. Architecture Notes

- **Sync Initialization**: NetworkSegment::new_sync() creates a separate thread with its own tokio runtime
- **Fail-Silent Design**: Missing credentials don't break statusline, just disable monitoring
- **Adaptive Frequency**: 
  - Healthy: 30s → 5min after 10 successes
  - Degraded: 5s for quick recovery
  - Failed: 60s to avoid overwhelming

### 7. Key Files

- `src/core/segments/network/segment.rs` - Main segment implementation
- `src/core/segments/network/credential_manager.rs` - Credential resolution
- `src/core/segments/network/http_monitor.rs` - API health checks
- `src/core/segments/network/status_file_writer.rs` - Status persistence
- `src/core/statusline.rs` - Integration point
- `src/ui/themes/presets.rs` - Default configuration

### 8. Feature Flag

All network monitoring code is behind `#[cfg(feature = "network-monitoring")]` flag.

### 9. Dependencies

- `isahc` - HTTP client
- `tokio` - Async runtime
- `thiserror` - Error handling

### 10. Troubleshooting Checklist

1. ✓ Built with `--features network-monitoring`?
2. ✓ Credentials exported in environment?
3. ✓ Status file being created?
4. ✓ Network segment in default config?
5. ✓ Claude Code restarted after config change?
6. ✓ Using correct binary in Claude Code settings?