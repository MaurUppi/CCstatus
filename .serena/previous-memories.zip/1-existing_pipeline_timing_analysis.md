# Existing Pipeline Analysis: Does NOT Work With Timing

## Core Finding
**The existing ccstatus network monitoring pipeline will NOT work even if you wait and send stdin with timing data (`total_duration_ms`).**

## Root Causes

### 1. No Timing Field in Input Structure
```rust
// InputData struct in src/config/types.rs
pub struct InputData {
    pub model: Model,
    pub workspace: Workspace, 
    pub transcript_path: String,
    // NO total_duration_ms field exists
}
```

### 2. Completely Synchronous Architecture
- `main()` function is NOT `async` (no `tokio::main`)
- No background threads or monitoring loops
- Executes once per stdin input and exits immediately
- No persistent monitoring between runs

### 3. NetworkSegment is Purely Passive
```rust
// src/core/segments/network/segment.rs
fn collect(&self, _input: &InputData) -> Option<SegmentData> {
    // PROBLEM: Only returns cached/default data
    // NEVER calls:
    // - credential_manager.get_credentials() 
    // - http_monitor.probe()
    // - Any actual monitoring operations
}
```

### 4. No Trigger Mechanisms
- No code checks for timing conditions
- No window-based logic (GREEN/RED scheduling)  
- No event-based triggers
- No time-based probe scheduling

## Execution Flow Analysis
```
ccstatus cold start → wait 5 minutes → send stdin
    ↓
main() reads InputData (no timing field)
    ↓
collect_all_segments() creates NetworkSegment::new_sync()
    ↓
NetworkSegment.collect() returns cached/empty state
    ↓
Program exits (no background tasks)
```

## What Would Be Required
1. **Async Runtime**: tokio::main or runtime creation
2. **Background Service**: Persistent monitoring daemon
3. **Input Schema**: Add timing fields to InputData
4. **Trigger Logic**: Code to activate monitoring based on conditions
5. **State Persistence**: Load/save between program runs

## Implications
- Files (`ccstatus-debug.log`, `ccstatus-monitoring.json`) will NEVER be created
- Network segment shows placeholder status only
- All monitoring infrastructure exists but is dormant
- Even adding timing data to stdin won't help without architectural changes

## Alternative: Proactive Initialization
The only viable solution is to add proactive initialization during segment creation that:
1. Detects first-time execution
2. Spawns background async tasks
3. Performs GREEN probe to establish baseline
4. Creates monitoring files automatically

Date: 2025-08-24
Context: ccstatus network monitoring architecture analysis