# CCometixLine Task Completion Checklist

## Before Committing Changes

### 1. Code Quality Checks
```bash
# Format code according to project standards
cargo fmt

# Run linting checks
cargo clippy

# Fix any warnings or errors reported by clippy
```

### 2. Testing
```bash
# Run all unit tests
cargo test

# Verify tests pass without errors
# Add new tests for any new functionality
```

### 3. Build Verification
```bash
# Ensure development build works
cargo build

# Ensure release build works and check binary size
cargo build --release
ls -lh target/release/ccometixline  # Should be ~2MB
```

### 4. Functional Testing
```bash
# Test basic functionality with mock data
echo '{"model":{"display_name":"claude-3-5-sonnet"},"workspace":{"current_dir":"'$(pwd)'"},"session":{"id":"test123"}}' | ./target/debug/ccometixline

# Test CLI arguments
./target/debug/ccometixline --help
./target/debug/ccometixline --print
```

### 5. Integration Testing (if applicable)
```bash
# Test statusline.sh integration if changes affect JSON parsing
echo '{"model":{"display_name":"test"},"workspace":{"current_dir":"'$(pwd)'"}}' | ./statusline.sh

# Test with different model types and directory structures
```

## Documentation Updates

### 1. Update README.md
- Update version numbers if releasing
- Update feature descriptions if functionality changed
- Update installation instructions if build process changed

### 2. Update CHANGELOG.md
- Add entry for new version following Keep a Changelog format
- Categorize changes as Added, Changed, Deprecated, Removed, Fixed, Security
- Include technical details and any breaking changes

### 3. Code Documentation
- Add or update doc comments for new public APIs
- Ensure all public functions have appropriate documentation
- Update module-level documentation if structure changed

## Version Management

### 1. Version Bump (for releases)
```bash
# Update version in Cargo.toml
# Version should follow semantic versioning (MAJOR.MINOR.PATCH)
```

### 2. Dependency Updates
```bash
# Check for dependency updates
cargo outdated  # (if installed)

# Update dependencies if needed
cargo update
```

## Performance Verification

### 1. Performance Benchmarks
```bash
# Check startup time (should be <50ms)
time ./target/release/ccometixline --help

# Check binary size (should be ~2MB)
ls -lh target/release/ccometixline

# Check memory usage during operation
# Monitor RSS memory usage during typical operations
```

### 2. Cross-Platform Testing (if applicable)
- Test on different operating systems (Linux, macOS, Windows)
- Verify cross-compilation targets still work
- Test NPM package installation flow

## Security Checks

### 1. Dependency Audit
```bash
# Run security audit on dependencies
cargo audit  # (if cargo-audit is installed)
```

### 2. Code Review
- Review any new dependencies added
- Ensure no sensitive information is logged
- Verify input validation for JSON parsing

## Git and Release Process

### 1. Git Commit
```bash
# Stage changes
git add .

# Commit with descriptive message
git commit -m "feat: Add new segment feature"  # or "fix:", "docs:", etc.

# Push to repository
git push
```

### 2. Release Preparation (for version releases)
- Tag release with version number
- Ensure GitHub Actions CI/CD passes
- Verify binary artifacts are generated correctly
- Update NPM package if distributing via npm

## Final Checklist
- [ ] Code formatted with `cargo fmt`
- [ ] No clippy warnings with `cargo clippy`
- [ ] All tests pass with `cargo test`
- [ ] Development build works with `cargo build`
- [ ] Release build works with `cargo build --release`
- [ ] Functional testing completed
- [ ] Documentation updated (README, CHANGELOG, code docs)
- [ ] Performance requirements met (<50ms startup, ~2MB binary, <10MB memory)
- [ ] Security audit passed (if applicable)
- [ ] Git commit made with descriptive message