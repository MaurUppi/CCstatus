# Credential Priority System - Implementation and Fixes

## Session Summary
Completed major refactoring of the network monitoring credential system, implementing shell config file reading and removing deprecated ANTHROPIC_API_KEY support.

## Key Changes Implemented

### 1. Shell Configuration File Reader (`shell_config_reader.rs`)
- **New Module**: Created comprehensive shell config reader with auto-detection
- **Cross-platform Support**: 
  - macOS/Linux: `.zshrc`, `.bashrc`, `.bash_profile`, `.profile`
  - Windows: PowerShell profiles
- **Regex Parsing**: Extracts `export VAR="value"` and PowerShell syntax
- **Integration**: Added to credential manager as priority level 2

### 2. Updated Credential Priority Order
**Before**: Environment → Claude config → None (fail silent)
**After**: 
1. **System-wide Environment** (in-memory): `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`
2. **Shell config files**: Parsed from shell configuration files
3. **Claude config files**: `~/.claude/settings.json` 
4. **None** (fail silent)

### 3. ANTHROPIC_API_KEY Removal
- **Credential Manager**: Removed API key fallback logic entirely
- **Shell Config Reader**: Removed API key parsing from all parsers
- **Tests**: Removed `test_api_key_fallback()` and updated all related tests
- **Documentation**: Updated all comments and docs to reflect new requirements

### 4. Architecture Improvements
- **Source Tracking**: Added `CredentialSource::ShellConfig(PathBuf)` variant
- **Status Reporting**: Shows credential source in status file:
  - `"source": "environment"` - from process memory
  - `"source": "shell:/Users/you/.zshrc"` - from shell config  
  - `"source": "config:/Users/you/.claude/settings.json"` - from Claude config
- **Error Handling**: Added `NetworkError::RegexError` for pattern parsing

## Critical Design Decisions

### 1. Strict Credential Requirements  
- **Both Required**: Must have `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN` together
- **No Fallbacks**: No standalone API key support - enforces complete configuration
- **Fail Silent**: Missing credentials disable monitoring rather than error

### 2. Shell Config Reading Strategy
- **Auto-detection**: Detects shell type from `$SHELL` environment variable
- **Platform Defaults**: macOS→zsh, Linux→bash, Windows→PowerShell
- **Multiple Locations**: Checks multiple config files per shell type
- **Comment Awareness**: Skips commented lines during parsing

### 3. Security Considerations
- **Read-only Operations**: Never modifies shell config files
- **Environment Isolation**: Doesn't affect process environment
- **Fail-safe Design**: Parse errors don't crash the application

## Implementation Files Modified
- `src/core/segments/network/shell_config_reader.rs` (NEW)
- `src/core/segments/network/credential_manager.rs`
- `src/core/segments/network/types.rs`
- `src/core/segments/network/status_file_writer.rs`
- `src/core/segments/network/mod.rs`
- `Cargo.toml` (added regex dependency)

## Testing Status
- **Build**: ✅ Successful with network-monitoring feature
- **Unit Tests**: ✅ All credential manager tests pass (5/5)
- **Shell Tests**: ✅ All shell config reader tests pass (5/5)
- **Integration**: ✅ No breaking changes to existing functionality

## Usage Instructions
Users must now configure credentials with both variables:

### Shell Configuration (Preferred)
```bash
# zsh/bash
export ANTHROPIC_BASE_URL="https://x.y.z/api"
export ANTHROPIC_AUTH_TOKEN="your-api-key"

# PowerShell
$env:ANTHROPIC_BASE_URL = "https://x.y.z/api"
$env:ANTHROPIC_AUTH_TOKEN = "your-api-key"
```

### Claude Config (Fallback)
```json
{
  "api_base_url": "https://x.y.z/api", 
  "api_key": "your-api-key"
}
```

## Build Commands
```bash
cargo build --features network-monitoring --release
cp target/release/ccstatus ~/.claude/ccstatus/
chmod +x ~/.claude/ccstatus/ccstatus
```

## Future Considerations
- Monitor user feedback on new credential requirements
- Consider adding validation warnings for incomplete credentials
- Potential enhancement: credential validation before monitoring starts
- Documentation updates needed for user-facing guides