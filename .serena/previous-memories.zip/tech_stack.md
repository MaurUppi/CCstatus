# CCstatus - Technology Stack

## Core Language & Runtime

**Rust 2021 Edition**
- High-performance systems programming language
- Memory safety without garbage collection
- Excellent concurrency primitives with async/await
- Cross-platform compilation support

## Architecture & Paradigms

- **Modular Design**: Component-based architecture with segment system
- **Async Programming**: Tokio runtime for non-blocking I/O operations
- **Error Handling**: Comprehensive error types with `thiserror` crate
- **Feature-based Compilation**: Optional functionality via Cargo features

## Core Dependencies

### Configuration & Serialization
- **`serde`** (1.0): Serialization/deserialization framework
- **`serde_json`**: JSON handling for Claude Code data and config files
- **`toml`** (0.9.5): TOML configuration file parsing
- **`clap`** (4.0): Command-line argument parsing with derive macros

### Async Runtime (Network Monitoring Feature)
- **`tokio`** (1.47.1): Async runtime with features:
  - `rt`: Basic runtime
  - `rt-multi-thread`: Multi-threaded runtime
  - `time`: Timer and timeout support
  - `sync`: Synchronization primitives
  - `fs`: Async file system operations
  - `macros`: Procedural macros for async functions

### HTTP Client & Network Operations
- **`isahc`** (1.7): HTTP client with JSON support for API monitoring
- **`regex`** (1.10): Regular expressions for shell config parsing

### Error Handling
- **`thiserror`** (2.0.15): Derive macros for error types

## Optional Features & Dependencies

### TUI (Terminal User Interface)
- **`ratatui`** (0.29): Terminal UI library for configuration interface
- **`crossterm`** (0.29.0): Cross-platform terminal manipulation
- **`ansi_term`** (0.12): ANSI color and style formatting
- **`ansi-to-tui`** (7.0): ANSI to TUI color conversion

### Self-Update Capability
- **`ureq`** (3.1.0): Lightweight HTTP client with JSON support
- **`semver`** (1.0): Semantic version parsing and comparison
- **`chrono`** (0.4): Date and time handling
- **`dirs`** (6.0.0): Standard directory path resolution

## Development Dependencies

### Testing
- **`tempfile`** (3.0): Temporary file and directory creation for tests

## Build Features

### Default Features
```toml
default = ["tui", "self-update", "network-monitoring"]
```

### Feature Definitions
- **`tui`**: Terminal user interface for configuration
- **`self-update`**: Automatic update checking and installation
- **`network-monitoring`**: Real-time API connectivity monitoring

## Platform Support

### Target Platforms
- **Linux**: x86_64 (dynamic and static binaries)
- **macOS**: Intel (x86_64) and Apple Silicon (ARM64)
- **Windows**: x86_64

### Platform-Specific Considerations
- **Linux**: Supports both glibc (dynamic) and musl (static) linking
- **macOS**: Separate binaries for Intel and Apple Silicon architectures
- **Windows**: Native Windows executable with PowerShell integration

## Build System

### Cargo Configuration
- **Edition**: 2021 (latest stable Rust edition)
- **Categories**: command-line-utilities, development-tools, network-programming
- **License**: MIT

### Cross-Compilation Support
- GitHub Actions CI/CD pipeline builds for all target platforms
- Release automation with binary distribution
- NPM packaging for cross-platform installation

## External Integrations

### Claude Code Integration
- JSON-based data exchange via stdin
- Configuration file parsing (`settings.json`)
- Statusline output formatting

### Git Integration
- Native git command execution
- Working tree status parsing
- Branch tracking information

### Shell Integration
- Status file output for shell prompt integration
- Cross-platform shell configuration parsing (Bash, Zsh, PowerShell)
- Environment variable credential resolution

## Performance Characteristics

### Benchmarks (vs TypeScript alternatives)
- **Startup Time**: < 50ms (vs ~200ms for TypeScript)
- **Memory Usage**: < 10MB (vs ~25MB for Node.js tools)
- **Binary Size**: ~2MB optimized release build
- **Cold Cache Performance**: Sub-100ms for full status generation

### Optimization Strategies
- **Lazy Loading**: Components loaded only when needed
- **Efficient Serialization**: Minimal JSON parsing overhead
- **Async I/O**: Non-blocking file and network operations
- **Feature Gating**: Optional functionality to reduce binary size

## Security Considerations

- **Credential Handling**: Secure credential resolution with priority hierarchy
- **Fail-Silent**: Graceful error handling without exposing sensitive information
- **Input Validation**: Proper parsing and validation of external inputs
- **No Privilege Escalation**: Runs with user permissions only