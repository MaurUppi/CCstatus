# NetworkSegment Core Timing-Driven Orchestration - Critical Architecture Analysis

## 🚨 CRITICAL FINDINGS - SYSTEM ARCHITECTURE FAILURE

### Executive Summary
NetworkSegment is implemented as **passive statusline renderer** instead of **active timing-driven orchestrator** as required by specifications. This represents a complete system architecture failure that renders the entire v2 Network Monitoring Pipeline non-functional.

### ❌ Critical Issue #1: NetworkSegment Orchestration Failure

**Location**: `src/core/segments/network/segment.rs:38-74`

**Required Behavior (Per Requirements Document)**:
```rust
fn collect(&self, input: &InputData) -> Option<SegmentData> {
    // Parse timing data from stdin
    let total_duration_ms = input.cost.total_duration_ms;
    
    // Calculate timing windows
    let in_green_window = (total_duration_ms % 300_000) < 3_000;  // Every 300s, first 3s
    let in_red_window = (total_duration_ms % 10_000) < 1_000;   // Every 10s, first 1s
    
    // Active orchestration
    let creds = self.credential_manager.get_credentials();
    let (error_detected, last_error_event) = self.jsonl_monitor.scan_tail();
    
    // Trigger probes when windows hit
    if in_green_window {
        self.http_monitor.probe(ProbeMode::Green, creds);
    }
    if error_detected && in_red_window {
        self.http_monitor.probe(ProbeMode::Red, creds, last_error_event);
    }
}
```

**Actual Implementation**:
```rust
fn collect(&self, _input: &InputData) -> Option<SegmentData> {
    // Network monitoring is async, but Segment trait is sync
    // Return cached status from HttpMonitor for now
    
    let monitoring_state = self.http_monitor.get_monitoring_state();
    // ... just renders cached state, completely ignores _input
}
```

**Missing Critical Features**:
- ❌ No parsing of `_input` parameter (completely ignored with underscore prefix)
- ❌ No timing window calculations (no modulo operations found in codebase)
- ❌ Never calls `CredentialManager.get_credentials()`
- ❌ Never calls `JsonlMonitor.scan_tail()`
- ❌ Never calls `HttpMonitor.probe()`
- ❌ No stdin trigger response - completely passive

### ❌ Critical Issue #2: InputData Schema Missing Cost Field

**Location**: `src/config/types.rs:94-99`

**Required Schema**:
```rust
pub struct InputData {
    pub model: Model,
    pub workspace: Workspace,
    pub transcript_path: String,
    pub cost: CostData,  // ❌ COMPLETELY MISSING
}

pub struct CostData {
    pub total_duration_ms: u64,  // ❌ CRITICAL for timing windows
    pub total_cost_usd: f64,
    pub total_api_duration_ms: u64,
}
```

**Actual Implementation**:
```rust
#[derive(Deserialize)]
pub struct InputData {
    pub model: Model,
    pub workspace: Workspace,
    pub transcript_path: String,
    // NO cost field - cannot calculate timing windows
}
```

**Search Validation Results**:
- `CostData` struct: **Not found anywhere in codebase**
- `total_duration_ms` field: **Not found anywhere in codebase**
- Window calculations: **No 300_000 or 10_000 modulo operations exist**

### 🎯 Requirements vs Reality Gap Analysis

| Component | Required Role | Actual Implementation | Status |
|-----------|---------------|---------------------|--------|
| NetworkSegment | Active stdin-triggered orchestrator | Passive statusline renderer | ❌ CRITICAL FAILURE |
| InputData.cost | Parse total_duration_ms for windows | Field doesn't exist | ❌ MISSING ENTIRELY |
| Window Calculations | (total_duration_ms % 300_000) < 3_000 | Not implemented | ❌ NON-EXISTENT |
| CredentialManager calls | Active credential resolution | Never called | ❌ NO INTEGRATION |
| HttpMonitor probes | Active timing-driven probes | Never triggered | ❌ NO ORCHESTRATION |

### 🚨 System Impact Assessment

**Severity**: CRITICAL ARCHITECTURE FAILURE

**Impact Scope**:
- **Timing-driven behavior**: Completely non-functional
- **GREEN window probes**: Never occur (300s frequency control missing)
- **RED window probes**: Never occur (10s error-driven control missing) 
- **Credential resolution**: Never happens
- **Error detection coordination**: Never triggered
- **Pipeline orchestration**: Completely broken

**Root Cause**: Fundamental architectural mismatch
- **Expected**: NetworkSegment as intelligent timing-driven coordinator
- **Reality**: NetworkSegment as simple status display renderer

### 📋 Required Implementation Steps

1. **Fix InputData Schema** (`src/config/types.rs`):
   - Add `cost: CostData` field to InputData
   - Define CostData struct with total_duration_ms

2. **Reimplement NetworkSegment.collect()** (`src/core/segments/network/segment.rs`):
   - Parse input.cost.total_duration_ms
   - Calculate GREEN/RED timing windows
   - Call CredentialManager.get_credentials()
   - Call JsonlMonitor.scan_tail() for error detection
   - Call HttpMonitor.probe() when windows hit

3. **Add Window Logic**:
   - GREEN: `(total_duration_ms % 300_000) < 3_000`
   - RED: `(total_duration_ms % 10_000) < 1_000` (only when error_detected)

4. **Enable Active Orchestration**:
   - Transform from passive renderer to active coordinator
   - Implement stdin trigger response behavior
   - Coordinate between all network monitoring components

### 💡 Architectural Insights

**Design Pattern Issue**: 
- Current implementation treats NetworkSegment as View component (passive renderer)
- Requirements specify Controller component (active orchestrator)
- This MVC pattern mismatch causes complete system dysfunction

**Critical Dependencies**:
- InputData.cost.total_duration_ms → Timing window calculations
- Timing windows → Probe frequency control  
- Probe frequency → Network monitoring functionality
- Network monitoring → Status accuracy

**Fix Priority**: IMMEDIATE - System is completely non-functional without these changes

### 🎯 Validation Methodology Used

1. **Requirements Analysis**: Deep read of network monitoring v2 specification
2. **Code Inspection**: Symbol-based analysis of NetworkSegment implementation  
3. **Schema Validation**: Search for CostData and total_duration_ms fields
4. **Integration Testing**: Search for cross-component calls (get_credentials, probe)
5. **Pattern Matching**: Search for timing window calculations (modulo operations)

**Confidence Level**: 100% - All findings validated through systematic code analysis

---

*Analysis completed: 2025-01-25*  
*Validation method: Systematic architectural review with requirements traceability*  
*Impact assessment: Complete system dysfunction - immediate fix required*