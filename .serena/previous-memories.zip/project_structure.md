# CCstatus - Project Structure

## Root Directory Structure

```
CCstatus/
├── src/                     # Source code
├── tests/                   # Test files
├── .github/                 # GitHub Actions CI/CD
├── assets/                  # Project assets (screenshots, etc.)
├── npm/                     # NPM packaging files
├── Cargo.toml               # Rust package manifest
├── Cargo.lock               # Dependency lock file
├── README.md                # English documentation
├── README.zh.md             # Chinese documentation
├── CHANGELOG.md             # Version history
└── .gitignore               # Git ignore rules
```

## Source Code Organization (`src/`)

### Core Application Structure

```
src/
├── main.rs                  # Application entry point
├── lib.rs                   # Library root
├── cli.rs                   # Command-line interface definitions
└── updater.rs               # Self-update functionality
```

### Core Module (`src/core/`)

```
src/core/
├── mod.rs                   # Module exports
├── statusline.rs           # Main statusline generation logic
└── segments/               # Segment implementations
    ├── mod.rs              # Segment module exports
    ├── directory.rs        # Directory display segment
    ├── git.rs              # Git status segment
    ├── model.rs            # Claude model display segment
    ├── usage.rs            # Context usage segment
    ├── update.rs           # Update notification segment
    └── network/            # Network monitoring segment
        ├── mod.rs          # Network module exports
        ├── credential.rs   # Credential management
        └── credential.md   # Credential system documentation
```

### Configuration Module (`src/config/`)

```
src/config/
├── mod.rs                  # Configuration module exports
├── types.rs                # Configuration type definitions
├── loader.rs               # Configuration loading logic
└── defaults.rs             # Default configuration values
```

### UI Module (`src/ui/`)

```
src/ui/
├── mod.rs                  # UI module exports
├── app.rs                  # Main TUI application state
├── layout.rs               # UI layout management
├── events.rs               # Event handling
├── components/             # UI components
│   ├── mod.rs              # Component exports
│   ├── editor.rs           # Configuration editor
│   ├── settings.rs         # Settings panel
│   ├── preview.rs          # Live preview
│   ├── help.rs             # Help system
│   ├── segment_list.rs     # Segment list editor
│   ├── color_picker.rs     # Color selection
│   ├── icon_selector.rs    # Icon selection
│   ├── theme_selector.rs   # Theme selection
│   ├── name_input.rs       # Name input field
│   └── separator_editor.rs # Separator editor
└── themes/                 # Theme system
    ├── mod.rs              # Theme module exports
    └── presets.rs          # Predefined themes
```

### Themes Module (`src/themes/`)

```
src/themes/
└── powerline_importer.rs   # Powerline theme import (planned)
```

## Test Structure (`tests/`)

```
tests/
├── main.rs                 # Test entry point
├── common/                 # Common test utilities
│   └── mod.rs              # Shared test code
└── network/                # Network-specific tests
    └── credential_tests.rs # Credential management tests
```

## Key Architecture Components

### 1. Segment System
**Location**: `src/core/segments/`

The modular segment system allows independent components to contribute to the statusline:
- Each segment is self-contained with its own logic
- Configurable via the unified configuration system  
- Can be enabled/disabled independently
- Supports async operations (network monitoring)

### 2. Configuration Management
**Location**: `src/config/`

Hierarchical configuration system:
- TOML-based configuration files
- Environment variable overrides
- Runtime CLI arguments
- Default fallbacks

### 3. Network Monitoring
**Location**: `src/core/segments/network/`

Advanced credential management and API monitoring:
- Multi-source credential resolution (Environment → Claude Config → Shell Config)
- Cross-platform shell configuration parsing
- Async health checking with adaptive frequency
- Status file output for shell integration

### 4. TUI Interface
**Location**: `src/ui/`

Optional terminal user interface for configuration:
- Real-time preview of statusline changes
- Interactive segment configuration
- Theme selection and customization
- Color and icon pickers

## Module Dependencies

### Internal Dependencies
```
main.rs
├── cli.rs              (command-line parsing)
├── config::*           (configuration management)
├── core::*             (core functionality)
└── ui::*               (optional TUI interface)

core/statusline.rs
├── segments::*         (all segment implementations)
└── config::types       (configuration structures)

segments/network/
├── credential.rs       (credential resolution)
└── types               (network-specific types)
```

### External Dependencies
- **serde ecosystem**: Configuration and data serialization
- **clap**: Command-line interface
- **tokio**: Async runtime (network monitoring)
- **ratatui + crossterm**: Terminal UI (optional)
- **isahc**: HTTP client for API monitoring

## Build Artifacts

### Release Binaries
- `ccstatus` (Linux/macOS executable)
- `ccstatus.exe` (Windows executable)

### Configuration Files
- `~/.claude/ccstatus/config.toml` (user configuration)
- `~/.claude/ccstatus/ccstatus-monitoring.json` (network status)

## Development Workflow

### Source Code Flow
1. **Entry Point** (`main.rs`): CLI parsing and mode selection
2. **Configuration Loading** (`config/`): Load user preferences
3. **Data Collection** (`core/segments/`): Gather segment information  
4. **Statusline Generation** (`core/statusline.rs`): Format and output
5. **Optional UI** (`ui/`): TUI configuration interface

### Feature Gating
The codebase uses Cargo features to conditionally compile functionality:
- Base functionality always available
- `network-monitoring`: Async API health checking
- `tui`: Terminal user interface
- `self-update`: Update checking and installation

## Testing Strategy

### Test Organization
- **Unit Tests**: Embedded in source files with `#[cfg(test)]`
- **Integration Tests**: `tests/` directory for cross-module testing
- **Network Tests**: Specialized tests for credential and monitoring systems

### Test Categories
- **Configuration**: Config loading, parsing, defaults
- **Segments**: Individual segment functionality
- **Network**: Credential resolution, API monitoring
- **UI**: Component behavior and state management

## Documentation

### Code Documentation
- **Inline Comments**: Focused on complex logic and algorithms
- **Module Documentation**: High-level purpose and usage
- **API Documentation**: Public interface documentation
- **Architecture Notes**: Design decisions and patterns

### External Documentation
- **README.md**: User-facing documentation and installation
- **README.zh.md**: Chinese translation
- **CHANGELOG.md**: Version history and breaking changes
- **credential.md**: Detailed credential system documentation