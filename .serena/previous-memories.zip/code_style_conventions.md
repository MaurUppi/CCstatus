# CCstatus - Code Style & Conventions

## Rust Language Standards

### Edition & Language Level
- **Rust Edition**: 2021 (latest stable)
- **Minimum Supported Rust Version (MSRV)**: Not explicitly specified (uses latest stable)
- **Language Features**: Uses stable Rust features only, no nightly dependencies

## Code Formatting & Style

### Formatting Rules
- **Formatter**: `cargo fmt` (rustfmt) with default settings
- **Line Length**: Default rustfmt limit (100 characters)
- **Indentation**: 4 spaces (Rust standard)
- **CI Enforcement**: `cargo fmt -- --check` in CI pipeline

### Code Structure
```rust
// Standard module organization
use std::collections::HashMap;     // Standard library imports first
use serde::{Deserialize, Serialize}; // External crate imports second
use crate::config::types::Config;  // Internal imports last

// Function organization
pub fn public_function() -> Result<(), Error> {
    // Public functions first
}

fn private_function() {
    // Private functions after public ones
}
```

## Naming Conventions

### Identifiers
- **Functions & Variables**: `snake_case`
- **Types & Structs**: `PascalCase`  
- **Constants**: `SCREAMING_SNAKE_CASE`
- **Modules**: `snake_case`
- **Feature Names**: `kebab-case` (e.g., `network-monitoring`)

### Examples
```rust
// Correct naming patterns
pub struct SegmentConfig {          // PascalCase for types
    pub enabled: bool,              // snake_case for fields
    pub icon_config: IconConfig,    // snake_case with descriptive names
}

const DEFAULT_TIMEOUT: u64 = 30;   // SCREAMING_SNAKE_CASE for constants

fn parse_export_statements() {      // snake_case for functions
    // Implementation
}

mod network_monitoring;             // snake_case for modules
```

## Error Handling

### Error Strategy
- **Error Crate**: Uses `thiserror` for custom error types
- **Return Types**: Consistent use of `Result<T, E>` pattern
- **Error Propagation**: Uses `?` operator for error propagation
- **Error Categories**: Domain-specific error types

### Error Implementation Pattern
```rust
use thiserror::Error;

#[derive(Error, Debug)]
pub enum NetworkError {
    #[error("Home directory not found")]
    HomeDirNotFound,
    
    #[error("Configuration read error: {0}")]
    ConfigReadError(std::io::Error),
    
    #[error("Regex compilation error: {0}")]
    RegexError(String),
}
```

## Documentation Standards

### Code Documentation
- **Module-level Docs**: High-level purpose and usage examples
- **Public API**: Documented with `///` doc comments
- **Examples**: Include usage examples in doc comments where helpful
- **Architecture**: Significant design decisions documented in code

### Documentation Style
```rust
/// Manages credential resolution from multiple sources with shell configuration parsing
/// 
/// The credential manager implements a priority-based resolution system:
/// 1. Environment variables (highest priority)
/// 2. Shell configuration files
/// 3. Claude Code configuration files (lowest priority)
/// 
/// # Examples
/// 
/// ```rust
/// let credential_manager = CredentialManager::new()?;
/// if let Some(creds) = credential_manager.get_credentials().await? {
///     // Use credentials
/// }
/// ```
pub struct CredentialManager {
    claude_config_paths: Vec<PathBuf>,
}
```

## Async Programming Conventions

### Async Patterns
- **Runtime**: Uses Tokio with multi-threaded runtime
- **Function Signatures**: Clear async boundaries with `async fn`
- **Error Handling**: Async-compatible error types
- **I/O Operations**: Non-blocking file and network operations

### Async Style
```rust
/// Try to get credentials from Claude Code config file
pub async fn get_from_claude_config(
    &self, 
    config_path: &PathBuf
) -> Result<Option<ApiCredentials>, NetworkError> {
    if !config_path.exists() {
        return Ok(None);
    }
    
    let content = tokio::fs::read_to_string(config_path).await
        .map_err(NetworkError::ConfigReadError)?;
    
    // Process content...
    Ok(result)
}
```

## Serialization Conventions

### Serde Usage
- **Derive Macros**: Consistent use of `#[derive(Serialize, Deserialize)]`
- **Field Naming**: `snake_case` in Rust, converted to appropriate format for external APIs
- **Optional Fields**: Use `Option<T>` for optional configuration values
- **Default Values**: Implement `Default` trait for configuration structs

### Serialization Example
```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SegmentConfig {
    pub id: SegmentId,
    pub enabled: bool,
    pub icon: IconConfig,
    pub colors: ColorConfig,
    pub styles: TextStyleConfig,
    pub options: HashMap<String, serde_json::Value>,
}
```

## Testing Conventions

### Test Organization
- **Unit Tests**: In-file tests with `#[cfg(test)]` modules
- **Integration Tests**: Separate `tests/` directory
- **Test Naming**: Descriptive test function names with `test_` prefix
- **Test Structure**: Arrange-Act-Assert pattern

### Test Examples
```rust
#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_credential_manager_new() {
        let cm = CredentialManager::new();
        assert!(cm.is_ok() || cm.is_err()); // Either outcome valid
    }
    
    #[tokio::test]
    async fn test_environment_credentials() {
        let cm = CredentialManager::new().unwrap();
        let result = cm.get_from_environment();
        assert!(result.is_ok());
    }
}
```

## Feature Management

### Feature Flags
- **Conditional Compilation**: Use `#[cfg(feature = "...")]` for optional functionality
- **Feature Documentation**: Clear documentation of what each feature enables
- **Default Features**: Sensible defaults with optional enhancements

### Feature Pattern
```rust
#[cfg(feature = "network-monitoring")]
pub mod network;

#[cfg(feature = "tui")]
pub fn run_configurator() -> Result<(), Box<dyn std::error::Error>> {
    // TUI implementation
}

#[cfg(not(feature = "tui"))]
pub fn run_configurator() -> Result<(), Box<dyn std::error::Error>> {
    eprintln!("TUI feature not enabled");
    std::process::exit(1);
}
```

## Performance Conventions

### Optimization Guidelines
- **String Handling**: Prefer `&str` over `String` when possible
- **Memory Allocation**: Minimize unnecessary allocations
- **Async Operations**: Use async for I/O, avoid blocking operations
- **Error Paths**: Fast failure paths for common error conditions

### Performance Patterns
```rust
// Prefer borrowing over cloning
pub fn process_content(&self, content: &str) -> Result<Option<Credentials>, Error> {
    // Work with borrowed content
}

// Use async for I/O operations
pub async fn read_config(&self, path: &Path) -> Result<String, Error> {
    tokio::fs::read_to_string(path).await
        .map_err(|e| Error::ConfigRead(e))
}
```

## Security Guidelines

### Secure Coding Practices
- **Credential Handling**: Never log credential values
- **Input Validation**: Validate all external inputs
- **Error Messages**: Avoid exposing sensitive information in error messages
- **File Permissions**: Respect file system permissions

### Security Example
```rust
// Safe credential logging - shows length, not value
logger.debug(
    "CredentialManager", 
    &format!("Found credentials: token_len={}", creds.auth_token.len())
).await;

// Input validation
if !config_path.exists() {
    return Ok(None);  // Fail-silent for missing files
}
```

## CI/CD Integration

### Code Quality Checks
- **Formatting**: `cargo fmt -- --check`
- **Linting**: `cargo clippy -- -D warnings` (warnings treated as errors)
- **Testing**: `cargo test --verbose`
- **Cross-platform**: Build verification on Linux, macOS, Windows

### Quality Gates
All code must pass:
1. Compilation without warnings
2. Formatting check (rustfmt)
3. Linting check (clippy) with zero warnings
4. All tests passing
5. Cross-platform build verification