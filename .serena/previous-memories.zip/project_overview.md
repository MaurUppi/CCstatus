# CCstatus - Project Overview

CCstatus is a high-performance Claude Code statusline and network monitoring tool written in Rust with Git integration, real-time usage tracking, and API connectivity monitoring.

## Primary Purpose

CCstatus serves as a comprehensive status display tool for Claude Code IDE, providing developers with real-time information about their development environment. It displays critical information in a compact, informative statusline including:

- Model information with simplified Claude model names
- Current directory/workspace
- Git branch status and tracking information  
- Context window usage (token usage percentage)
- Real-time Claude API connectivity monitoring
- Visual indicators for API health status

## Key Features

### Core Functionality
- **High Performance**: Native Rust implementation with < 50ms startup time
- **Network Monitoring**: Real-time Claude API connectivity status with adaptive health check frequency
- **Git Integration**: Branch status, tracking info, and working tree state
- **Model Display**: Simplified Claude model names (e.g., `claude-3-5-sonnet` → `Sonnet 3.5`)
- **Usage Tracking**: Token usage based on transcript analysis with context limit tracking
- **Visual Indicators**: Color-coded API status (🟢/🟡/🔴) for terminal prompt integration

### Network Monitoring Features
- **Adaptive Monitoring**: Frequency adjusts based on connection health
  - Healthy: 30s interval, extends to 5min after 10 consecutive successes
  - Degraded: 5s interval for quick recovery detection
  - Failed: 60s interval to avoid overwhelming failed endpoints
- **Status File**: Writes monitoring status to `~/.claude/ccstatus/ccstatus-monitoring.json`
- **Fail-silent**: Gracefully handles missing credentials without errors
- **Priority-based Credentials**: Environment variables → Claude config → Shell config

### Advanced Features
- **TUI Configuration Interface**: Optional GUI for configuration management
- **Cross-platform Support**: Windows, macOS, Linux with appropriate binaries
- **Self-update Capability**: Built-in update mechanism (optional feature)
- **Theme System**: Multiple themes and customizable styling
- **Nerd Font Integration**: Rich icon support for enhanced visual display

## Architecture

The project is organized in a modular architecture:

### Core Components
- **Statusline Generator**: Main rendering engine for status display
- **Segment System**: Modular components for different information types
- **Configuration Management**: TOML-based configuration with defaults
- **Network Monitoring**: Async API health checking and credential management

### Segment Types
- **Directory Segment**: Current workspace display
- **Git Segment**: Branch status and tracking information
- **Model Segment**: Claude model information
- **Usage Segment**: Context window and token usage
- **Network Segment**: API connectivity monitoring
- **Update Segment**: Update availability checking

## Target Users

- **Claude Code Users**: Primary target for statusline integration
- **Developers**: Working with Claude API who need connectivity monitoring
- **DevOps**: Teams needing API health monitoring in development workflows
- **Terminal Users**: Power users wanting rich status information in their prompt

## Value Proposition

1. **Performance**: Rust-native speed vs TypeScript alternatives (~4x faster startup, ~60% less memory)
2. **Comprehensive Monitoring**: Combines statusline display with real-time API health monitoring
3. **Easy Integration**: Simple configuration and automatic Claude Code integration
4. **Cross-platform**: Native binaries for all major platforms
5. **Extensible**: Modular architecture allows for future feature expansion

## Development Stage

Currently at version 1.0.4, the project is in active development with:
- Stable core functionality
- Network monitoring feature complete
- TUI configuration interface implemented
- Cross-platform binary distribution
- NPM packaging for easy installation

## Installation Methods

1. **NPM Global Install** (Recommended): `npm install -g @mauruppi/ccstatus`
2. **Manual Binary**: Download from GitHub releases
3. **Build from Source**: Full Cargo build process

The project is designed to be immediately usable after installation with sensible defaults while offering extensive customization options for power users.