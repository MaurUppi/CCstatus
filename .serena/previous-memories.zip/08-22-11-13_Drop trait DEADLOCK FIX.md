# Drop Trait Deadlock Analysis & Fix - NetworkSegment

## Problem Summary
**Critical deadlock identified** in NetworkSegment Drop trait implementation causing HTTP requests to hang at "Executing HTTP request..." indefinitely.

## Root Cause Analysis

### Deadlock Chain
1. **Multiple Instance Problem**: Both async (`new()`) and sync (`new_sync()`) create NetworkSegment instances simultaneously
2. **Aggressive Cleanup**: Drop trait calls `cleanup_files()` which unconditionally deletes shared resources:
   - `network-debug.log` (actively being written to)
   - `ccstatus-monitoring.json`
3. **Resource Conflict**: When any instance drops, it deletes files that other active instances are using
4. **File Handle Invalidation**: HTTP monitoring loops get stuck when trying to write to deleted debug log files

### Evidence from Debug Logs
- Pattern: "Cleanup Deleted debug log" messages appear during active execution
- HTTP requests start but never complete after "Executing HTTP request..."
- Multiple "Sync Init Started" entries show concurrent instance creation
- Repeating cycle every ~10 seconds as instances are created/dropped

### Original Intent
Drop trait was implemented to ensure fresh ccstatus startup by cleaning stale `ccstatus-monitoring.json` files containing previous session state like `"interval_seconds": 300`.

## Solution: Instance Type Differentiation

### Implementation Strategy
Add instance type discrimination to NetworkSegment to differentiate cleanup behavior:

```rust
// Add before NetworkSegment struct (around line 20)
#[derive(Debug, Clone, PartialEq)]
enum InstanceType {
    /// Primary instance - should cleanup on drop (from async new())
    Primary,
    /// Secondary instance - should NOT cleanup on drop (from sync new_sync())
    Secondary,
}

// Add field to NetworkSegment struct (around line 36)
pub struct NetworkSegment {
    current_status: Arc<RwLock<NetworkStatus>>,
    status_renderer: StatusRenderer,
    config: NetworkConfig,
    _monitoring_handle: Option<tokio::task::JoinHandle<()>>,
    instance_type: InstanceType,  // ADD THIS FIELD
}

// Update Drop implementation (lines 731-736)
impl Drop for NetworkSegment {
    fn drop(&mut self) {
        // Only cleanup for primary instances
        if self.instance_type == InstanceType::Primary {
            Self::cleanup_files();
        }
    }
}

// Update constructors:
// In new() method (~line 282): instance_type: InstanceType::Primary
// In new_sync() method (~line 265): instance_type: InstanceType::Secondary
```

### Architecture Benefits
- **Primary instances** (async monitoring): Clean up on shutdown ✅
- **Secondary instances** (statusline): No cleanup, prevent deadlock ✅  
- **Fresh startup**: Status files still deleted by primary instance ✅
- **No resource conflicts**: Each instance type has defined behavior ✅

## Files Analyzed
- `src/core/segments/network/segment.rs` - Main implementation
- `src/core/segments/network/state_machine.rs` - StateMachine struct
- `~/.claude/ccstatus/network-debug.log` - Debug evidence
- `~/.claude/ccstatus/ccstatus-monitoring.json` - Status file (deleted by cleanup)

## Key Technical Insights
1. **Multiple Runtime Conflict**: Both "ccstatus-monitor" and "ccstatus-sync-health" runtimes accessing same HTTP resources
2. **File Locking Issues**: Deleting debug log while HTTP requests are writing to it causes system-level resource conflicts
3. **Lifecycle Mismatch**: Long-lived async instances vs short-lived sync instances have different cleanup needs
4. **StateMachine Not At Fault**: The deadlock is in Drop trait implementation, not StateMachine functionality

This fix preserves the original cleanup intention while eliminating multi-instance resource conflicts.