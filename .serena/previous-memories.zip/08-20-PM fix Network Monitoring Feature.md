# Network Monitoring Feature - Comprehensive Fix Analysis & Action Plan

## Session Overview
Conducted deep architecture analysis of ccstatus network monitoring feature with user clarification on design purpose. Identified critical synchronization issues and designed complete fix strategy with prioritized action items.

## Design Purpose Clarification
ccstatus monitors Claude Code API health in real-time:
- Display network status (🟢🟡🔴) in statusline when Claude Code encounters API errors
- Background monitoring with adaptive frequency strategy
- Capture errors from Claude Code session logs (401, 403, 429, 500, 502, 504)
- Save error tracking to `ccstatus-captured-error.json` with first/last occurrence strategy
- Show detailed breakdowns (DNS:20ms|TCP:30ms|TLS:40ms|TTFB:420ms|Total:841ms)
- Return to 🟢 when network recovers

## Critical Issues Identified

### 🚨 Issue #1: Status Synchronization Failure (CRITICAL)
**Problem**: JSON shows `"status": "error"` but statusline displays ⚪ (Unknown) instead of 🔴 (Error)
**Root Cause**: Disconnect between MonitoringEngine status updates and NetworkSegment current_status
**Impact**: Users can't see network issues in real-time - breaks core functionality
**Files**: `src/core/segments/network/segment.rs:243-286` (collect), `288-435` (MonitoringEngine)

### 🔥 Issue #2: Error Type Taxonomy Incomplete (HIGH)
**Problem**: `last_error_code: 400` but `error_type: null`
**Official Anthropic API Error Types** (from https://docs.anthropic.com/en/api/errors):
- 400: `invalid_request_error`
- 401: `authentication_error`  
- 403: `permission_error`
- 404: `not_found_error`
- 413: `request_too_large`
- 429: `rate_limit_error`
- 500: `api_error`
- 529: `overloaded_error`
- Network: `connection_error`

**Current Bug**: HttpMonitor sets `error: None` for HTTP responses, only populates for network failures
**Files**: `src/core/segments/network/http_monitor.rs:68-86`, `123-141`

### 🔥 Issue #3: Wrong Logging Directory (HIGH)
**Problem**: Uses hardcoded `~/.claude/ccstatus/` instead of project-specific directory
**Smart Detection Pattern**:
```
PWD: /Users/ouzy/Documents/DevProjects/CCstatus
→ ~/.claude/projects/-Users-ouzy-Documents-DevProjects-CCstatus
```
**Algorithm**: Replace all '/' with '-' in PWD, prepend `~/.claude/projects/`
**Files**: `src/core/segments/network/status_file_writer.rs:9-15`

### 📋 Issue #4: Missing Error Capture System (MEDIUM)
**Hybrid Architecture Design**:
- **Read From**: `~/.claude/projects/{project-dir}/*.jsonl` (latest modified file)
- **Store To**: `~/.claude/ccstatus/ccstatus-captured-error.json` (global)
- **Strategy**: Monitor latest .jsonl file changes, parse Claude Code errors, track first/last occurrence

## Adaptive Frequency Strategy (Exact Rules)
```
Initial State: 30 seconds
├── 10 consecutive healthy → HealthyOptimized: 5 minutes
└── Any error → ErrorMode: 5 seconds
    ├── 10 consecutive errors → ErrorPersistent: 1 minute  
    └── Recovery → Back to Initial: 30 seconds
```

**Counters Required**:
- `consecutive_healthy_count: u32`
- `consecutive_error_count: u32`
- `current_frequency_state: FrequencyState`

## Technical Implementation

### Smart Project Directory Detection
```rust
fn get_claude_project_dir() -> Result<PathBuf, NetworkError> {
    let pwd = std::env::current_dir()?;
    let claude_project_name = pwd.to_string_lossy().replace('/', "-");
    let home = env::var("HOME")?;
    Ok(PathBuf::from(home)
        .join(".claude")
        .join("projects") 
        .join(claude_project_name))
}
```

### Error Capture System Architecture
```rust
struct ProjectLogWatcher {
    project_dir: PathBuf,           // Dynamic project directory
    latest_file: Option<PathBuf>,   // Latest modified .jsonl
    file_position: u64,             // Track read position
    error_tracker: Arc<ErrorTracker>,
}

// ccstatus-captured-error.json format:
{
  "project_source": "/Users/ouzy/Documents/DevProjects/CCstatus",
  "error_summary": {
    "authentication_error": {
      "first_seen": "2025-08-20T00:01:39Z", 
      "last_seen": "2025-08-20T00:05:20Z",
      "count": 3
    }
  }
}
```

## Priority Action Items

### Phase 1: Core Fixes (CRITICAL/HIGH)
1. **Fix Status Synchronization** - Debug MonitoringEngine.set_status() → current_status flow
2. **Smart Project Directory** - Replace hardcoded paths with dynamic detection
3. **Complete Error Taxonomy** - Map HTTP codes to Anthropic error types, populate error field
4. **Adaptive Frequency Strategy** - Implement FrequencyStateMachine with exact timing rules

### Phase 2: Feature Enhancement (MEDIUM)
1. **Error Capture System** - Build ProjectLogWatcher to monitor latest .jsonl files
2. **Enhanced Status Display** - Show detailed breakdowns in statusline
3. **Integration Testing** - Verify end-to-end functionality

## Files Requiring Changes
- `src/core/segments/network/segment.rs` - Fix status sync, add project detection
- `src/core/segments/network/http_monitor.rs` - Complete error taxonomy mapping
- `src/core/segments/network/status_file_writer.rs` - Dynamic project directory
- `src/core/segments/network/state_machine.rs` - Adaptive frequency strategy
- `src/core/segments/network/status_renderer.rs` - Enhanced display with breakdowns
- **NEW**: `src/core/segments/network/project_log_watcher.rs` - .jsonl monitoring
- **NEW**: `src/core/segments/network/error_capture_writer.rs` - Global error tracking

## Success Criteria
- ✅ Statusline shows 🔴 immediately when JSON has "error" status  
- ✅ Meaningful error types instead of null in JSON output
- ✅ Project-specific monitoring works in any directory
- ✅ Adaptive frequency strategy responds to network health
- ✅ Error capture system tracks first/last occurrence across projects
- ✅ Detailed timing breakdowns visible in statusline during errors

## Current Status
- **Architecture Analysis**: Complete ✅
- **Issue Identification**: Complete ✅  
- **Solution Design**: Complete ✅
- **Implementation**: Ready to begin 🚀

**Estimated Timeline**: 3-4 days for Phase 1 (core fixes), 2-3 days for Phase 2 (enhancements)