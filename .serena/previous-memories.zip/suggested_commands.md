# CCstatus - Suggested Development Commands

## Essential Development Commands

### Project Setup
```bash
# Clone the repository
git clone https://github.com/MaurUppi/CCstatus.git
cd CCstatus

# Build development version with all features
cargo build --features network-monitoring

# Build basic version (without network monitoring)
cargo build

# Build optimized release with all features
cargo build --features network-monitoring --release
```

### Development Workflow Commands

#### Daily Development
```bash
# Quick development build
cargo build

# Run with development build
cargo run -- --help

# Run with specific features
cargo run --features network-monitoring -- --print

# Build and run in one step
cargo run --release --features network-monitoring
```

#### Code Quality (Required before commits)
```bash
# Format code (must pass)
cargo fmt

# Check formatting without changing files
cargo fmt -- --check

# Run linter (must pass without warnings)
cargo clippy -- -D warnings

# Run linter for all features
cargo clippy --features network-monitoring -- -D warnings
```

#### Testing
```bash
# Run all tests
cargo test --verbose

# Run tests with network monitoring features
cargo test --features network-monitoring --verbose

# Run specific test module
cargo test --features network-monitoring credential_tests

# Run tests with output
cargo test -- --nocapture

# Run single test
cargo test test_credential_manager_new
```

## Feature-Specific Commands

### Network Monitoring Development
```bash
# Build with network monitoring only
cargo build --features network-monitoring

# Test network monitoring specifically
cargo test --features network-monitoring network

# Run with network monitoring enabled
cargo run --features network-monitoring
```

### TUI Development
```bash
# Build with TUI features
cargo build --features tui

# Run TUI configurator
cargo run --features tui -- --config

# Test with full feature set
cargo test --features "tui,network-monitoring"
```

### Self-Update Development
```bash
# Build with self-update capability
cargo build --features self-update

# Test update checking
cargo run --features self-update -- --update
```

## Release & Distribution Commands

### Production Builds
```bash
# Full feature release build
cargo build --features "tui,self-update,network-monitoring" --release

# Minimal release build
cargo build --release

# Cross-platform release preparation (local)
cargo build --target x86_64-unknown-linux-gnu --release
cargo build --target x86_64-pc-windows-gnu --release
```

### Installation & Deployment
```bash
# Install to local Claude Code directory
mkdir -p ~/.claude/ccstatus
cp target/release/ccstatus ~/.claude/ccstatus/ccstatus
chmod +x ~/.claude/ccstatus/ccstatus

# Test installation
~/.claude/ccstatus/ccstatus --help
```

## Configuration & Usage Commands

### Configuration Management
```bash
# Print current configuration
ccstatus --print

# Check configuration validity
ccstatus --check

# Initialize default configuration
ccstatus --init

# Run TUI configurator (if tui feature enabled)
ccstatus --config

# Apply specific theme
ccstatus --theme powerline
```

### Testing Integration
```bash
# Test with Claude Code mock data
echo '{"directory": "/test", "model": "claude-3-5-sonnet"}' | ccstatus

# Test statusline generation
ccstatus --print | head -1

# Test network monitoring status file
cat ~/.claude/ccstatus/ccstatus-monitoring.json
```

## Debugging & Development Tools

### Debug Builds
```bash
# Debug build with full logging
RUST_LOG=debug cargo run --features network-monitoring

# Debug network monitoring specifically
CCSTATUS_DEBUG=1 cargo run --features network-monitoring

# Build with debug symbols
cargo build --features network-monitoring
```

### Profiling & Performance
```bash
# Release build for performance testing
cargo build --release --features network-monitoring

# Time execution
time ./target/release/ccstatus --print

# Memory usage check (on Linux)
valgrind --tool=massif ./target/release/ccstatus --print
```

## Platform-Specific Commands

### macOS (Darwin) Specific
```bash
# Check for Homebrew dependencies (if any)
brew list | grep -E '(git|rust)'

# macOS release build
cargo build --target x86_64-apple-darwin --release  # Intel
cargo build --target aarch64-apple-darwin --release  # Apple Silicon
```

### Linux Specific
```bash
# Static build for universal Linux compatibility
cargo build --target x86_64-unknown-linux-musl --release

# Dynamic build for modern Linux
cargo build --target x86_64-unknown-linux-gnu --release

# Check dependencies
ldd target/release/ccstatus
```

### Windows Specific
```powershell
# Windows build
cargo build --target x86_64-pc-windows-msvc --release

# Install to Claude Code (PowerShell)
New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.claude\ccstatus"
Copy-Item "target\release\ccstatus.exe" "$env:USERPROFILE\.claude\ccstatus\"
```

## Continuous Integration Commands

### Local CI Simulation
```bash
# Simulate full CI pipeline locally
cargo fmt -- --check && \
cargo clippy --features network-monitoring -- -D warnings && \
cargo test --features network-monitoring --verbose && \
cargo build --release --features network-monitoring
```

### Quality Assurance
```bash
# Full quality check
cargo check --all-features
cargo clippy --all-features -- -D warnings
cargo test --all-features
cargo fmt -- --check

# Security audit (if cargo-audit installed)
cargo audit

# Dependency tree analysis
cargo tree
```

## Git & Version Management

### Development Workflow
```bash
# Create feature branch
git checkout -b feature/network-monitoring-enhancement

# Commit with conventional commits
git commit -m "feat(network): add adaptive monitoring frequency"
git commit -m "fix(credential): handle missing shell config gracefully"
git commit -m "docs(readme): update installation instructions"

# Push feature branch
git push origin feature/network-monitoring-enhancement
```

### Release Preparation
```bash
# Tag release
git tag -a v1.0.4 -m "Release version 1.0.4"
git push origin v1.0.4

# Update changelog
git log --oneline --since="last release" >> CHANGELOG.md
```

## Utilities & Helper Commands

### System Information
```bash
# Check Rust version
rustc --version

# Check Cargo version
cargo version

# System info
uname -a  # Unix systems
systeminfo  # Windows

# Git version (required dependency)
git --version
```

### Development Environment
```bash
# Check available features
cargo metadata --format-version 1 | jq '.packages[0].features'

# List build targets
rustup target list

# Update Rust toolchain
rustup update stable
```

## Task Completion Checklist

When completing any development task, run this sequence:

```bash
# 1. Format code
cargo fmt

# 2. Fix any linting issues
cargo clippy --features network-monitoring -- -D warnings

# 3. Run all tests
cargo test --features network-monitoring --verbose

# 4. Build release version
cargo build --release --features network-monitoring

# 5. Test installation
mkdir -p ~/.claude/ccstatus
cp target/release/ccstatus ~/.claude/ccstatus/
~/.claude/ccstatus/ccstatus --help

# 6. Commit changes
git add .
git commit -m "type(scope): descriptive message"
```

This ensures code quality, functionality, and proper integration before any code is committed to the repository.