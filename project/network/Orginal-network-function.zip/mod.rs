//! Network monitoring module for CCstatus
//! 
//! Provides Claude API connectivity monitoring with adaptive frequency
//! and comprehensive status reporting.

pub use segment::NetworkSegment;

pub mod types;
pub mod credential_manager;
pub mod shell_config_reader;
pub mod credential;
pub mod http_monitor;
pub mod state_machine;
pub mod latency_tracker;
pub mod error_tracker;
pub mod status_renderer;
pub mod status_file_writer;
pub mod jsonl_monitor;
pub mod debug_logger;
pub mod segment;

pub use types::*;