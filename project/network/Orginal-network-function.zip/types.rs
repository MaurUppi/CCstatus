//! Core types for network monitoring

use std::time::Duration;
use chrono::{DateTime, Utc, Local};
use serde::{Deserialize, Serialize};

use std::path::PathBuf;

/// Network monitoring errors
#[derive(Debug, thiserror::Error)]
pub enum NetworkError {
    #[error("No credentials found")]
    NoCredentials,
    
    #[error("HTTP client error: {0}")]
    HttpClientError(#[from] isahc::Error),
    
    #[error("Configuration read error: {0}")]
    ConfigReadError(#[from] tokio::io::Error),
    
    #[error("Configuration parse error: {0}")]
    ConfigParseError(#[from] serde_json::Error),
    
    #[error("Home directory not found")]
    HomeDirNotFound,
    
    #[error("Failed to detect project directory")]
    DirectoryDetectionError,
    
    #[error("Directory creation failed: {0}")]
    DirectoryCreationError(std::io::Error),
    
    #[error("File write error: {0}")]
    FileWriteError(tokio::io::Error),
    
    #[error("Serialization error: {0}")]
    SerializationError(serde_json::Error),
    
    #[error("Regex pattern error: {0}")]
    RegexError(String),
    
    #[error("Write timeout: {0}")]
    WriteTimeout(String),
    
    #[error("Runtime error: {0}")]
    RuntimeError(String),
    
    #[error("Another sync process is already running")]
    ProcessLocked,
    
    #[error("Process lock error: {0}")]
    ProcessLockError(String),
}

impl NetworkError {
    pub fn should_fail_silent(&self) -> bool {
        matches!(self, 
            NetworkError::NoCredentials |
            NetworkError::HomeDirNotFound
        )
    }
    
    pub fn is_credentials_missing(&self) -> bool {
        matches!(self, NetworkError::NoCredentials)
    }
}

/// Network configuration
#[derive(Debug, Clone, Deserialize)]
pub struct NetworkConfig {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default = "default_timeout")]
    pub timeout_seconds: u64,
    #[serde(default = "default_check_interval")]
    pub check_interval_seconds: u64,
}

impl Default for NetworkConfig {
    fn default() -> Self {
        Self {
            enabled: true,   // Network monitoring enabled by default
            timeout_seconds: default_timeout(),
            check_interval_seconds: default_check_interval(),
        }
    }
}

fn default_timeout() -> u64 { 30 }
fn default_check_interval() -> u64 { 30 }

/// Network status
#[derive(Debug, Clone, PartialEq)]
pub enum NetworkStatus {
    Healthy,
    Degraded { 
        reason: String, 
        details: String 
    },
    Error { 
        error_type: String, 
        details: String 
    },
    Unknown,
    Disabled,
}

impl Default for NetworkStatus {
    fn default() -> Self {
        Self::Unknown
    }
}

impl std::fmt::Display for NetworkStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let status_str = match self {
            NetworkStatus::Healthy => "healthy",
            NetworkStatus::Degraded { .. } => "degraded",
            NetworkStatus::Error { .. } => "error",
            NetworkStatus::Unknown => "unknown",
            NetworkStatus::Disabled => "disabled",
        };
        write!(f, "{}", status_str)
    }
}

/// API credentials from environment or config
#[derive(Debug, Clone)]
pub struct ApiCredentials {
    pub base_url: String,
    pub auth_token: String,
    pub source: CredentialSource,
}

/// Source of credentials
#[derive(Debug, Clone)]
pub enum CredentialSource {
    Environment,
    ShellConfig(PathBuf),
    ClaudeConfig(PathBuf),
}

/// HTTP result status
#[derive(Debug, Clone, PartialEq)]
pub enum HttpStatus {
    Success,
    AuthError,
    RateLimit,
    ServerError,
    ClientError,
    NetworkError,
}

impl HttpStatus {
    pub fn is_success(&self) -> bool {
        matches!(self, HttpStatus::Success)
    }
}

/// Detailed latency information
#[derive(Debug, Clone)]
pub struct LatencyData {
    pub dns: Option<Duration>,
    pub tcp: Option<Duration>, 
    pub tls: Option<Duration>,
    pub ttfb: Duration,
    pub total: Duration,
}

impl LatencyData {
    pub fn format_breakdown(&self) -> String {
        format!(
            "DNS:{}|TCP:{}|TLS:{}|TTFB:{}ms|Total:{}ms",
            self.format_duration(self.dns),
            self.format_duration(self.tcp),
            self.format_duration(self.tls),
            self.ttfb.as_millis(),
            self.total.as_millis()
        )
    }
    
    fn format_duration(&self, duration: Option<Duration>) -> String {
        match duration {
            Some(d) if d.as_millis() == 0 => "reuse".to_string(),
            Some(d) => format!("{}ms", d.as_millis()),
            None => "reuse".to_string(),
        }
    }
}

/// HTTP request result
#[derive(Debug, Clone)]
pub struct HttpResult {
    pub status: HttpStatus,
    pub latency: LatencyData,
    pub error: Option<String>,
    pub error_type: Option<String>,
    pub response_code: Option<u16>,
}

impl HttpResult {
    pub fn error(message: &str, _error: impl std::fmt::Display) -> Self {
        Self {
            status: HttpStatus::NetworkError,
            latency: LatencyData {
                dns: None,
                tcp: None,
                tls: None,
                ttfb: Duration::from_millis(0),
                total: Duration::from_millis(0),
            },
            error: Some(message.to_string()),
            error_type: None, // Network errors don't have Anthropic error types
            response_code: None,
        }
    }
}

/// Monitoring state machine states
#[derive(Debug, Clone)]
pub enum MonitoringState {
    Healthy { 
        interval: Duration, 
        consecutive_successes: u32 
    },
    Degraded { 
        interval: Duration,
        since: DateTime<Utc>,
    },
    Failed { 
        interval: Duration, 
        consecutive_failures: u32,
        since: DateTime<Utc>,
    },
}

/// State machine events
#[derive(Debug, Clone)]
pub enum StateEvent {
    Success,
    RateLimit,
    Failure,
}

/// Health check result with credential context
#[derive(Debug, Clone)]
pub struct HealthCheckResult {
    pub status: NetworkStatus,
    pub latency: LatencyData,
    pub error: Option<String>,
    pub error_type: Option<String>,
    pub timestamp: DateTime<Local>,
    pub state: MonitoringState,
    pub credentials: ApiCredentials,
    pub response_code: Option<u16>,
}

/// Error record for tracking
#[derive(Debug, Clone)]
pub struct ErrorRecord {
    pub first_occurrence: DateTime<Utc>,
    pub last_occurrence: DateTime<Utc>,
    pub count: u32,
    pub error_code: Option<u16>,
}

/// Timed result for HTTP operations
#[derive(Debug)]
pub struct TimedResult {
    pub result: Result<isahc::Response<isahc::AsyncBody>, isahc::Error>,
    pub dns: Option<Duration>,
    pub tcp: Option<Duration>,
    pub tls: Option<Duration>,
    pub ttfb: Duration,
}

/// Status file data structure
#[derive(Serialize, Deserialize)]
pub struct StatusFileData {
    pub status: String,
    pub monitoring_enabled: bool,
    pub api_config: ApiConfigData,
    pub network: NetworkData,
    pub monitoring_state: MonitoringStateData,
    pub timestamp: DateTime<Local>,
}

#[derive(Serialize, Deserialize)]
pub struct ApiConfigData {
    pub endpoint: String,
    pub source: String,
}

#[derive(Serialize, Deserialize)]
pub struct NetworkData {
    pub latency_ms: u32,
    pub breakdown: String,
    pub http_status_code: Option<u16>,
    pub error_type: Option<String>,
}

#[derive(Serialize, Deserialize)]
pub struct MonitoringStateData {
    pub state: String,
    pub interval_seconds: u64,
    pub consecutive_successes: Option<u32>,
    pub consecutive_failures: Option<u32>,
}

impl From<&MonitoringState> for MonitoringStateData {
    fn from(state: &MonitoringState) -> Self {
        match state {
            MonitoringState::Healthy { interval, consecutive_successes } => {
                Self {
                    state: "healthy".to_string(),
                    interval_seconds: interval.as_secs(),
                    consecutive_successes: Some(*consecutive_successes),
                    consecutive_failures: None,
                }
            }
            MonitoringState::Degraded { interval, .. } => {
                Self {
                    state: "degraded".to_string(),
                    interval_seconds: interval.as_secs(),
                    consecutive_successes: None,
                    consecutive_failures: None,
                }
            }
            MonitoringState::Failed { interval, consecutive_failures, .. } => {
                Self {
                    state: "failed".to_string(),
                    interval_seconds: interval.as_secs(),
                    consecutive_successes: None,
                    consecutive_failures: Some(*consecutive_failures),
                }
            }
        }
    }
}