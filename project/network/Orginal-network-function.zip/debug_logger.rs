//! Debug logging for network monitoring
//! 
//! Provides comprehensive logging for monitoring engine lifecycle, credential issues, 
//! status file operations, and troubleshooting network monitoring problems.

use std::env;
use std::path::PathBuf;

use chrono::Local;
use crate::core::segments::network::types::NetworkError;

/// Debug logger for network monitoring operations
pub struct DebugLogger {
    enabled: bool,
    log_file_path: Option<PathBuf>,
}

impl DebugLogger {
    /// Create new debug logger
    pub fn new() -> Self {
        let enabled = env::var("CCSTATUS_DEBUG").unwrap_or_default() == "1";
        let log_file_path = if enabled {
            Self::get_debug_log_path().ok()
        } else {
            None
        };

        Self {
            enabled,
            log_file_path,
        }
    }

    /// Check if debug logging is enabled
    #[allow(dead_code)] // Used in external test files
    pub fn is_enabled(&self) -> bool {
        self.enabled
    }

    /// Get debug log file path in same directory as other ccstatus files
    pub fn get_debug_log_path() -> Result<PathBuf, NetworkError> {
        // Get home directory
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        // Use same directory as ccstatus-monitoring.json and ccstatus-captured-error.json
        let ccstatus_dir = PathBuf::from(home)
            .join(".claude")
            .join("ccstatus");
        
        Ok(ccstatus_dir.join("network-debug.log"))
    }

    /// Helper method to write log entry to file with error handling
    fn write_log_entry_to_file(&self, log_entry: &str) {
        if let Some(ref log_path) = self.log_file_path {
            if let Err(e) = self.write_to_file_sync(log_path, log_entry) {
                eprintln!("DEBUG_LOGGER_ERROR: Failed to write to {}: {}", log_path.display(), e);
            }
        } else {
            eprintln!("DEBUG_LOGGER_ERROR: log_file_path is None");
        }
    }

    /// Log a debug message with timestamp
    pub async fn log(&self, level: &str, component: &str, message: &str) {
        if !self.enabled {
            return;
        }

        let timestamp = Local::now().format("%Y-%m-%d %H:%M:%S%.3f");
        let log_entry = format!("[{}] [{}] [{}] {}\n", timestamp, level, component, message);

        // Always print to stderr when debug is enabled
        eprint!("{}", log_entry);

        // Also write to file if path is available - use sync method for reliability
        self.write_log_entry_to_file(&log_entry);
    }

    /// Log a debug message synchronously (for use in non-async contexts)
    pub fn log_sync(&self, level: &str, component: &str, message: &str) {
        if !self.enabled {
            return;
        }

        let timestamp = Local::now().format("%Y-%m-%d %H:%M:%S%.3f");
        let log_entry = format!("[{}] [{}] [{}] {}\n", timestamp, level, component, message);

        // Always print to stderr when debug is enabled
        eprint!("{}", log_entry);

        // Also write to file if path is available
        self.write_log_entry_to_file(&log_entry);
    }


    /// Write log entry to file synchronously (for use in non-async contexts)
    fn write_to_file_sync(&self, log_path: &PathBuf, entry: &str) -> Result<(), NetworkError> {
        use std::fs;
        use std::io::Write;

        // Ensure directory exists
        if let Some(parent) = log_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent)
                    .map_err(NetworkError::DirectoryCreationError)?;
            }
        }

        // Use append mode to add to existing file
        let mut file = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(log_path)
            .map_err(NetworkError::FileWriteError)?;

        file.write_all(entry.as_bytes())
            .map_err(NetworkError::FileWriteError)?;

        // Critical: Flush to ensure data is written to disk
        file.flush()
            .map_err(NetworkError::FileWriteError)?;

        Ok(())
    }

    /// Log info level message
    pub async fn info(&self, component: &str, message: &str) {
        self.log("INFO", component, message).await;
    }

    /// Log warning level message
    pub async fn warn(&self, component: &str, message: &str) {
        self.log("WARN", component, message).await;
    }

    /// Log error level message
    pub async fn error(&self, component: &str, message: &str) {
        self.log("ERROR", component, message).await;
    }

    /// Log debug level message
    pub async fn debug(&self, component: &str, message: &str) {
        self.log("DEBUG", component, message).await;
    }

    /// Synchronous convenience methods for non-async contexts
    
    /// Log info level message synchronously
    pub fn info_sync(&self, component: &str, message: &str) {
        self.log_sync("INFO", component, message);
    }

    /// Log warning level message synchronously
    pub fn warn_sync(&self, component: &str, message: &str) {
        self.log_sync("WARN", component, message);
    }

    /// Log error level message synchronously
    pub fn error_sync(&self, component: &str, message: &str) {
        self.log_sync("ERROR", component, message);
    }

    /// Log debug level message synchronously
    pub fn debug_sync(&self, component: &str, message: &str) {
        self.log_sync("DEBUG", component, message);
    }

    /// Log monitoring engine lifecycle events
    pub async fn log_engine_event(&self, event: &str, details: &str) {
        self.info("MonitoringEngine", &format!("{}: {}", event, details)).await;
    }

    /// Log credential operations
    pub async fn log_credential_event(&self, event: &str, source: &str, success: bool) {
        let level = if success { "INFO" } else { "WARN" };
        let message = format!("{}: {} (success={})", event, source, success);
        self.log(level, "Credentials", &message).await;
    }

    /// Log status file operations with timing
    pub async fn log_status_file_event(&self, operation: &str, file_path: &str, success: bool, elapsed_ms: Option<u64>) {
        let timing = elapsed_ms.map(|ms| format!(" ({} ms)", ms)).unwrap_or_default();
        let level = if success { "DEBUG" } else { "ERROR" };
        let message = format!("{}: {} (success={}){}", operation, file_path, success, timing);
        self.log(level, "StatusFile", &message).await;
    }

    /// Log health check operations
    pub async fn log_health_check(&self, endpoint: &str, status_code: Option<u16>, latency_ms: u64, error: Option<&str>) {
        let status_info = status_code
            .map(|code| format!("HTTP {}", code))
            .unwrap_or_else(|| "Network Error".to_string());
        
        let error_info = error
            .map(|e| format!(" ({})", e))
            .unwrap_or_default();

        let message = format!("Health check: {} -> {} in {}ms{}", endpoint, status_info, latency_ms, error_info);
        
        let level = match (status_code, error) {
            (Some(code), None) if (200..300).contains(&code) => "DEBUG",
            (Some(code), None) if (400..500).contains(&code) => "WARN",
            _ => "ERROR",
        };
        
        self.log(level, "HealthCheck", &message).await;
    }

    /// Log initialization timeout events
    #[allow(dead_code)] // Used in external test files
    pub async fn log_init_timeout(&self, timeout_ms: u64, component: &str) {
        self.warn("Initialization", &format!("{} initialization timed out after {} ms", component, timeout_ms)).await;
    }

    /// Log status transitions
    pub async fn log_status_transition(&self, from: &str, to: &str, reason: &str) {
        self.info("StatusTransition", &format!("{} -> {} ({})", from, to, reason)).await;
    }

    /// Get debug log summary for troubleshooting
    #[allow(dead_code)] // Used in external test files
    pub async fn get_log_summary(&self) -> Option<String> {
        if !self.enabled {
            return None;
        }

        let summary = format!(
            "Debug logging enabled\nCCSTATUS_DEBUG=1\nLog file: {:?}\nTimestamp: {}",
            self.log_file_path,
            Local::now().format("%Y-%m-%d %H:%M:%S")
        );

        Some(summary)
    }

    /// Log runtime creation with thread configuration details
    pub fn log_runtime_creation_sync(&self, runtime_name: &str, thread_count: usize, success: bool, error: Option<&str>) {
        let error_info = error.map(|e| format!(" ({})", e)).unwrap_or_default();
        let level = if success { "INFO" } else { "ERROR" };
        let message = format!(
            "Runtime Created: {} - {} threads, success={}{}", 
            runtime_name, thread_count, success, error_info
        );
        self.log_sync(level, "RuntimeManager", &message);
    }

    /// Log async operation timing to detect potential hangs/deadlocks
    pub async fn log_async_operation_timing(&self, operation: &str, elapsed_ms: u64, threshold_ms: u64) {
        let level = if elapsed_ms > threshold_ms { "WARN" } else { "DEBUG" };
        let status = if elapsed_ms > threshold_ms { "SLOW" } else { "OK" };
        let message = format!(
            "Async Operation: {} took {}ms (threshold: {}ms) - {}", 
            operation, elapsed_ms, threshold_ms, status
        );
        self.log(level, "AsyncMonitor", &message).await;
    }

    /// Log async operation timing synchronously
    pub fn log_async_operation_timing_sync(&self, operation: &str, elapsed_ms: u64, threshold_ms: u64) {
        let level = if elapsed_ms > threshold_ms { "WARN" } else { "DEBUG" };
        let status = if elapsed_ms > threshold_ms { "SLOW" } else { "OK" };
        let message = format!(
            "Async Operation: {} took {}ms (threshold: {}ms) - {}", 
            operation, elapsed_ms, threshold_ms, status
        );
        self.log_sync(level, "AsyncMonitor", &message);
    }

    /// Log potential deadlock detection 
    pub async fn log_deadlock_detection(&self, operation: &str, timeout_ms: u64, context: &str) {
        let message = format!(
            "Potential Deadlock: {} timed out after {}ms in context: {}", 
            operation, timeout_ms, context
        );
        self.log("ERROR", "DeadlockDetector", &message).await;
    }

    /// Log potential deadlock detection synchronously
    pub fn log_deadlock_detection_sync(&self, operation: &str, timeout_ms: u64, context: &str) {
        let message = format!(
            "Potential Deadlock: {} timed out after {}ms in context: {}", 
            operation, timeout_ms, context
        );
        self.log_sync("ERROR", "DeadlockDetector", &message);
    }

    /// Log runtime health metrics
    pub async fn log_runtime_health(&self, runtime_name: &str, active_tasks: usize, worker_threads: usize) {
        let message = format!(
            "Runtime Health: {} - {} active tasks, {} worker threads", 
            runtime_name, active_tasks, worker_threads
        );
        self.log("DEBUG", "RuntimeHealth", &message).await;
    }

    /// Log blocking operation warnings (operations that might cause deadlocks)
    pub async fn log_blocking_operation_warning(&self, operation: &str, duration_ms: u64) {
        let message = format!(
            "Blocking Operation Warning: {} blocked for {}ms - potential deadlock risk", 
            operation, duration_ms
        );
        self.log("WARN", "BlockingDetector", &message).await;
    }

    /// Log blocking operation warnings synchronously
    pub fn log_blocking_operation_warning_sync(&self, operation: &str, duration_ms: u64) {
        let message = format!(
            "Blocking Operation Warning: {} blocked for {}ms - potential deadlock risk", 
            operation, duration_ms
        );
        self.log_sync("WARN", "BlockingDetector", &message);
    }

    /// Log thread pool starvation detection
    pub async fn log_thread_starvation(&self, runtime_name: &str, waiting_tasks: usize, threshold: usize) {
        let message = format!(
            "Thread Starvation: {} has {} waiting tasks (threshold: {}) - possible resource contention", 
            runtime_name, waiting_tasks, threshold
        );
        self.log("WARN", "ThreadStarvation", &message).await;
    }

    /// Log async timeout events with recovery information
    pub async fn log_async_timeout(&self, operation: &str, timeout_ms: u64, recovery_action: &str) {
        let message = format!(
            "Async Timeout: {} exceeded {}ms timeout, recovery: {}", 
            operation, timeout_ms, recovery_action
        );
        self.log("WARN", "AsyncTimeout", &message).await;
    }

    /// Log async timeout events synchronously  
    pub fn log_async_timeout_sync(&self, operation: &str, timeout_ms: u64, recovery_action: &str) {
        let message = format!(
            "Async Timeout: {} exceeded {}ms timeout, recovery: {}", 
            operation, timeout_ms, recovery_action
        );
        self.log_sync("WARN", "AsyncTimeout", &message);
    }
}

impl Default for DebugLogger {
    fn default() -> Self {
        Self::new()
    }
}

/// Global debug logger instance
static mut GLOBAL_LOGGER: Option<DebugLogger> = None;
static LOGGER_INIT: std::sync::Once = std::sync::Once::new();

/// Get global debug logger instance
pub fn get_debug_logger() -> &'static DebugLogger {
    unsafe {
        LOGGER_INIT.call_once(|| {
            GLOBAL_LOGGER = Some(DebugLogger::new());
        });
        #[allow(static_mut_refs)] // Using safe singleton pattern with Once
        GLOBAL_LOGGER.as_ref().unwrap()
    }
}

/// Convenience macro for debug logging
#[macro_export]
macro_rules! debug_log {
    ($level:expr, $component:expr, $($arg:tt)*) => {{
        let logger = $crate::core::segments::network::debug_logger::get_debug_logger();
        if logger.is_enabled() {
            let message = format!($($arg)*);
            tokio::spawn(async move {
                logger.log($level, $component, &message).await;
            });
        }
    }};
}

/// Convenience macros for different log levels
#[macro_export]
macro_rules! debug_info {
    ($component:expr, $($arg:tt)*) => {
        debug_log!("INFO", $component, $($arg)*)
    };
}

#[macro_export]
macro_rules! debug_warn {
    ($component:expr, $($arg:tt)*) => {
        debug_log!("WARN", $component, $($arg)*)
    };
}

#[macro_export]
macro_rules! debug_error {
    ($component:expr, $($arg:tt)*) => {
        debug_log!("ERROR", $component, $($arg)*)
    };
}

// Tests for this module have been moved to tests/network/debug_logger_tests.rs