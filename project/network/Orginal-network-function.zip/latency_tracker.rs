//! Latency tracking and performance monitoring

use std::collections::VecDeque;
use std::time::Duration;
use std::sync::Arc;
use tokio::sync::RwLock;
use crate::core::segments::network::types::LatencyData;

/// Tracks latency data for performance monitoring
pub struct LatencyTracker {
    recent_samples: Arc<RwLock<VecDeque<LatencyData>>>,
}

impl LatencyTracker {
    /// Create new latency tracker
    pub fn new() -> Self {
        Self {
            recent_samples: Arc::new(RwLock::new(VecDeque::with_capacity(100))),
        }
    }
    
    /// Record a latency sample
    pub async fn record(&self, latency: &LatencyData) {
        let mut samples = self.recent_samples.write().await;
        
        // Maintain bounded size
        if samples.len() >= 100 {
            samples.pop_front();
        }
        
        samples.push_back(latency.clone());
    }
    
    /// Get average latency over the specified time window
    pub async fn get_average_latency(&self, _window: Duration) -> Option<Duration> {
        let samples = self.recent_samples.read().await;
        
        if samples.is_empty() {
            return None;
        }
        
        let sum: u64 = samples.iter()
            .map(|s| s.total.as_millis() as u64)
            .sum();
        
        Some(Duration::from_millis(sum / samples.len() as u64))
    }
    
    /// Get the most recent latency sample
    pub async fn get_latest_latency(&self) -> Option<LatencyData> {
        let samples = self.recent_samples.read().await;
        samples.back().cloned()
    }
    
    /// Get percentile latency (e.g., 95th percentile)
    pub async fn get_percentile_latency(&self, percentile: f64) -> Option<Duration> {
        let samples = self.recent_samples.read().await;
        
        if samples.is_empty() {
            return None;
        }
        
        let mut latencies: Vec<u64> = samples.iter()
            .map(|s| s.total.as_millis() as u64)
            .collect();
        
        latencies.sort_unstable();
        
        let index = ((percentile / 100.0) * latencies.len() as f64) as usize;
        let index = index.min(latencies.len() - 1);
        
        Some(Duration::from_millis(latencies[index]))
    }
    
    /// Get sample count
    pub async fn get_sample_count(&self) -> usize {
        let samples = self.recent_samples.read().await;
        samples.len()
    }
    
    /// Clear all samples
    pub async fn clear(&self) {
        let mut samples = self.recent_samples.write().await;
        samples.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn test_latency_tracker_new() {
        let tracker = LatencyTracker::new();
        let count = tracker.get_sample_count().await;
        assert_eq!(count, 0);
    }

    #[tokio::test]
    async fn test_record_and_average() {
        let tracker = LatencyTracker::new();
        
        // Record some latencies
        let latencies = vec![
            Duration::from_millis(100),
            Duration::from_millis(200), 
            Duration::from_millis(150),
        ];
        
        for latency in latencies {
            let data = LatencyData {
                dns: None,
                tcp: None, 
                tls: None,
                ttfb: latency / 2,
                total: latency,
            };
            tracker.record(&data).await;
        }
        
        let average = tracker.get_average_latency(Duration::from_secs(60)).await;
        assert_eq!(average, Some(Duration::from_millis(150)));
        
        let count = tracker.get_sample_count().await;
        assert_eq!(count, 3);
    }

    #[tokio::test]
    async fn test_bounded_size() {
        let tracker = LatencyTracker::new();
        
        // Record more than the maximum capacity
        for i in 0..150 {
            let data = LatencyData {
                dns: None,
                tcp: None, 
                tls: None,
                ttfb: Duration::from_millis(i),
                total: Duration::from_millis(i * 2),
            };
            tracker.record(&data).await;
        }
        
        let count = tracker.get_sample_count().await;
        assert_eq!(count, 100); // Should be bounded to 100
    }

    #[tokio::test]
    async fn test_percentile_calculation() {
        let tracker = LatencyTracker::new();
        
        // Record latencies: 100, 200, 300, 400, 500 ms
        for i in 1..=5 {
            let latency = Duration::from_millis(i * 100);
            let data = LatencyData {
                dns: None,
                tcp: None, 
                tls: None,
                ttfb: latency / 2,
                total: latency,
            };
            tracker.record(&data).await;
        }
        
        let p95 = tracker.get_percentile_latency(95.0).await;
        assert!(p95.is_some());
        assert_eq!(p95.unwrap(), Duration::from_millis(500)); // 95th percentile should be 500ms
        
        let p50 = tracker.get_percentile_latency(50.0).await;
        assert!(p50.is_some());
        assert_eq!(p50.unwrap(), Duration::from_millis(300)); // 50th percentile (median) should be 300ms
    }

    #[tokio::test]
    async fn test_latest_latency() {
        let tracker = LatencyTracker::new();
        
        let data = LatencyData {
            dns: Some(Duration::from_millis(10)),
            tcp: Some(Duration::from_millis(20)), 
            tls: Some(Duration::from_millis(30)),
            ttfb: Duration::from_millis(40),
            total: Duration::from_millis(100),
        };
        tracker.record(&data).await;
        
        let latest = tracker.get_latest_latency().await;
        assert!(latest.is_some());
        assert_eq!(latest.unwrap().total, Duration::from_millis(100));
    }

    #[tokio::test]
    async fn test_clear() {
        let tracker = LatencyTracker::new();
        
        let data = LatencyData {
            dns: None,
            tcp: None, 
            tls: None,
            ttfb: Duration::from_millis(50),
            total: Duration::from_millis(100),
        };
        tracker.record(&data).await;
        
        assert_eq!(tracker.get_sample_count().await, 1);
        
        tracker.clear().await;
        assert_eq!(tracker.get_sample_count().await, 0);
    }
}