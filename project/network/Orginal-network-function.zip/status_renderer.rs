//! Status rendering for network monitoring display
//! 
//! Handles visual representation of network status with emoji indicators and latency details.

use crate::core::segments::network::types::NetworkStatus;

/// Renders network status for display in statusline
pub struct StatusRenderer {
    show_details: bool,
}

impl StatusRenderer {
    /// Create new status renderer
    pub fn new() -> Self {
        Self {
            show_details: true,
        }
    }
    
    /// Create new status renderer with detail configuration
    pub fn with_details(show_details: bool) -> Self {
        Self {
            show_details,
        }
    }
    
    /// Render network status to string
    pub fn render(&self, status: &NetworkStatus) -> String {
        match status {
            NetworkStatus::Healthy => {
                "🟢".to_string()
            }
            
            NetworkStatus::Degraded { reason: _, details } => {
                if self.show_details {
                    format!("🟡 {}", self.format_details(details))
                } else {
                    "🟡".to_string()
                }
            }
            
            NetworkStatus::Error { error_type, details } => {
                if self.show_details {
                    format!("🔴 {} [{}]", self.format_details(details), error_type)
                } else {
                    "🔴".to_string()
                }
            }
            
            NetworkStatus::Unknown => {
                "⚪".to_string()
            }
            
            NetworkStatus::Disabled => {
                String::new()
            }
        }
    }
    
    /// Render compact status (emoji only)
    pub fn render_compact(&self, status: &NetworkStatus) -> String {
        match status {
            NetworkStatus::Healthy => "🟢".to_string(),
            NetworkStatus::Degraded { .. } => "🟡".to_string(),
            NetworkStatus::Error { .. } => "🔴".to_string(),
            NetworkStatus::Unknown => "⚪".to_string(),
            NetworkStatus::Disabled => String::new(),
        }
    }
    
    /// Render verbose status with full details
    pub fn render_verbose(&self, status: &NetworkStatus) -> String {
        match status {
            NetworkStatus::Healthy => {
                "🟢 Network: Healthy".to_string()
            }
            
            NetworkStatus::Degraded { reason, details } => {
                format!("🟡 Network: {} - {}", reason, details)
            }
            
            NetworkStatus::Error { error_type, details } => {
                format!("🔴 Network: {} - {}", error_type, details)
            }
            
            NetworkStatus::Unknown => {
                "⚪ Network: Unknown".to_string()
            }
            
            NetworkStatus::Disabled => {
                "Network: Disabled".to_string()
            }
        }
    }
    
    /// Get status color for terminal coloring
    pub fn get_status_color(&self, status: &NetworkStatus) -> &'static str {
        match status {
            NetworkStatus::Healthy => "green",
            NetworkStatus::Degraded { .. } => "yellow",
            NetworkStatus::Error { .. } => "red",
            NetworkStatus::Unknown => "white",
            NetworkStatus::Disabled => "default",
        }
    }
    
    /// Get status indicator without emoji (for compatibility)
    pub fn get_status_indicator(&self, status: &NetworkStatus) -> &'static str {
        match status {
            NetworkStatus::Healthy => "OK",
            NetworkStatus::Degraded { .. } => "WARN",
            NetworkStatus::Error { .. } => "ERR",
            NetworkStatus::Unknown => "UNK",
            NetworkStatus::Disabled => "",
        }
    }
    
    /// Format latency details for display
    fn format_details(&self, details: &str) -> String {
        // If details contain the breakdown format, make it more readable
        if details.contains("Total:") && details.contains("ms") {
            self.format_latency_breakdown(details)
        } else {
            details.to_string()
        }
    }
    
    /// Format latency breakdown for better readability
    fn format_latency_breakdown(&self, breakdown: &str) -> String {
        // Parse breakdown string like "DNS:reuse|TCP:reuse|TLS:45ms|TTFB:71ms|Total:156ms"
        let parts: Vec<&str> = breakdown.split('|').collect();
        
        // Find the total latency
        if let Some(total_part) = parts.iter().find(|p| p.starts_with("Total:")) {
            if let Some(total_ms) = total_part.strip_prefix("Total:").and_then(|s| s.strip_suffix("ms")) {
                if let Ok(ms) = total_ms.parse::<u32>() {
                    return self.format_latency_ms(ms);
                }
            }
        }
        
        // Fallback to original breakdown if parsing fails
        breakdown.to_string()
    }
    
    /// Format latency in milliseconds with appropriate suffix
    fn format_latency_ms(&self, ms: u32) -> String {
        match ms {
            0..=99 => format!("{}ms", ms),
            100..=999 => format!("{}ms", ms),
            1000..=4999 => format!("{:.1}s", ms as f64 / 1000.0),
            _ => format!("{}s", ms / 1000),
        }
    }
    
    /// Check if status should be displayed (not disabled/empty)
    pub fn should_display(&self, status: &NetworkStatus) -> bool {
        !matches!(status, NetworkStatus::Disabled)
    }
    
    /// Get priority level for status (higher = more important)
    pub fn get_priority(&self, status: &NetworkStatus) -> u8 {
        match status {
            NetworkStatus::Error { .. } => 3,
            NetworkStatus::Degraded { .. } => 2,
            NetworkStatus::Unknown => 1,
            NetworkStatus::Healthy => 1,
            NetworkStatus::Disabled => 0,
        }
    }
}

impl Default for StatusRenderer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_healthy_status_rendering() {
        let renderer = StatusRenderer::new();
        let status = NetworkStatus::Healthy;
        
        assert_eq!(renderer.render(&status), "🟢");
        assert_eq!(renderer.render_compact(&status), "🟢");
        assert_eq!(renderer.render_verbose(&status), "🟢 Network: Healthy");
        assert_eq!(renderer.get_status_color(&status), "green");
        assert_eq!(renderer.get_status_indicator(&status), "OK");
    }

    #[test]
    fn test_degraded_status_rendering() {
        let renderer = StatusRenderer::new();
        let status = NetworkStatus::Degraded {
            reason: "High latency".to_string(),
            details: "Total:250ms".to_string(),
        };
        
        assert_eq!(renderer.render(&status), "🟡 250ms");
        assert_eq!(renderer.render_compact(&status), "🟡");
        assert_eq!(renderer.render_verbose(&status), "🟡 Network: High latency - Total:250ms");
        assert_eq!(renderer.get_status_color(&status), "yellow");
        assert_eq!(renderer.get_status_indicator(&status), "WARN");
    }

    #[test]
    fn test_error_status_rendering() {
        let renderer = StatusRenderer::new();
        let status = NetworkStatus::Error {
            error_type: "NETWORK_TIMEOUT".to_string(),
            details: "Total:5000ms".to_string(),
        };
        
        assert_eq!(renderer.render(&status), "🔴 5s [NETWORK_TIMEOUT]");
        assert_eq!(renderer.render_compact(&status), "🔴");
        assert!(renderer.render_verbose(&status).contains("NETWORK_TIMEOUT"));
        assert_eq!(renderer.get_status_color(&status), "red");
        assert_eq!(renderer.get_status_indicator(&status), "ERR");
    }

    #[test]
    fn test_unknown_status_rendering() {
        let renderer = StatusRenderer::new();
        let status = NetworkStatus::Unknown;
        
        assert_eq!(renderer.render(&status), "⚪");
        assert_eq!(renderer.render_compact(&status), "⚪");
        assert_eq!(renderer.render_verbose(&status), "⚪ Network: Unknown");
        assert_eq!(renderer.get_status_color(&status), "white");
        assert_eq!(renderer.get_status_indicator(&status), "UNK");
    }

    #[test]
    fn test_disabled_status_rendering() {
        let renderer = StatusRenderer::new();
        let status = NetworkStatus::Disabled;
        
        assert_eq!(renderer.render(&status), "");
        assert_eq!(renderer.render_compact(&status), "");
        assert_eq!(renderer.render_verbose(&status), "Network: Disabled");
        assert_eq!(renderer.get_status_color(&status), "default");
        assert_eq!(renderer.get_status_indicator(&status), "");
    }

    #[test]
    fn test_details_disabled() {
        let renderer = StatusRenderer::with_details(false);
        let status = NetworkStatus::Degraded {
            reason: "High latency".to_string(),
            details: "Total:250ms".to_string(),
        };
        
        assert_eq!(renderer.render(&status), "🟡");
    }

    #[test]
    fn test_latency_formatting() {
        let renderer = StatusRenderer::new();
        
        assert_eq!(renderer.format_latency_ms(50), "50ms");
        assert_eq!(renderer.format_latency_ms(150), "150ms");
        assert_eq!(renderer.format_latency_ms(1500), "1.5s");
        assert_eq!(renderer.format_latency_ms(5000), "5s");
        assert_eq!(renderer.format_latency_ms(15000), "15s");
    }

    #[test]
    fn test_latency_breakdown_parsing() {
        let renderer = StatusRenderer::new();
        let breakdown = "DNS:20ms|TCP:30ms|TLS:45ms|TTFB:71ms|Total:166ms";
        
        let formatted = renderer.format_latency_breakdown(breakdown);
        assert_eq!(formatted, "166ms");
    }

    #[test]
    fn test_latency_breakdown_with_reuse() {
        let renderer = StatusRenderer::new();
        let breakdown = "DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms";
        
        let formatted = renderer.format_latency_breakdown(breakdown);
        assert_eq!(formatted, "890ms");
    }

    #[test]
    fn test_should_display() {
        let renderer = StatusRenderer::new();
        
        assert!(renderer.should_display(&NetworkStatus::Healthy));
        assert!(renderer.should_display(&NetworkStatus::Degraded { 
            reason: "test".to_string(), 
            details: "test".to_string() 
        }));
        assert!(renderer.should_display(&NetworkStatus::Error { 
            error_type: "test".to_string(), 
            details: "test".to_string() 
        }));
        assert!(renderer.should_display(&NetworkStatus::Unknown));
        assert!(!renderer.should_display(&NetworkStatus::Disabled));
    }

    #[test]
    fn test_priority_ordering() {
        let renderer = StatusRenderer::new();
        
        // Error should have the highest priority
        assert!(renderer.get_priority(&NetworkStatus::Error { 
            error_type: "test".to_string(), 
            details: "test".to_string() 
        }) > renderer.get_priority(&NetworkStatus::Degraded { 
            reason: "test".to_string(), 
            details: "test".to_string() 
        }));
        
        // Degraded should have higher priority than healthy
        assert!(renderer.get_priority(&NetworkStatus::Degraded { 
            reason: "test".to_string(), 
            details: "test".to_string() 
        }) > renderer.get_priority(&NetworkStatus::Healthy));
        
        // Disabled should have the lowest priority
        assert_eq!(renderer.get_priority(&NetworkStatus::Disabled), 0);
    }
}