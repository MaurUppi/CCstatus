//! Shell configuration file reader for credential extraction
//! 
//! Reads shell configuration files to extract exported environment variables
//! for API credentials when they're not available in the process environment.

use std::path::{Path, PathBuf};
use std::env;
use tokio::fs;
use regex::Regex;
use crate::core::segments::network::types::{ApiCredentials, CredentialSource, NetworkError};

/// Shell types supported for config reading
#[derive(Debug, Clone)]
pub enum ShellType {
    Zsh,
    Bash,
    PowerShell,
    Unknown,
}

/// Reads credentials from shell configuration files
pub struct ShellConfigReader {
    shell_type: ShellType,
    config_paths: Vec<PathBuf>,
}

impl ShellConfigReader {
    /// Helper function to process ANTHROPIC environment variables
    fn process_anthropic_variable(
        var_name: Option<&str>,
        var_value: String,
        base_url: &mut Option<String>,
        auth_token: &mut Option<String>,
    ) {
        match var_name {
            Some("ANTHROPIC_BASE_URL") => {
                *base_url = Some(var_value);
            },
            Some("ANTHROPIC_AUTH_TOKEN") => {
                *auth_token = Some(var_value);
            },
            _ => {}
        }
    }
    
    /// Helper function to process regex captures for PowerShell environment variables
    fn process_powershell_regex_captures(
        regex: &Regex,
        line: &str,
        base_url: &mut Option<String>,
        auth_token: &mut Option<String>,
    ) {
        if let Some(captures) = regex.captures(line) {
            let var_name = captures.get(1).map(|m| m.as_str());
            let var_value = captures.get(2).map(|m| m.as_str().to_string());
            
            if let Some(value) = var_value {
                Self::process_anthropic_variable(var_name, value, base_url, auth_token);
            }
        }
    }
    
    /// Create new shell config reader with auto-detection
    pub fn new() -> Result<Self, NetworkError> {
        let shell_type = Self::detect_shell();
        let config_paths = Self::get_config_paths(&shell_type)?;
        
        Ok(Self {
            shell_type,
            config_paths,
        })
    }
    
    /// Detect the current shell type
    fn detect_shell() -> ShellType {
        // Check SHELL environment variable first
        if let Ok(shell) = env::var("SHELL") {
            if shell.contains("zsh") {
                return ShellType::Zsh;
            } else if shell.contains("bash") {
                return ShellType::Bash;
            }
        }
        
        // Check for Windows
        if cfg!(target_os = "windows") {
            return ShellType::PowerShell;
        }
        
        // Default based on OS
        if cfg!(target_os = "macos") {
            ShellType::Zsh  // macOS defaults to zsh
        } else if cfg!(target_os = "linux") {
            ShellType::Bash  // Linux commonly uses bash
        } else {
            ShellType::Unknown
        }
    }
    
    /// Get configuration file paths based on shell type
    fn get_config_paths(shell_type: &ShellType) -> Result<Vec<PathBuf>, NetworkError> {
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        let home_path = PathBuf::from(home);
        
        let paths = match shell_type {
            ShellType::Zsh => vec![
                home_path.join(".zshrc"),
                home_path.join(".zshenv"),
                home_path.join(".zprofile"),
            ],
            ShellType::Bash => vec![
                home_path.join(".bashrc"),
                home_path.join(".bash_profile"),
                home_path.join(".profile"),
            ],
            ShellType::PowerShell => {
                // PowerShell profiles on Windows
                let mut ps_paths = vec![];
                
                // User profile
                if let Ok(ps_home) = env::var("USERPROFILE") {
                    let ps_home_path = PathBuf::from(ps_home);
                    ps_paths.push(ps_home_path.join("Documents")
                        .join("WindowsPowerShell")
                        .join("Microsoft.PowerShell_profile.ps1"));
                    ps_paths.push(ps_home_path.join("Documents")
                        .join("PowerShell")
                        .join("Microsoft.PowerShell_profile.ps1"));
                }
                
                ps_paths
            },
            ShellType::Unknown => vec![],
        };
        
        Ok(paths)
    }
    
    /// Try to get credentials from shell config files
    pub async fn get_credentials(&self) -> Result<Option<ApiCredentials>, NetworkError> {
        for config_path in &self.config_paths {
            if let Some(creds) = self.read_credentials_from_file(config_path).await? {
                return Ok(Some(creds));
            }
        }
        
        Ok(None)
    }
    
    /// Read credentials from a specific shell config file
    async fn read_credentials_from_file(&self, path: &PathBuf) -> Result<Option<ApiCredentials>, NetworkError> {
        if !path.exists() {
            return Ok(None);
        }
        
        let content = fs::read_to_string(path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        match self.shell_type {
            ShellType::Zsh | ShellType::Bash => {
                self.parse_shell_config(&content, path)
            },
            ShellType::PowerShell => {
                self.parse_powershell_config(&content, path)
            },
            ShellType::Unknown => Ok(None),
        }
    }
    
    /// Parse bash/zsh config file for exported environment variables and function-based definitions
    fn parse_shell_config(&self, content: &str, source_path: &Path) -> Result<Option<ApiCredentials>, NetworkError> {
        // Phase 1: Look for traditional export statements
        if let Some(creds) = self.parse_export_statements(content)? {
            return Ok(Some(ApiCredentials {
                base_url: creds.0,
                auth_token: creds.1,
                source: CredentialSource::ShellConfig(source_path.to_path_buf()),
            }));
        }
        
        // Phase 2: Look for function-based variable definitions (like cc-env)
        if let Some(creds) = self.parse_function_variables(content)? {
            return Ok(Some(ApiCredentials {
                base_url: creds.0,
                auth_token: creds.1,
                source: CredentialSource::ShellConfig(source_path.to_path_buf()),
            }));
        }
        
        Ok(None)
    }
    
    /// Parse traditional export statements
    fn parse_export_statements(&self, content: &str) -> Result<Option<(String, String)>, NetworkError> {
        // Enhanced regex to match export statements
        // Matches: export VAR="value" or export VAR='value' or export VAR=value
        let export_regex = Regex::new(r#"^\s*export\s+([A-Z_]+)=(["']?)([^\n\r]+)"#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        
        let mut base_url: Option<String> = None;
        let mut auth_token: Option<String> = None;
        
        for line in content.lines() {
            // Skip comments
            if line.trim_start().starts_with('#') {
                continue;
            }
            
            if let Some(captures) = export_regex.captures(line) {
                let var_name = captures.get(1).map(|m| m.as_str());
                let quote_char = captures.get(2).map(|m| m.as_str()).unwrap_or("");
                let raw_value = captures.get(3).map(|m| m.as_str()).unwrap_or("");
                
                // Remove matching quotes if present
                let var_value = if !quote_char.is_empty() && raw_value.ends_with(quote_char) {
                    raw_value.trim_end_matches(quote_char).to_string()
                } else {
                    raw_value.to_string()
                };
                
                Self::process_anthropic_variable(var_name, var_value, &mut base_url, &mut auth_token);
            }
        }
        
        // Check if we have complete credentials
        if let (Some(url), Some(token)) = (base_url, auth_token) {
            return Ok(Some((url, token)));
        }
        
        Ok(None)
    }
    
    /// Parse function-based variable definitions (like cc-env pattern)
    fn parse_function_variables(&self, content: &str) -> Result<Option<(String, String)>, NetworkError> {
        // Regex to detect function definitions
        let function_regex = Regex::new(r#"^\s*(function\s+)?([a-zA-Z_][a-zA-Z0-9_-]*)\s*\(\s*\)\s*\{"#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        
        // Regex to detect array assignments within functions
        let array_start_regex = Regex::new(r#"^\s*local\s+[a-zA-Z_][a-zA-Z0-9_]*\s*=\s*\("#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        
        // Regex to extract ANTHROPIC variables from array elements
        // Matches: "ANTHROPIC_BASE_URL=value" or 'ANTHROPIC_BASE_URL=value' or ANTHROPIC_BASE_URL=value
        let var_regex = Regex::new(r#"^\s*(["']?)(ANTHROPIC_(?:BASE_URL|AUTH_TOKEN))=([^\n\r]+)"#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        
        let lines: Vec<&str> = content.lines().collect();
        let mut i = 0;
        
        while i < lines.len() {
            let line = lines[i];
            
            // Skip comments
            if line.trim_start().starts_with('#') {
                i += 1;
                continue;
            }
            
            // Check if this line starts a function definition
            if function_regex.is_match(line) {
                i += 1;
                
                // Look for array assignments within this function
                while i < lines.len() {
                    let func_line = lines[i];
                    
                    // Stop if we hit the end of function (closing brace at start of line)
                    if func_line.trim_start().starts_with('}') {
                        break;
                    }
                    
                    // Check if this line starts an array assignment
                    if array_start_regex.is_match(func_line) {
                        i += 1;
                        
                        // Parse array elements until we find closing parenthesis
                        let mut base_url: Option<String> = None;
                        let mut auth_token: Option<String> = None;
                        
                        while i < lines.len() {
                            let array_line = lines[i];
                            
                            // Stop if we hit closing parenthesis
                            if array_line.trim().starts_with(')') {
                                break;
                            }
                            
                            // Check for ANTHROPIC variables in this array element
                            if let Some(captures) = var_regex.captures(array_line) {
                                let quote_char = captures.get(1).map(|m| m.as_str()).unwrap_or("");
                                let var_name = captures.get(2).map(|m| m.as_str());
                                let raw_value = captures.get(3).map(|m| m.as_str()).unwrap_or("");
                                
                                // Remove matching quotes if present
                                let var_value = if !quote_char.is_empty() && raw_value.ends_with(quote_char) {
                                    raw_value.trim_end_matches(quote_char).to_string()
                                } else {
                                    raw_value.to_string()
                                };
                                
                                Self::process_anthropic_variable(var_name, var_value, &mut base_url, &mut auth_token);
                            }
                            
                            i += 1;
                        }
                        
                        // If we found both credentials in this array, return them
                        if let (Some(url), Some(token)) = (base_url, auth_token) {
                            return Ok(Some((url, token)));
                        }
                    }
                    
                    i += 1;
                }
            } else {
                i += 1;
            }
        }
        
        Ok(None)
    }
    
    /// Parse PowerShell config file for environment variables
    fn parse_powershell_config(&self, content: &str, source_path: &Path) -> Result<Option<ApiCredentials>, NetworkError> {
        // Regex for PowerShell environment variable setting
        // Matches: $env:VAR = "value" or [Environment]::SetEnvironmentVariable("VAR", "value", ...)
        let env_regex = Regex::new(r#"\$env:([A-Z_]+)\s*=\s*["']([^"']+)["']"#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        let setenv_regex = Regex::new(r#"\[.*Environment.*]::SetEnvironmentVariable\s*\(\s*["']([A-Z_]+)["']\s*,\s*["']([^"']+)["']"#)
            .map_err(|e| NetworkError::RegexError(e.to_string()))?;
        
        let mut base_url: Option<String> = None;
        let mut auth_token: Option<String> = None;
        
        for line in content.lines() {
            // Skip comments
            if line.trim_start().starts_with('#') {
                continue;
            }
            
            // Check $env: syntax
            Self::process_powershell_regex_captures(&env_regex, line, &mut base_url, &mut auth_token);
            
            // Check SetEnvironmentVariable syntax
            Self::process_powershell_regex_captures(&setenv_regex, line, &mut base_url, &mut auth_token);
        }
        
        // Check if we have complete credentials
        if let (Some(url), Some(token)) = (base_url, auth_token) {
            return Ok(Some(ApiCredentials {
                base_url: url,
                auth_token: token,
                source: CredentialSource::ShellConfig(source_path.to_path_buf()),
            }));
        }
        
        Ok(None)
    }
    
}

