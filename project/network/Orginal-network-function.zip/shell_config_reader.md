# ShellConfigReader Module Documentation

## Overview

The `ShellConfigReader` is a sophisticated cross-platform shell configuration parser designed to extract API credentials from user shell configuration files. It serves as a secondary credential source in the CCStatus network monitoring system, providing fallback credential resolution when environment variables are not available. The module supports multiple shell types (Bash, Zsh, PowerShell) and implements advanced parsing algorithms to handle complex shell configuration patterns.

## Architecture

### Core Components

```rust
/// Shell types supported for config reading
#[derive(Debug, Clone)]
pub enum ShellType {
    Zsh,
    Bash,
    PowerShell,
    Unknown,
}

/// Reads credentials from shell configuration files
pub struct ShellConfigReader {
    shell_type: ShellType,
    config_paths: Vec<PathBuf>,
}
```

### Design Philosophy

The ShellConfigReader follows a multi-layered parsing strategy:
1. **Auto-detection**: Automatically detects the current shell environment
2. **Multi-format parsing**: Supports various credential declaration patterns
3. **Platform awareness**: Handles OS-specific configuration file locations
4. **Fail-safe operation**: Gracefully handles missing files and parsing errors

## Public Interface

### Constructor

```rust
pub fn new() -> Result<Self, NetworkError>
```

**Purpose**: Creates a new ShellConfigReader with automatic shell detection and configuration path resolution.

**Auto-Detection Logic**:
1. Examines `SHELL` environment variable for zsh/bash detection
2. Uses platform-specific defaults:
   - macOS: defaults to Zsh
   - Linux: defaults to Bash  
   - Windows: defaults to PowerShell
3. Falls back to `Unknown` for unsupported platforms

**Configuration Paths by Shell Type**:

- **Zsh**: `~/.zshrc`, `~/.zshenv`, `~/.zprofile`
- **Bash**: `~/.bashrc`, `~/.bash_profile`, `~/.profile`
- **PowerShell**: 
  - `%USERPROFILE%\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1`
  - `%USERPROFILE%\Documents\PowerShell\Microsoft.PowerShell_profile.ps1`

**Error Conditions**:
- Returns `NetworkError::HomeDirNotFound` if home directory cannot be determined

### Primary Method

```rust
pub async fn get_credentials(&self) -> Result<Option<ApiCredentials>, NetworkError>
```

**Purpose**: Asynchronously searches configuration files for ANTHROPIC API credentials.

**Search Strategy**:
- Iterates through configuration paths in priority order
- Returns first complete credential set found (both base_url and auth_token)
- Stops searching after finding valid credentials

**Return Values**:
- `Ok(Some(ApiCredentials))` - Complete credentials found
- `Ok(None)` - No credentials found in any configuration file
- `Err(NetworkError)` - File I/O or parsing error

## Parsing Algorithms

### Unix Shell Parsing (Bash/Zsh)

The module implements **two-phase parsing** for Unix shells:

#### Phase 1: Traditional Export Statements

**Supported Formats**:
```bash
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN='your_token_here'
export ANTHROPIC_BASE_URL=https://api.anthropic.com
```

**Regex Pattern**: 
```rust
r#"^\\s*export\\s+([A-Z_]+)=([\"']?)([^\\n\\r]+)"#
```

**Features**:
- Handles quoted and unquoted values
- Supports both double quotes (`"`) and single quotes (`'`)
- Properly strips matching quotes
- Skips comment lines (starting with `#`)

#### Phase 2: Function-Based Variable Definitions

**Purpose**: Parses complex shell functions that define credentials in arrays (e.g., Claude Code's `cc-env` pattern).

**Supported Pattern**:
```bash
function cc-env() {
    local env_vars=(
        "ANTHROPIC_BASE_URL=https://api.anthropic.com"
        "ANTHROPIC_AUTH_TOKEN=your_token_here"
    )
    # ... rest of function
}
```

**Parsing Algorithm**:
1. **Function Detection**: Uses regex to identify function definitions
2. **Array Locating**: Finds `local variable = (` patterns within functions
3. **Element Parsing**: Extracts ANTHROPIC variables from array elements
4. **Quote Handling**: Properly processes quoted and unquoted array elements

**Regex Patterns**:
- Function detection: `r#"^\\s*(function\\s+)?([a-zA-Z_][a-zA-Z0-9_-]*)\\s*\\(\\s*\\)\\s*\\{"#`
- Array start: `r#"^\\s*local\\s+[a-zA-Z_][a-zA-Z0-9_]*\\s*=\\s*\\("#`
- Variable extraction: `r#"^\\s*([\"']?)(ANTHROPIC_(?:BASE_URL|AUTH_TOKEN))=([^\\n\\r]+)"#`

### PowerShell Parsing

**Supported Formats**:
```powershell
$env:ANTHROPIC_BASE_URL = "https://api.anthropic.com"
$env:ANTHROPIC_AUTH_TOKEN = 'your_token_here'

[Environment]::SetEnvironmentVariable("ANTHROPIC_BASE_URL", "https://api.anthropic.com", "User")
[Environment]::SetEnvironmentVariable("ANTHROPIC_AUTH_TOKEN", "your_token_here", "User")
```

**Regex Patterns**:
- `$env:` syntax: `r#"\\$env:([A-Z_]+)\\s*=\\s*[\"']([^\"']+)[\"']"#`
- `SetEnvironmentVariable`: `r#"\\[.*Environment.*]::SetEnvironmentVariable\\s*\\(\\s*[\"']([A-Z_]+)[\"']\\s*,\\s*[\"']([^\"']+)[\"']"#`

**Features**:
- Handles both `$env:` and `[Environment]::` syntax patterns
- Supports nested namespaces in Environment class references
- Processes quoted string values only (PowerShell best practice)

## Data Types

### ApiCredentials

```rust
pub struct ApiCredentials {
    pub base_url: String,
    pub auth_token: String,
    pub source: CredentialSource,
}
```

The returned credentials include source tracking via `CredentialSource::ShellConfig(PathBuf)` for audit and troubleshooting purposes.

### ShellType Variants

- **`Zsh`**: Z shell (default on macOS)
- **`Bash`**: Bourne Again Shell (default on Linux)
- **`PowerShell`**: Microsoft PowerShell (default on Windows)
- **`Unknown`**: Unsupported or undetected shell

## Error Handling

### Error Categories

**System Errors**:
- `NetworkError::HomeDirNotFound`: Cannot determine user home directory
- `NetworkError::ConfigReadError(tokio::io::Error)`: File I/O failure
- `NetworkError::RegexError(String)`: Regex compilation failure

**Error Handling Strategy**:
- **Fail-fast on regex errors**: Indicates programming bugs
- **Fail-soft on file errors**: Missing configuration files are expected
- **Graceful degradation**: Returns `None` when no credentials found

### Edge Cases Handled

1. **Missing Configuration Files**: Silently skipped, not treated as errors
2. **Malformed Configuration**: Individual parsing failures don't stop the search
3. **Partial Credentials**: Only complete credential sets are returned
4. **Comment Lines**: Properly ignored in all shell types
5. **Quote Mismatches**: Handled gracefully without crashing
6. **Large Files**: Line-by-line processing prevents memory exhaustion

## Integration Points

### CredentialManager Integration

The ShellConfigReader is primarily used by `CredentialManager` as a secondary credential source:

```rust
// From CredentialManager::get_credentials()
match ShellConfigReader::new() {
    Ok(shell_reader) => {
        match shell_reader.get_credentials().await {
            Ok(Some(creds)) => return Ok(Some(creds)),
            Ok(None) => {}, // Continue to next source
            Err(e) => {} // Log error, continue
        }
    },
    Err(e) => {} // Handle creation error
}
```

**Location**: `src/core/segments/network/credential_manager.rs:69`

### Test Coverage

Comprehensive test coverage in `tests/network/shell_config_reader_tests.rs`:
- Shell detection validation
- Configuration file parsing
- Error condition handling
- Real-world configuration file testing

## Performance Characteristics

### Algorithmic Complexity

- **File Search**: O(n) where n = number of configuration files (typically 2-3)
- **Parsing**: O(m) where m = file size in lines
- **Memory Usage**: O(1) - line-by-line processing, no large data structures

### Optimization Features

1. **Early Termination**: Stops at first successful credential extraction
2. **Async I/O**: Non-blocking file operations for UI responsiveness
3. **Minimal Memory Footprint**: Processes files line-by-line
4. **Regex Compilation Caching**: Compiles patterns once per parsing session

### Performance Considerations

- **File I/O Bound**: Performance primarily limited by disk access
- **Regex Performance**: Uses non-backtracking patterns where possible
- **Memory Efficient**: Suitable for resource-constrained environments

## Security Considerations

### Security Features

1. **Path Safety**: Only accesses files within user's home directory
2. **No Privilege Escalation**: Operates with user-level permissions only
3. **Safe Parsing**: Regex patterns designed to prevent ReDoS attacks
4. **No Credential Logging**: Only processes credentials, never logs values

### Attack Surface Analysis

**Minimal Attack Vectors**:
- File system access limited to user's configuration files
- Regex patterns use bounded quantifiers
- No shell command execution
- No network operations

**Security Best Practices**:
- Validates file paths before access
- Uses safe string processing functions
- Implements fail-safe error handling

## Advanced Features

### Multi-format Support

The parser handles various credential declaration styles:

**Traditional Unix Style**:
```bash
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN="sk-..."
```

**Function-based Style (cc-env pattern)**:
```bash
function setup-claude() {
    local credentials=(
        "ANTHROPIC_BASE_URL=https://api.anthropic.com"
        "ANTHROPIC_AUTH_TOKEN=sk-..."
    )
}
```

**PowerShell Styles**:
```powershell
$env:ANTHROPIC_BASE_URL = "https://api.anthropic.com"
[Environment]::SetEnvironmentVariable("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
```

### Quote Handling Algorithm

Sophisticated quote processing handles various scenarios:

```rust
// Handles: "value", 'value', value
let var_value = if !quote_char.is_empty() && raw_value.ends_with(quote_char) {
    raw_value.trim_end_matches(quote_char).to_string()
} else {
    raw_value.to_string()
};
```

## Troubleshooting

### Common Issues

1. **No Credentials Found**
   - Verify configuration files exist in expected locations
   - Check credential format matches supported patterns
   - Ensure complete credential pairs (both base_url and token)

2. **Shell Detection Issues**
   - Manually verify `SHELL` environment variable
   - Check platform-specific defaults are appropriate
   - Consider using explicit shell configuration

3. **Parsing Failures**
   - Validate shell configuration syntax
   - Check for unsupported quote patterns
   - Verify credentials are not in comment sections

### Debug Information

Enable debug logging in CredentialManager to see ShellConfigReader activity:

```bash
CCSTATUS_DEBUG=1 ccstatus
```

Expected output patterns:
```
ShellConfigReader created successfully
ShellConfigReader returned None (no credentials found in shell configs)
```

### Configuration Validation

**Valid Configuration Examples**:

```bash
# .zshrc / .bashrc
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN="sk-your-token-here"
```

```powershell
# Microsoft.PowerShell_profile.ps1
$env:ANTHROPIC_BASE_URL = "https://api.anthropic.com"
$env:ANTHROPIC_AUTH_TOKEN = "sk-your-token-here"
```

## Extensibility

### Adding New Shell Types

1. **Extend ShellType Enum**:
```rust
pub enum ShellType {
    Zsh,
    Bash,
    PowerShell,
    Fish,     // New shell
    Unknown,
}
```

2. **Update Detection Logic**:
```rust
fn detect_shell() -> ShellType {
    if let Ok(shell) = env::var("SHELL") {
        if shell.contains("fish") {
            return ShellType::Fish;
        }
        // ... existing logic
    }
}
```

3. **Add Configuration Paths**:
```rust
ShellType::Fish => vec![
    home_path.join(".config/fish/config.fish"),
],
```

4. **Implement Parsing Logic**:
```rust
ShellType::Fish => {
    self.parse_fish_config(&content, path)
},
```

### Adding New Credential Formats

Extend existing parsing methods or create new ones:

```rust
fn parse_new_format(&self, content: &str) -> Result<Option<(String, String)>, NetworkError> {
    // New parsing logic
}
```

### Custom Configuration Sources

The module can be extended to support additional configuration sources:

```rust
// Potential extensions
fn get_custom_paths() -> Vec<PathBuf> {
    // IDE-specific configuration files
    // Docker environment files
    // Kubernetes secrets
}
```

## Dependencies

### Required Crates

- `tokio` - Async runtime and file I/O operations
- `regex` - Pattern matching and text extraction
- `std::path` - File system path manipulation
- `std::env` - Environment variable access

### Internal Dependencies

- `crate::core::segments::network::types` - Type definitions
- File system operations via `tokio::fs`

## Compatibility

### Platform Support

- **macOS**: Full support (Zsh primary, Bash secondary)
- **Linux**: Full support (Bash primary, Zsh secondary) 
- **Windows**: PowerShell support
- **Other Unix**: Basic support via Unknown shell type

### Shell Version Compatibility

- **Bash**: Compatible with Bash 3.0+
- **Zsh**: Compatible with Zsh 4.0+
- **PowerShell**: Compatible with PowerShell 5.0+ and PowerShell Core

---

*This documentation covers the ShellConfigReader module as implemented in `src/core/segments/network/shell_config_reader.rs`. The module serves as a critical component in the CCStatus credential resolution system, providing robust cross-platform shell configuration parsing capabilities.*