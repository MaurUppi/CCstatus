# CredentialManager Module Documentation

## Overview

The `CredentialManager` is a critical security component in the CCStatus network monitoring system responsible for secure credential resolution from multiple sources. It implements a hierarchical credential lookup system with comprehensive error handling and logging for API authentication with Claude Code services.

## Architecture

### Core Structure

```rust
pub struct CredentialManager {
    claude_config_paths: Vec<PathBuf>,
}
```

The CredentialManager follows a minimalist design with a single field containing pre-configured paths to Claude Code configuration files. The simplicity of the structure belies the sophisticated credential resolution logic implemented in its methods.

### Key Dependencies

- **Types**: `ApiCredentials`, `CredentialSource`, `NetworkError`
- **External Integration**: `ShellConfigReader` for shell configuration parsing
- **Logging**: Integrated with `debug_logger` for comprehensive observability
- **I/O**: Async file operations via `tokio::fs`

## Public Interface

### Constructor

```rust
pub fn new() -> Result<Self, NetworkError>
```

**Purpose**: Creates a new CredentialManager instance with predefined configuration file paths.

**Behavior**:
- Determines user home directory from `HOME` or `USERPROFILE` environment variables
- Configures three credential file paths:
  - `~/.claude/settings.json`
  - `.claude/settings.local.json` 
  - `.claude/settings.json`

**Error Conditions**:
- Returns `NetworkError::HomeDirNotFound` if home directory cannot be determined

### Primary Method

```rust
pub async fn get_credentials(&self) -> Result<Option<ApiCredentials>, NetworkError>
```

**Purpose**: Resolves API credentials using a three-tier priority system.

**Priority Hierarchy**:
1. **Environment Variables** (Highest Priority)
   - `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`
   - Immediate return if both variables present
   
2. **Shell Configuration Files** (Medium Priority)
   - Delegates to `ShellConfigReader` for parsing shell profiles
   - Supports multiple shell types and configuration formats
   
3. **Claude Code Configuration Files** (Lowest Priority)
   - Searches predefined paths in order
   - Supports multiple field naming conventions:
     - `api_base_url` + `auth_token`
     - `base_url` + `auth_token`

**Return Values**:
- `Ok(Some(ApiCredentials))` - Credentials found and validated
- `Ok(None)` - No credentials found (fail-silent behavior)
- `Err(NetworkError)` - System error during credential resolution

## Data Types

### ApiCredentials

```rust
pub struct ApiCredentials {
    pub base_url: String,
    pub auth_token: String,
    pub source: CredentialSource,
}
```

**Fields**:
- `base_url`: API endpoint URL
- `auth_token`: Authentication token for API access
- `source`: Tracks the origin of credentials for audit purposes

### CredentialSource

```rust
pub enum CredentialSource {
    Environment,
    ShellConfig(PathBuf),
    ClaudeConfig(PathBuf),
}
```

**Variants**:
- `Environment`: Credentials from environment variables
- `ShellConfig(PathBuf)`: Credentials from shell configuration file
- `ClaudeConfig(PathBuf)`: Credentials from Claude Code configuration file

## Integration Points

### Network Segment Integration

The CredentialManager is instantiated and used in:

1. **NetworkSegment::perform_async_health_check()** (`src/core/segments/network/segment.rs:459`)
   - Creates CredentialManager instance for async health monitoring
   
2. **NetworkSegment::perform_sync_health_check()** (`src/core/segments/network/segment.rs:639`)
   - Creates CredentialManager instance for synchronous health checks
   
3. **MonitoringEngine::new()** (`src/core/segments/network/segment.rs:1044`)
   - CredentialManager is embedded as a field in the MonitoringEngine struct

### Error Handling Integration

The module integrates with the broader error handling system through `NetworkError`:

```rust
pub enum NetworkError {
    NoCredentials,
    HomeDirNotFound,
    ConfigReadError(tokio::io::Error),
    ConfigParseError(serde_json::Error),
    // ... other variants
}
```

## Security Considerations

### Best Practices Implemented

1. **No Credential Logging**: Only credential lengths are logged, never the actual values
2. **Fail-Silent Behavior**: Returns `None` rather than panicking when credentials unavailable
3. **Hierarchical Security**: Environment variables take precedence over file-based credentials
4. **Comprehensive Error Context**: Detailed error information without exposing sensitive data

### Security Features

- **Multi-Source Support**: Reduces single point of failure
- **Source Tracking**: Audit trail for credential origins
- **Async Operations**: Non-blocking credential resolution
- **Robust Error Handling**: Prevents credential exposure through error messages

## Testing Interface

The module provides comprehensive test coverage in `tests/network/credential_manager_tests.rs`:

- **Constructor Testing**: Validates successful instantiation
- **Environment Variable Testing**: Tests priority system behavior
- **Configuration File Testing**: Validates file parsing and format support
- **Error Handling Testing**: Ensures proper error propagation

## Usage Examples

### Basic Usage

```rust
use crate::core::segments::network::credential_manager::CredentialManager;

// Create credential manager
let credential_manager = CredentialManager::new()?;

// Resolve credentials
match credential_manager.get_credentials().await? {
    Some(credentials) => {
        println!("Found credentials from: {:?}", credentials.source);
        // Use credentials for API calls
    },
    None => {
        println!("No credentials available");
    }
}
```

### Integration Pattern

```rust
// Typical integration in monitoring systems
let credential_manager = CredentialManager::new()?;
let credentials = credential_manager.get_credentials().await?;

if let Some(creds) = credentials {
    let http_monitor = HttpMonitor::new_with_credentials(creds).await?;
    // Continue with monitoring setup
} else {
    return Err(NetworkError::NoCredentials);
}
```

## Performance Characteristics

### Async Design Benefits

- **Non-blocking I/O**: File reads don't block the main thread
- **Parallel Operations**: Can be used concurrently with other async operations
- **Responsive UI**: Critical for status line applications

### Optimization Features

- **Early Return**: Stops at first successful credential source
- **Minimal Memory Footprint**: Simple struct with efficient path storage
- **Cached Paths**: Configuration paths calculated once at instantiation

## Configuration File Format

### Claude Code Configuration

```json
{
  "api_base_url": "https://api.anthropic.com",
  "auth_token": "your_auth_token_here"
}
```

Alternative format:
```json
{
  "base_url": "https://api.anthropic.com", 
  "auth_token": "your_auth_token_here"
}
```

### Environment Variables

```bash
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN="your_auth_token_here"
```

## Future Extensibility

The design supports future enhancements:

- **Additional Credential Sources**: Easy to add new sources to the priority hierarchy
- **Configuration Validation**: Can be extended with credential validation
- **Caching**: Credential caching can be added without interface changes
- **Multiple API Support**: Structure supports extending to other API services

## Troubleshooting

### Common Issues

1. **HomeDirNotFound**: Ensure `HOME` or `USERPROFILE` environment variable is set
2. **No Credentials**: Check priority order - environment variables override config files
3. **Config Parse Errors**: Verify JSON syntax in configuration files
4. **Permission Issues**: Ensure read access to configuration directories

### Debug Information

Enable debug logging with `CCSTATUS_DEBUG=1` to see detailed credential resolution flow:

```rust
// Example debug output
logger.debug("CredentialManager", "Starting credential lookup from all sources").await;
logger.debug("CredentialManager", "Found env credentials: endpoint=..., token_len=...").await;
```

## Dependencies

### Required Crates

- `tokio` - Async runtime and file I/O
- `serde_json` - JSON configuration parsing  
- `thiserror` - Error handling (via NetworkError)

### Internal Dependencies

- `crate::core::segments::network::types`
- `crate::core::segments::network::shell_config_reader`
- `crate::core::segments::network::debug_logger`

---

*This documentation covers the CredentialManager module as of the current implementation. For the most up-to-date interface details, refer to the source code at `src/core/segments/network/credential_manager.rs`.*