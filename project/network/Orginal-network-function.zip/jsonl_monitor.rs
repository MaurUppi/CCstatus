//! JSONL file monitoring for Claude Code session error capture
//! 
//! Monitors Claude Code .jsonl session files in real-time to capture API errors
//! and stores them in a global ccstatus-captured-error.json with first/last occurrence tracking.

use std::collections::HashMap;
use std::path::PathBuf;
use std::time::Duration;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::fs;
use tokio::time::sleep;
use crate::core::segments::network::types::NetworkError;

/// Configuration for .jsonl monitoring
#[derive(Debug, Clone)]
pub struct JsonlMonitorConfig {
    /// Project directory to monitor (e.g., ~/.claude/projects/-Users-ouzy-Documents-DevProjects-CCstatus/)
    pub project_dir: PathBuf,
    
    /// Global error capture file path (e.g., ~/.claude/ccstatus/ccstatus-captured-error.json)
    pub global_error_file: PathBuf,
    
    /// Monitoring interval (default: 5 seconds)
    pub check_interval: Duration,
    
    /// Maximum age of .jsonl files to monitor (default: 24 hours)
    pub max_file_age: Duration,
}

/// Error record with first/last occurrence tracking
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapturedError {
    /// Type of error (e.g., "authentication_error", "rate_limit_error")
    pub error_type: String,
    
    /// Detailed error message/description
    pub details: String,
    
    /// HTTP status code if available
    pub http_code: Option<u16>,
    
    /// First occurrence timestamp
    pub first_occurrence: DateTime<Utc>,
    
    /// Last occurrence timestamp  
    pub last_occurrence: DateTime<Utc>,
    
    /// Total occurrence count
    pub count: u32,
    
    /// Source session ID where error occurred
    pub session_id: String,
    
    /// Claude Code project path
    pub project_path: String,
}

/// Global error storage format
#[derive(Debug, Serialize, Deserialize)]
pub struct ErrorCaptureData {
    /// Version of the capture format
    pub version: String,
    
    /// When this file was last updated
    pub last_updated: DateTime<Utc>,
    
    /// Map of error_type -> CapturedError
    pub errors: HashMap<String, CapturedError>,
    
    /// Metadata about monitoring
    pub metadata: ErrorCaptureMetadata,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ErrorCaptureMetadata {
    /// Total number of errors captured
    pub total_errors_captured: u32,
    
    /// Number of unique error types
    pub unique_error_types: u32,
    
    /// Last monitored session timestamp
    pub last_monitored_session: Option<DateTime<Utc>>,
    
    /// Projects being monitored
    pub monitored_projects: Vec<String>,
}

/// Parsed .jsonl entry for error detection
#[derive(Debug, Deserialize)]
struct JsonlEntry {
    #[serde(rename = "type")]
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub entry_type: Option<String>,
    
    pub message: Option<JsonlMessage>,
    
    #[serde(rename = "sessionId")]
    pub session_id: Option<String>,
    
    pub timestamp: Option<String>,
    
    #[serde(rename = "isApiErrorMessage")]
    pub is_api_error_message: Option<bool>,
    
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub uuid: Option<String>,
}

#[derive(Debug, Deserialize)]
struct JsonlMessage {
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub id: Option<String>,
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub model: Option<String>,
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub usage: Option<JsonlUsage>,
    pub content: Option<serde_json::Value>,
    pub stop_reason: Option<String>,
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub role: Option<String>,
}

#[derive(Debug, Deserialize)]
struct JsonlUsage {
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub input_tokens: Option<u32>,
    #[allow(dead_code)] // Part of JSON schema, may be used in future monitoring logic
    pub output_tokens: Option<u32>,
}

/// JSONL monitor for real-time error capture
pub struct JsonlMonitor {
    config: JsonlMonitorConfig,
    last_checked_files: HashMap<PathBuf, DateTime<Utc>>,
}

impl JsonlMonitor {
    /// Create new JSONL monitor
    pub fn new(config: JsonlMonitorConfig) -> Self {
        Self {
            config,
            last_checked_files: HashMap::new(),
        }
    }
    
    /// Start monitoring .jsonl files for errors
    pub async fn start_monitoring(&mut self) -> Result<(), NetworkError> {
        loop {
            if let Err(e) = self.check_for_errors().await {
                eprintln!("Error during .jsonl monitoring: {}", e);
                // Continue monitoring despite errors
            }
            
            sleep(self.config.check_interval).await;
        }
    }
    
    /// Check for new errors in .jsonl files
    async fn check_for_errors(&mut self) -> Result<(), NetworkError> {
        // Find all .jsonl files in project directory
        let jsonl_files = self.find_jsonl_files().await?;
        
        for file_path in jsonl_files {
            self.process_jsonl_file(&file_path).await?;
        }
        
        Ok(())
    }
    
    /// Find all .jsonl files in the project directory
    async fn find_jsonl_files(&self) -> Result<Vec<PathBuf>, NetworkError> {
        let mut jsonl_files = Vec::new();
        
        if !self.config.project_dir.exists() {
            return Ok(jsonl_files);
        }
        
        let mut entries = fs::read_dir(&self.config.project_dir).await
            .map_err(NetworkError::ConfigReadError)?;
        
        while let Some(entry) = entries.next_entry().await
            .map_err(NetworkError::ConfigReadError)? {
            
            let path = entry.path();
            
            // Check if it's a .jsonl file
            if let Some(extension) = path.extension() {
                if extension == "jsonl" {
                    // Check if file is recent enough
                    if let Ok(metadata) = entry.metadata().await {
                        if let Ok(modified) = metadata.modified() {
                            let modified_duration = std::time::SystemTime::now()
                                .duration_since(modified)
                                .unwrap_or(Duration::from_secs(0));
                            
                            if modified_duration <= self.config.max_file_age {
                                jsonl_files.push(path);
                            }
                        }
                    }
                }
            }
        }
        
        Ok(jsonl_files)
    }
    
    /// Process a single .jsonl file for errors
    async fn process_jsonl_file(&mut self, file_path: &PathBuf) -> Result<(), NetworkError> {
        // Check if we've already processed this file recently
        let file_modified = self.get_file_modified_time(file_path).await?;
        
        if let Some(last_checked) = self.last_checked_files.get(file_path) {
            if file_modified <= *last_checked {
                return Ok(()) // No new content
            }
        }
        
        // Read file content
        let content = fs::read_to_string(file_path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        let mut new_errors = Vec::new();
        
        // Parse each line as JSON
        for (_line_num, line) in content.lines().enumerate() {
            if line.trim().is_empty() {
                continue;
            }
            
            match serde_json::from_str::<JsonlEntry>(line) {
                Ok(entry) => {
                    if let Some(error) = self.extract_error_from_entry(&entry, file_path).await {
                        new_errors.push(error);
                    }
                }
                Err(_) => {
                    // Skip invalid JSON lines - they might be partial writes
                    continue;
                }
            }
        }
        
        // Update global error file if we found new errors
        if !new_errors.is_empty() {
            self.update_global_error_file(new_errors).await?;
        }
        
        // Update last checked timestamp
        self.last_checked_files.insert(file_path.clone(), file_modified);
        
        Ok(())
    }
    
    /// Get file modification time
    async fn get_file_modified_time(&self, file_path: &PathBuf) -> Result<DateTime<Utc>, NetworkError> {
        let metadata = fs::metadata(file_path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        let modified = metadata.modified()
            .map_err(|_| NetworkError::ConfigReadError(
                std::io::Error::new(std::io::ErrorKind::Other, "Failed to get file modification time")
            ))?;
        
        Ok(DateTime::<Utc>::from(modified))
    }
    
    /// Extract error information from a .jsonl entry
    async fn extract_error_from_entry(
        &self,
        entry: &JsonlEntry,
        _file_path: &PathBuf,
    ) -> Option<CapturedError> {
        // Check for explicit API error flag
        if entry.is_api_error_message == Some(true) {
            return self.create_error_from_entry(entry, _file_path, "api_error").await;
        }
        
        // Check message content for HTTP error codes
        if let Some(message) = &entry.message {
            if let Some(content) = &message.content {
                let content_str = content.to_string().to_lowercase();
                
                // Look for HTTP error patterns
                if content_str.contains("400") || content_str.contains("bad request") {
                    return self.create_error_from_entry(entry, _file_path, "invalid_request_error").await;
                }
                if content_str.contains("401") || content_str.contains("unauthorized") {
                    return self.create_error_from_entry(entry, _file_path, "authentication_error").await;
                }
                if content_str.contains("403") || content_str.contains("forbidden") {
                    return self.create_error_from_entry(entry, _file_path, "permission_error").await;
                }
                if content_str.contains("404") || content_str.contains("not found") {
                    return self.create_error_from_entry(entry, _file_path, "not_found_error").await;
                }
                if content_str.contains("429") || content_str.contains("rate limit") {
                    return self.create_error_from_entry(entry, _file_path, "rate_limit_error").await;
                }
                if content_str.contains("500") || content_str.contains("internal server error") {
                    return self.create_error_from_entry(entry, _file_path, "api_error").await;
                }
                if content_str.contains("529") || content_str.contains("overloaded") {
                    return self.create_error_from_entry(entry, _file_path, "overloaded_error").await;
                }
            }
            
            // Check stop_reason for errors
            if let Some(stop_reason) = &message.stop_reason {
                if stop_reason.to_lowercase().contains("error") {
                    return self.create_error_from_entry(entry, _file_path, "api_error").await;
                }
            }
        }
        
        None
    }
    
    /// Create CapturedError from .jsonl entry
    async fn create_error_from_entry(
        &self,
        entry: &JsonlEntry,
        _file_path: &PathBuf,
        error_type: &str,
    ) -> Option<CapturedError> {
        let now = Utc::now();
        
        // Parse timestamp from entry
        let timestamp = if let Some(ts_str) = &entry.timestamp {
            DateTime::parse_from_rfc3339(ts_str)
                .map(|dt| dt.with_timezone(&Utc))
                .unwrap_or(now)
        } else {
            now
        };
        
        // Extract details from message content
        let details = if let Some(message) = &entry.message {
            if let Some(content) = &message.content {
                content.to_string()
            } else {
                "API error detected in Claude Code session".to_string()
            }
        } else {
            "API error detected in Claude Code session".to_string()
        };
        
        // Extract HTTP code from details if possible
        let http_code = self.extract_http_code(&details);
        
        Some(CapturedError {
            error_type: error_type.to_string(),
            details: details.chars().take(500).collect(), // Limit details length
            http_code,
            first_occurrence: timestamp,
            last_occurrence: timestamp,
            count: 1,
            session_id: entry.session_id.clone().unwrap_or_else(|| "unknown".to_string()),
            project_path: self.config.project_dir.to_string_lossy().to_string(),
        })
    }
    
    /// Extract HTTP status code from error details
    fn extract_http_code(&self, details: &str) -> Option<u16> {
        // Look for HTTP status codes in the details
        let patterns = ["400", "401", "403", "404", "413", "429", "500", "529"];
        for pattern in patterns {
            if details.contains(pattern) {
                return pattern.parse().ok();
            }
        }
        None
    }
    
    /// Update the global error capture file
    async fn update_global_error_file(&self, new_errors: Vec<CapturedError>) -> Result<(), NetworkError> {
        // Ensure directory exists
        if let Some(parent) = self.config.global_error_file.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).await
                    .map_err(|e| NetworkError::DirectoryCreationError(e))?;
            }
        }
        
        // Load existing data or create new
        let mut error_data = self.load_existing_error_data().await?;
        
        // Merge new errors
        for new_error in new_errors {
            let key = format!("{}_{}", new_error.error_type, new_error.session_id);
            
            match error_data.errors.get_mut(&key) {
                Some(existing) => {
                    // Update existing error
                    existing.last_occurrence = new_error.first_occurrence;
                    existing.count += 1;
                    existing.details = new_error.details; // Update with latest details
                }
                None => {
                    // Add new error
                    error_data.errors.insert(key, new_error);
                }
            }
        }
        
        // Update metadata
        error_data.last_updated = Utc::now();
        error_data.metadata.total_errors_captured = error_data.errors.values().map(|e| e.count).sum();
        error_data.metadata.unique_error_types = error_data.errors.keys().len() as u32;
        error_data.metadata.last_monitored_session = Some(Utc::now());
        
        // Add current project to monitored projects if not already present
        let current_project = self.config.project_dir.to_string_lossy().to_string();
        if !error_data.metadata.monitored_projects.contains(&current_project) {
            error_data.metadata.monitored_projects.push(current_project);
        }
        
        // Write to file
        let json_content = serde_json::to_string_pretty(&error_data)
            .map_err(NetworkError::SerializationError)?;
        
        fs::write(&self.config.global_error_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        Ok(())
    }
    
    /// Load existing error capture data
    async fn load_existing_error_data(&self) -> Result<ErrorCaptureData, NetworkError> {
        if self.config.global_error_file.exists() {
            let content = fs::read_to_string(&self.config.global_error_file).await
                .map_err(NetworkError::ConfigReadError)?;
            
            serde_json::from_str(&content)
                .map_err(NetworkError::ConfigParseError)
        } else {
            // Create new empty data
            Ok(ErrorCaptureData {
                version: "1.0".to_string(),
                last_updated: Utc::now(),
                errors: HashMap::new(),
                metadata: ErrorCaptureMetadata {
                    total_errors_captured: 0,
                    unique_error_types: 0,
                    last_monitored_session: None,
                    monitored_projects: Vec::new(),
                },
            })
        }
    }
}

impl Default for JsonlMonitorConfig {
    fn default() -> Self {
        let home = std::env::var("HOME")
            .or_else(|_| std::env::var("USERPROFILE"))
            .unwrap_or_else(|_| "/tmp".to_string());
        
        Self {
            project_dir: PathBuf::from(&home).join(".claude").join("projects").join("unknown"),
            global_error_file: PathBuf::from(&home).join(".claude").join("ccstatus").join("ccstatus-captured-error.json"),
            check_interval: Duration::from_secs(5),
            max_file_age: Duration::from_secs(24 * 60 * 60), // 24 hours
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;
    
    #[test]
    fn test_jsonl_monitor_config_default() {
        let config = JsonlMonitorConfig::default();
        assert_eq!(config.check_interval, Duration::from_secs(5));
        assert_eq!(config.max_file_age, Duration::from_secs(24 * 60 * 60));
        assert!(config.global_error_file.to_string_lossy().contains("ccstatus-captured-error.json"));
    }
    
    #[test]
    fn test_captured_error_serialization() {
        let error = CapturedError {
            error_type: "authentication_error".to_string(),
            details: "Invalid API token".to_string(),
            http_code: Some(401),
            first_occurrence: Utc::now(),
            last_occurrence: Utc::now(),
            count: 1,
            session_id: "test-session".to_string(),
            project_path: "/test/project".to_string(),
        };
        
        let json = serde_json::to_string(&error).unwrap();
        let deserialized: CapturedError = serde_json::from_str(&json).unwrap();
        
        assert_eq!(deserialized.error_type, "authentication_error");
        assert_eq!(deserialized.http_code, Some(401));
    }
    
    #[tokio::test]
    async fn test_find_jsonl_files() {
        let temp_dir = tempdir().unwrap();
        let project_dir = temp_dir.path().to_path_buf();
        
        // Create test .jsonl files
        let jsonl1 = project_dir.join("test1.jsonl");
        let jsonl2 = project_dir.join("test2.jsonl");
        let other_file = project_dir.join("test.txt");
        
        fs::write(&jsonl1, "test content").await.unwrap();
        fs::write(&jsonl2, "test content").await.unwrap();
        fs::write(&other_file, "test content").await.unwrap();
        
        let config = JsonlMonitorConfig {
            project_dir: project_dir.clone(),
            ..JsonlMonitorConfig::default()
        };
        
        let monitor = JsonlMonitor::new(config);
        let files = monitor.find_jsonl_files().await.unwrap();
        
        assert_eq!(files.len(), 2);
        assert!(files.contains(&jsonl1));
        assert!(files.contains(&jsonl2));
        assert!(!files.iter().any(|f| f.file_name().unwrap() == "test.txt"));
        
        temp_dir.close().unwrap();
    }
    
    #[test]
    fn test_extract_http_code() {
        let monitor = JsonlMonitor::new(JsonlMonitorConfig::default());
        
        assert_eq!(monitor.extract_http_code("HTTP 400 Bad Request"), Some(400));
        assert_eq!(monitor.extract_http_code("Error 401 Unauthorized"), Some(401));
        assert_eq!(monitor.extract_http_code("Rate limit exceeded (429)"), Some(429));
        assert_eq!(monitor.extract_http_code("No error here"), None);
    }
    
    #[tokio::test]
    async fn test_error_capture_data_serialization() {
        let mut errors = HashMap::new();
        errors.insert("test_key".to_string(), CapturedError {
            error_type: "rate_limit_error".to_string(),
            details: "Too many requests".to_string(),
            http_code: Some(429),
            first_occurrence: Utc::now(),
            last_occurrence: Utc::now(),
            count: 5,
            session_id: "test-session".to_string(),
            project_path: "/test/path".to_string(),
        });
        
        let data = ErrorCaptureData {
            version: "1.0".to_string(),
            last_updated: Utc::now(),
            errors,
            metadata: ErrorCaptureMetadata {
                total_errors_captured: 5,
                unique_error_types: 1,
                last_monitored_session: Some(Utc::now()),
                monitored_projects: vec!["/test/path".to_string()],
            },
        };
        
        let json = serde_json::to_string_pretty(&data).unwrap();
        let deserialized: ErrorCaptureData = serde_json::from_str(&json).unwrap();
        
        assert_eq!(deserialized.version, "1.0");
        assert_eq!(deserialized.metadata.total_errors_captured, 5);
        assert_eq!(deserialized.metadata.unique_error_types, 1);
        assert_eq!(deserialized.errors.len(), 1);
    }
}