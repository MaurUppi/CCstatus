//! HTTP monitoring for Claude API health checks
//! 
//! Provides lightweight health checks with detailed latency tracking and error categorization.

use isahc::{HttpClient, Request};
use isahc::config::{Configurable, RedirectPolicy};
use serde_json::json;
use std::time::{Duration, Instant};
use crate::core::segments::network::types::{
    NetworkError, NetworkConfig, HttpResult, HttpStatus, LatencyData, TimedResult
};
use crate::core::segments::network::latency_tracker::LatencyTracker;
use crate::core::segments::network::error_tracker::ErrorTracker;

/// HTTP client for API health monitoring
pub struct HttpMonitor {
    /// HTTP client with timing support
    client: HttpClient,
    
    /// Latency tracker
    latency_tracker: LatencyTracker,
    
    /// Error tracker
    error_tracker: ErrorTracker,
    
    /// Request payload for health checks
    health_check_payload: String,
}

impl HttpMonitor {
    /// Create new HTTP monitor
    pub async fn new(_config: &NetworkConfig) -> Result<Self, NetworkError> {
        // Configure HTTP client with reasonable timeouts to prevent hanging
        let client = HttpClient::builder()
            .redirect_policy(RedirectPolicy::Follow)
            .timeout(Duration::from_secs(30)) // Fixed 30s total timeout
            .connect_timeout(Duration::from_secs(10)) // 10s connect timeout
            .tcp_keepalive(Duration::from_secs(30)) // Enable TCP keepalive
            .tcp_nodelay() // Disable Nagle's algorithm for lower latency
            .build()
            .map_err(NetworkError::HttpClientError)?;
        
        // Prepare lightweight health check payload
        let health_check_payload = serde_json::to_string(&json!({
            "model": "claude-3-5-sonnet-20241022",
            "max_tokens": 1,
            "messages": [{
                "role": "user",
                "content": "ping"
            }]
        })).map_err(|e| NetworkError::SerializationError(e))?;
        
        Ok(Self {
            client,
            latency_tracker: LatencyTracker::new(),
            error_tracker: ErrorTracker::new(),
            health_check_payload,
        })
    }
    
    /// Perform health check against the API endpoint
    pub async fn check_endpoint(
        &self,
        base_url: &str,
        auth_token: &str,
    ) -> HttpResult {
        let endpoint = format!("{}/v1/messages", base_url.trim_end_matches('/'));
        let overall_start = Instant::now();
        
        // Add debug logging to track HTTP request flow
        use crate::core::segments::network::debug_logger::get_debug_logger;
        let logger = get_debug_logger();
        
        logger.debug("HttpMonitor", &format!("Attempting HTTP request to: {}", endpoint)).await;
        logger.debug("HttpMonitor", &format!("Auth token length: {}", auth_token.len())).await;
        
        // Build request
        let request = match Request::post(&endpoint)
            .header("Content-Type", "application/json")
            .header("x-api-key", auth_token)
            .header("anthropic-version", "2023-06-01")
            .body(self.health_check_payload.clone())
        {
            Ok(req) => {
                logger.debug("HttpMonitor", "HTTP request built successfully").await;
                req
            },
            Err(e) => {
                logger.error("HttpMonitor", &format!("Request build failed: {}", e)).await;
                return HttpResult::error("Request build failed", e);
            },
        };
        
        // Execute request with detailed timing
        logger.debug("HttpMonitor", "Executing HTTP request...").await;
        let latency_breakdown = self.execute_with_timing(request).await;
        let total_duration = overall_start.elapsed();
        
        logger.debug("HttpMonitor", &format!("HTTP request completed in {}ms", total_duration.as_millis())).await;
        
        // Combine timing data
        let latency = LatencyData {
            dns: latency_breakdown.dns,
            tcp: latency_breakdown.tcp,
            tls: latency_breakdown.tls,
            ttfb: latency_breakdown.ttfb,
            total: total_duration,
        };
        
        // Track results
        self.latency_tracker.record(&latency).await;
        
        match latency_breakdown.result {
            Ok(response) => {
                let status = response.status();
                let status_type = self.categorize_status(status.as_u16());
                
                logger.debug("HttpMonitor", &format!("HTTP response: {} (type: {:?})", status.as_u16(), status_type)).await;
                
                if !status_type.is_success() {
                    self.error_tracker.record_error(
                        &format!("API_{}", status.as_u16()),
                        Some(status.as_u16()),
                    ).await;
                }
                
                // CRITICAL FIX: Separate error message from error type
                let (error_msg, error_type) = if status_type.is_success() {
                    (None, None) // No error for successful responses
                } else {
                    let anthropic_error_type = self.get_anthropic_error_type(status.as_u16());
                    let error_message = format!("HTTP {} - {}", status.as_u16(), status.canonical_reason().unwrap_or("Unknown Error"));
                    (Some(error_message), anthropic_error_type)
                };
                
                logger.debug("HttpMonitor", &format!("Returning HttpResult: success={}, latency={}ms", status_type.is_success(), latency.total.as_millis())).await;
                
                HttpResult {
                    status: status_type,
                    latency,
                    error: error_msg,
                    error_type,
                    response_code: Some(status.as_u16()),
                }
            }
            Err(e) => {
                let error_msg = self.categorize_error(&e);
                logger.error("HttpMonitor", &format!("HTTP request failed: {} (categorized as: {})", e, error_msg)).await;
                
                self.error_tracker.record_error(&error_msg, None).await;
                
                HttpResult {
                    status: HttpStatus::NetworkError,
                    latency,
                    error: Some(error_msg),
                    error_type: None, // Network errors don't have Anthropic error types
                    response_code: None,
                }
            }
        }
    }
    
    /// Execute request with timing measurements
    async fn execute_with_timing(&self, request: Request<String>) -> TimedResult {
        // Note: isahc doesn't provide detailed timing breakdowns
        // This is a simplified implementation focusing on total time
        let start = Instant::now();
        
        // Clone client for direct execution
        let client = self.client.clone();
        
        // Use debug logging to track execution
        use crate::core::segments::network::debug_logger::get_debug_logger;
        let logger = get_debug_logger();
        logger.debug("HttpMonitor", "Executing HTTP request with direct client").await;
        
        // ARCHITECTURAL FIX: Direct HTTP client calls to prevent nested runtime deadlocks
        logger.debug("HttpMonitor", "Making direct HTTP client call").await;
        
        let result = match tokio::time::timeout(
            Duration::from_secs(25), // Slightly less than client timeout
            client.send_async(request) // Direct call - no nested spawn needed
        ).await {
            Ok(http_result) => {
                match http_result {
                    Ok(response) => {
                        logger.debug("HttpMonitor", "Direct HTTP request completed successfully").await;
                        Ok(response)
                    },
                    Err(http_error) => {
                        logger.error("HttpMonitor", &format!("HTTP request failed: {}", http_error)).await;
                        Err(http_error)
                    }
                }
            },
            Err(_) => {
                logger.error("HttpMonitor", "HTTP request timed out after 25 seconds").await;
                // Create a timeout error using isahc's error construction
                use std::io::{Error as IoError, ErrorKind};
                let timeout_error = IoError::new(ErrorKind::TimedOut, "Request timed out after 25 seconds");
                Err(isahc::Error::from(timeout_error))
            },
        };
        
        let total_time = start.elapsed();
        
        // For detailed timing, we'd need to integrate with system-level
        // network monitoring or use a different HTTP client
        // For now, estimate based on total time and connection reuse patterns
        
        TimedResult {
            result,
            dns: if total_time > Duration::from_millis(100) {
                Some(Duration::from_millis(20)) // Estimated DNS lookup time
            } else {
                None // Likely connection reuse
            },
            tcp: if total_time > Duration::from_millis(50) {
                Some(Duration::from_millis(30)) // Estimated TCP connect time
            } else {
                None // Likely connection reuse
            },
            tls: if total_time > Duration::from_millis(80) {
                Some(Duration::from_millis(40)) // Estimated TLS handshake time
            } else {
                None // Likely connection reuse
            },
            ttfb: Duration::from_millis(total_time.as_millis() as u64 / 2), // Server processing estimate
        }
    }
    
    /// Categorize HTTP status code
    fn categorize_status(&self, status_code: u16) -> HttpStatus {
        match status_code {
            200..=299 => HttpStatus::Success,
            401 | 403 => HttpStatus::AuthError,
            429 => HttpStatus::RateLimit,
            500..=599 => HttpStatus::ServerError,
            _ => HttpStatus::ClientError,
        }
    }
    
    /// Map HTTP status codes to official Anthropic API error types
    /// Based on https://docs.anthropic.com/en/api/errors
    fn get_anthropic_error_type(&self, status_code: u16) -> Option<String> {
        match status_code {
            400 => Some("invalid_request_error".to_string()),
            401 => Some("authentication_error".to_string()),
            403 => Some("permission_error".to_string()),
            404 => Some("not_found_error".to_string()),
            413 => Some("request_too_large".to_string()),
            429 => Some("rate_limit_error".to_string()),
            500 => Some("api_error".to_string()),
            529 => Some("overloaded_error".to_string()),
            _ => None, // Success or other status codes don't have specific error types
        }
    }
    
    /// Categorize isahc error
    fn categorize_error(&self, error: &isahc::Error) -> String {
        if error.is_timeout() {
            "NETWORK_TIMEOUT".to_string()
        } else {
            // Simplified error categorization since some methods changed
            let error_str = error.to_string();
            if error_str.contains("connect") || error_str.contains("connection") {
                "CONNECTION_FAILED".to_string()
            } else if error_str.contains("tls") || error_str.contains("ssl") {
                "TLS_ERROR".to_string()
            } else {
                "NETWORK_ERROR".to_string()
            }
        }
    }
    
}

// Note: HttpMonitor uses a simple architecture with direct HTTP client calls
// to avoid async runtime complexity and deadlock issues
// In production use, HttpMonitor instances typically live for the application lifetime

// Tests for this module have been moved to tests/network/http_monitor_tests.rs