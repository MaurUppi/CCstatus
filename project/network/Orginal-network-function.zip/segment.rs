//! Network monitoring segment implementation
//! 
//! Main component that implements the Segment trait and coordinates all network monitoring functionality.

use std::sync::Arc;
use std::time::Duration;
use tokio::sync::RwLock;
use chrono::Local;
use crate::core::segments::{Segment, SegmentData};
use crate::config::{InputData, SegmentId};
use crate::core::segments::network::types::{
    NetworkConfig, NetworkError, NetworkStatus, HealthCheckResult, MonitoringState
};
use crate::core::segments::network::credential_manager::CredentialManager;
use crate::core::segments::network::http_monitor::HttpMonitor;
use crate::core::segments::network::state_machine::StateMachine;
use crate::core::segments::network::status_renderer::StatusRenderer;
use crate::core::segments::network::status_file_writer::StatusFileWriter;
use crate::core::segments::network::jsonl_monitor::{JsonlMonitor, JsonlMonitorConfig};
use crate::core::segments::network::debug_logger::get_debug_logger;
use std::collections::HashMap;
use std::env;


/// Main network monitoring segment
pub struct NetworkSegment {
    /// Current status (cached for fast access)
    current_status: Arc<RwLock<NetworkStatus>>,
    
    /// Status renderer for display
    status_renderer: StatusRenderer,
    
    /// Configuration
    config: NetworkConfig,
    
    /// Monitoring task handle (for cleanup)
    _monitoring_handle: Option<tokio::task::JoinHandle<()>>,
}

/// Monitoring engine that runs asynchronously
struct MonitoringEngine {
    credential_manager: CredentialManager,
    http_monitor: HttpMonitor,
    state_machine: StateMachine,
    status_writer: StatusFileWriter,
    jsonl_monitor: Option<JsonlMonitor>,
    current_status: Arc<RwLock<NetworkStatus>>,
}

impl NetworkSegment {
    /// Create network segment from synchronous context (for statusline usage)
    pub fn new_sync() -> Self {
        let logger = get_debug_logger();
        
        // Log initialization start
        logger.info_sync("MonitoringEngine", "Sync Init Started: Creating NetworkSegment from synchronous context");
        
        // PHASE 3: Process synchronization - prevent concurrent sync spawns
        if let Err(_) = Self::acquire_sync_lock(&logger) {
            logger.warn_sync("ProcessLock", "Another sync process is running, returning cached status");
            return Self::create_fallback_segment(&logger);
        }
        
        // Try to create an enabled segment in a blocking context
        let config = NetworkConfig::default();
        
        // CRITICAL FIX: Check for existing status before defaulting to Unknown
        // This prevents statusline from always showing Unknown on fresh renders
        let initial_status = if let Ok(writer) = StatusFileWriter::new() {
            let status_file_path = writer.get_status_file_path().to_string_lossy().to_string();
            
            if let Ok(status_data) = std::fs::read_to_string(writer.get_status_file_path()) {
                // Log successful status file read
                logger.debug_sync("StatusFile", &format!("Read: {} (success=true)", status_file_path));
                
                if let Ok(data) = serde_json::from_str::<crate::core::segments::network::types::StatusFileData>(&status_data) {
                    // Check if status is recent based on adaptive interval (not hardcoded 30 seconds)
                    let age = Local::now().signed_duration_since(data.timestamp);
                    let age_seconds = age.num_seconds();
                    let adaptive_interval = data.monitoring_state.interval_seconds as i64;
                    
                    // Log status age check with adaptive interval
                    logger.debug_sync("StatusFile", &format!("Status file age: {}s, status: '{}', interval: {}s, fresh: {}", age_seconds, data.status, adaptive_interval, age_seconds < adaptive_interval));
                    
                    if age_seconds < adaptive_interval {
                        // Convert JSON status back to NetworkStatus
                        match data.status.as_str() {
                            "healthy" => NetworkStatus::Healthy,
                            "degraded" => NetworkStatus::Degraded {
                                reason: "From previous session".to_string(),
                                details: data.network.breakdown,
                            },
                            "error" => NetworkStatus::Error {
                                error_type: data.network.error_type.unwrap_or_else(|| "UNKNOWN_ERROR".to_string()),
                                details: data.network.breakdown,
                            },
                            _ => NetworkStatus::Unknown,
                        }
                    } else {
                        // Log stale status
                        logger.warn_sync("StatusFile", &format!("Status file is stale ({}s old), defaulting to Unknown", age_seconds));
                        NetworkStatus::Unknown
                    }
                } else {
                    // Log JSON parse error
                    logger.warn_sync("StatusFile", &format!("Failed to parse JSON in {}", status_file_path));
                    NetworkStatus::Unknown
                }
            } else {
                // Log file read failure
                logger.debug_sync("StatusFile", &format!("Status file not found or unreadable: {}", status_file_path));
                NetworkStatus::Unknown
            }
        } else {
            // Log StatusFileWriter creation failure
            logger.warn_sync("StatusFile", "Failed to create StatusFileWriter");
            NetworkStatus::Unknown
        };
        
        // PHASE 4: Use thread-based approach to avoid runtime lifecycle issues  
        let current_status = if matches!(initial_status, NetworkStatus::Unknown) {
            logger.debug_sync("SyncHealthCheck", "No fresh status found, performing immediate health check via thread");
            
            // Use thread-based approach instead of runtime to avoid cleanup issues
            let logger_clone = logger;
            let (tx, rx) = std::sync::mpsc::channel();
            
            std::thread::spawn(move || {
                let rt = match tokio::runtime::Runtime::new() {
                    Ok(runtime) => runtime,
                    Err(e) => {
                        logger_clone.error_sync("ThreadHealthCheck", &format!("Failed to create runtime: {}", e));
                        let _ = tx.send(Err(NetworkError::RuntimeError(e.to_string())));
                        return;
                    }
                };
                
                let result = rt.block_on(async {
                    logger_clone.debug_sync("ThreadHealthCheck", "Starting async health check in dedicated thread");
                    Self::perform_async_health_check(&logger_clone).await
                });
                
                let _ = tx.send(result);
            });
            
            // Wait for health check completion with timeout
            match rx.recv_timeout(std::time::Duration::from_secs(10)) {
                Ok(Ok(health_result)) => {
                    logger.debug_sync("SyncHealthCheck", "Thread-based health check completed successfully");
                    
                    // Write status file synchronously  
                    if let Ok(writer) = StatusFileWriter::new() {
                        logger.debug_sync("SyncHealthCheck", "StatusFileWriter created - calling write_status_sync");
                        match Self::write_status_sync(&writer, &health_result, &logger) {
                            Ok(_) => logger.debug_sync("SyncHealthCheck", "write_status_sync completed successfully"),
                            Err(e) => logger.error_sync("SyncHealthCheck", &format!("write_status_sync failed: {}", e)),
                        }
                    }
                    
                    Arc::new(RwLock::new(health_result.status))
                },
                Ok(Err(e)) => {
                    logger.error_sync("SyncHealthCheck", &format!("Thread-based health check failed: {}", e));
                    let error_status = NetworkStatus::Error {
                        error_type: "HEALTH_CHECK_ERROR".to_string(),
                        details: format!("Health check failed: {}", e),
                    };
                    Arc::new(RwLock::new(error_status))
                },
                Err(_) => {
                    logger.warn_sync("SyncHealthCheck", "Thread-based health check timed out after 10 seconds");
                    let timeout_status = NetworkStatus::Error {
                        error_type: "HEALTH_CHECK_TIMEOUT".to_string(),
                        details: "Health check timed out after 10 seconds".to_string(),
                    };
                    Arc::new(RwLock::new(timeout_status))
                }
            }
        } else {
            logger.debug_sync("StatusCache", &format!("Using cached status: {:?}", initial_status));
            Arc::new(RwLock::new(initial_status))
        };
        
        let status_clone = current_status.clone();
        let config_clone = config.clone();
        
        // Create synchronization primitives for initialization
        let (init_tx, init_rx) = std::sync::mpsc::channel();
        
        // Try to create a tokio runtime or use existing one
        let _thread_handle = std::thread::spawn(move || {
            // Log thread startup
            logger.info_sync("MonitoringEngine", "Thread Started: Monitoring thread spawned successfully");
            
            // Create a new tokio runtime for the monitoring thread
            // CRITICAL FIX: Use multithreaded runtime to prevent async I/O deadlocks
            // Single-threaded runtime can deadlock when monitoring loop + credential I/O compete for scheduler
            let rt = match tokio::runtime::Builder::new_multi_thread()
                .worker_threads(2)  // Minimal threads for concurrent I/O scheduling
                .thread_name("ccstatus-monitor")
                .enable_all()
                .build() {
                Ok(runtime) => {
                    // Log runtime creation success with detailed thread information
                    logger.log_runtime_creation_sync("ccstatus-monitor", 2, true, None);
                    logger.info_sync("MonitoringEngine", "Runtime Created: Multi-threaded Tokio runtime created successfully (2 worker threads)");
                    runtime
                },
                Err(e) => {
                    // Log runtime creation failure with detailed error information
                    logger.log_runtime_creation_sync("ccstatus-monitor", 2, false, Some(&e.to_string()));
                    logger.error_sync("MonitoringEngine", &format!("Failed to create tokio runtime: {}", e));
                    // Signal initialization failure
                    let _ = init_tx.send(false);
                    return;
                },
            };
            
            rt.block_on(async {
                // Log initialization attempt
                let logger = get_debug_logger();
                logger.log_engine_event("Init Started", "Attempting to initialize MonitoringEngine").await;
                
                // Try to initialize monitoring
                match MonitoringEngine::new(status_clone.clone(), config_clone).await {
                    Ok(engine) => {
                        // Log successful initialization
                        logger.log_engine_event("Init Success", "MonitoringEngine initialized successfully, starting monitoring loop").await;
                        
                        // Signal successful initialization
                        let _ = init_tx.send(true);
                        engine.run_monitoring_loop().await;
                    }
                    Err(e) => {
                        // Log initialization failure
                        let error_message = e.to_string();
                        let is_credentials_error = e.is_credentials_missing();
                        
                        logger.error("MonitoringEngine", &format!("Initialization failed: {} (credentials_missing: {})", error_message, is_credentials_error)).await;
                        
                        // Set status to appropriate error state based on error type
                        let mut status = status_clone.write().await;
                        let error_status = if is_credentials_error {
                            NetworkStatus::Error {
                                error_type: "NO_CREDENTIALS".to_string(),
                                details: "Claude Code credentials not found. Set ANTHROPIC_BASE_URL and ANTHROPIC_AUTH_TOKEN as environment variables, or add exports to ~/.zshrc, or define them in shell functions (like cc-env)".to_string(),
                            }
                        } else {
                            NetworkStatus::Error {
                                error_type: "INITIALIZATION_FAILED".to_string(),
                                details: format!("Network monitoring initialization failed: {}", e),
                            }
                        };
                        
                        // Log status transition
                        logger.log_status_transition("Unknown", "Error", &format!("{:?}", error_status.clone())).await;
                        
                        *status = error_status.clone();
                        let current_status = status.clone();
                        drop(status); // Release the lock before writing file
                        
                        // Write error status to file with appropriate status
                        if let Ok(writer) = StatusFileWriter::new() {
                            let _ = writer.write_error_status(&current_status).await;
                        }
                        
                        // Signal initialization complete (even though failed)
                        let _ = init_tx.send(true);
                    }
                }
            });
        });
        
        // Wait for initialization to complete (increased from 100ms to 2000ms)
        // This gives adequate time for credential lookup and network initialization
        if let Ok(_) = init_rx.recv_timeout(Duration::from_millis(2000)) {
            // Initialization signal received (success or failure)
            logger.info_sync("MonitoringEngine", "Init Complete: Initialization completed within 2s timeout");
        } else {
            // Timeout - set status to error instead of leaving as unknown
            logger.warn_sync("Initialization", "MonitoringEngine initialization timed out after 2000 ms");
            
            if let Ok(mut status) = current_status.try_write() {
                let timeout_status = NetworkStatus::Error {
                    error_type: "INITIALIZATION_TIMEOUT".to_string(),
                    details: "Network monitoring initialization timed out after 2 seconds. Check credentials and network connectivity.".to_string(),
                };
                
                // Log status transition for timeout
                logger.info_sync("StatusTransition", &format!("Unknown -> Error ({:?})", timeout_status));
                
                *status = timeout_status;
            }
        }
        
        let segment = Self {
            current_status,
            status_renderer: StatusRenderer::new(),
            config,
            _monitoring_handle: None, // Thread handle, not tokio handle
        };
        
        // PHASE 3: Release process lock after successful sync health check completion  
        Self::release_sync_lock(&logger);
        
        segment
    }
    
    /// Create new network segment with monitoring enabled
    pub async fn new(config: NetworkConfig) -> Result<Self, NetworkError> {
        let current_status = Arc::new(RwLock::new(NetworkStatus::Unknown));
        let status_renderer = StatusRenderer::new();
        
        if !config.enabled {
            // If disabled, set status to disabled and don't start monitoring
            {
                let mut status = current_status.write().await;
                *status = NetworkStatus::Disabled;
            }
            
            return Ok(Self {
                current_status,
                status_renderer,
                config,
                _monitoring_handle: None,
            });
        }
        
        // Try to initialize monitoring engine
        let monitoring_engine = match MonitoringEngine::new(current_status.clone(), config.clone()).await {
            Ok(engine) => engine,
            Err(e) if e.should_fail_silent() => {
                // Set status to appropriate error state for user feedback
                let error_status = if e.is_credentials_missing() {
                    NetworkStatus::Error {
                        error_type: "NO_CREDENTIALS".to_string(),
                        details: "Claude Code credentials not found. Set ANTHROPIC_BASE_URL and ANTHROPIC_AUTH_TOKEN as environment variables, or add exports to ~/.zshrc, or define them in shell functions (like cc-env)".to_string(),
                    }
                } else {
                    // For other silent failures like HomeDirNotFound, keep as disabled
                    NetworkStatus::Disabled
                };
                
                {
                    let mut status = current_status.write().await;
                    *status = error_status.clone();
                }
                
                // Write appropriate status to file
                if let Ok(writer) = StatusFileWriter::new() {
                    match &error_status {
                        NetworkStatus::Error { .. } => {
                            let _ = writer.write_error_status(&error_status).await;
                        }
                        NetworkStatus::Disabled => {
                            let _ = writer.write_disabled_status().await;
                        }
                        _ => {}
                    }
                }
                
                return Ok(Self {
                    current_status,
                    status_renderer,
                    config,
                    _monitoring_handle: None,
                });
            }
            Err(e) => return Err(e),
        };
        
        // Start monitoring loop
        let monitoring_handle = tokio::spawn(async move {
            monitoring_engine.run_monitoring_loop().await;
        });
        
        Ok(Self {
            current_status,
            status_renderer,
            config,
            _monitoring_handle: Some(monitoring_handle),
        })
    }
    
    /// Create new network segment with default config
    pub async fn new_default() -> Result<Self, NetworkError> {
        Self::new(NetworkConfig::default()).await
    }
    
    /// Create a disabled network segment
    pub fn disabled() -> Self {
        let config = NetworkConfig {
            enabled: false,
            ..NetworkConfig::default()
        };
        
        let current_status = Arc::new(RwLock::new(NetworkStatus::Disabled));
        let status_renderer = StatusRenderer::new();
        
        Self {
            current_status,
            status_renderer,
            config,
            _monitoring_handle: None,
        }
    }
    
    /// Get current network status (async)
    pub async fn get_status(&self) -> NetworkStatus {
        let status = self.current_status.read().await;
        status.clone()
    }
    
    /// Check if monitoring is enabled
    pub fn is_monitoring_enabled(&self) -> bool {
        self.config.enabled && self._monitoring_handle.is_some()
    }

    /// Helper function to parse monitoring state from JSON data
    fn parse_monitoring_state(monitoring_state_data: &crate::core::segments::network::types::MonitoringStateData) -> MonitoringState {
        match monitoring_state_data.state.as_str() {
            "healthy" => MonitoringState::Healthy {
                interval: Duration::from_secs(monitoring_state_data.interval_seconds),
                consecutive_successes: monitoring_state_data.consecutive_successes.unwrap_or(0),
            },
            "degraded" => MonitoringState::Degraded {
                interval: Duration::from_secs(monitoring_state_data.interval_seconds),
                since: chrono::Utc::now(),
            },
            "failed" => MonitoringState::Failed {
                interval: Duration::from_secs(monitoring_state_data.interval_seconds),
                consecutive_failures: monitoring_state_data.consecutive_failures.unwrap_or(0),
                since: chrono::Utc::now(),
            },
            _ => MonitoringState::Healthy {
                interval: Duration::from_secs(30),
                consecutive_successes: 0,
            }
        }
    }

    /// Helper function to convert HTTP status to state machine event
    fn http_status_to_state_event(http_status: &crate::core::segments::network::types::HttpStatus) -> crate::core::segments::network::types::StateEvent {
        match http_status {
            crate::core::segments::network::types::HttpStatus::Success => {
                crate::core::segments::network::types::StateEvent::Success
            }
            crate::core::segments::network::types::HttpStatus::RateLimit => {
                crate::core::segments::network::types::StateEvent::RateLimit
            }
            _ => crate::core::segments::network::types::StateEvent::Failure,
        }
    }

    /// Perform async health check (for use in dedicated thread)
    async fn perform_async_health_check(logger: &crate::core::segments::network::debug_logger::DebugLogger) -> Result<HealthCheckResult, NetworkError> {
        logger.debug_sync("AsyncHealthCheck", "Starting async health check");
        
        // Create credential manager
        let credential_manager = CredentialManager::new()?;
        let state_machine = StateMachine::new();
        
        // Get credentials
        let creds = match credential_manager.get_credentials().await {
            Ok(Some(credentials)) => credentials,
            Ok(None) => return Err(NetworkError::NoCredentials),
            Err(e) => return Err(e),
        };
        
        logger.debug_sync("AsyncHealthCheck", &format!("Credentials retrieved: endpoint={}", creds.base_url));
        
        // Perform HTTP health check
        let config = NetworkConfig::default();
        let http_monitor = HttpMonitor::new(&config).await?;
        let http_result = http_monitor.check_endpoint(&creds.base_url, &creds.auth_token).await;
        
        logger.debug_sync("AsyncHealthCheck", &format!("HTTP check completed: status={:?}", http_result.status));
        
        // Convert HttpStatus to NetworkStatus
        let network_status = match http_result.status {
            crate::core::segments::network::types::HttpStatus::Success => NetworkStatus::Healthy,
            crate::core::segments::network::types::HttpStatus::RateLimit => NetworkStatus::Degraded {
                reason: "Rate limited".to_string(),
                details: http_result.error.clone().unwrap_or_else(|| "API rate limited".to_string()),
            },
            crate::core::segments::network::types::HttpStatus::ServerError => NetworkStatus::Degraded {
                reason: "Server error".to_string(),
                details: http_result.error.clone().unwrap_or_else(|| "API server error".to_string()),
            },
            _ => NetworkStatus::Error {
                error_type: http_result.error_type.clone().unwrap_or_else(|| "HTTP_ERROR".to_string()),
                details: http_result.error.clone().unwrap_or_else(|| "HTTP request failed".to_string()),
            },
        };
        
        // Transition state machine
        let state_event = Self::http_status_to_state_event(&http_result.status);
        let transitioned_state = state_machine.transition(state_event).await;
        
        // Create HealthCheckResult
        let health_result = HealthCheckResult {
            status: network_status,
            latency: http_result.latency,
            error: http_result.error,
            error_type: http_result.error_type,
            response_code: http_result.response_code,
            timestamp: chrono::Local::now(),
            state: transitioned_state,
            credentials: creds,
        };
        
        logger.debug_sync("AsyncHealthCheck", "Async health check completed successfully");
        Ok(health_result)
    }

    /// Perform synchronous health check with timeout to solve race condition
    fn perform_sync_health_check(logger: &crate::core::segments::network::debug_logger::DebugLogger) -> Result<HealthCheckResult, NetworkError> {
        logger.debug_sync("SyncHealthCheck", "Starting synchronous health check");
        
        // Load previous StateMachine state from status file
        let (initial_state, last_timestamp, cached_result) = if let Ok(writer) = StatusFileWriter::new() {
            if let Ok(status_data) = std::fs::read_to_string(writer.get_status_file_path()) {
                if let Ok(data) = serde_json::from_str::<crate::core::segments::network::types::StatusFileData>(&status_data) {
                    // Check if status is recent (within last 30 seconds)
                    let age = Local::now().signed_duration_since(data.timestamp);
                    let state = if age.num_seconds() < 30 {
                        // Restore state from JSON
                        Self::parse_monitoring_state(&data.monitoring_state)
                    } else {
                        // Status file is stale but preserve StateMachine progression
                        Self::parse_monitoring_state(&data.monitoring_state)
                    };
                    
                    // Create cached result from status file data
                    let cached_health_result = HealthCheckResult {
                        status: match data.status.as_str() {
                            "healthy" => NetworkStatus::Healthy,
                            _ => NetworkStatus::Unknown, // Conservative fallback
                        },
                        latency: crate::core::segments::network::types::LatencyData {
                            total: Duration::from_millis(data.network.latency_ms.into()),
                            dns: Some(Duration::from_millis(20)),
                            tcp: Some(Duration::from_millis(30)),
                            tls: Some(Duration::from_millis(40)),
                            ttfb: Duration::from_millis(data.network.latency_ms.saturating_sub(90).into()),
                        },
                        error: data.network.error_type.clone(),
                        error_type: data.network.error_type.clone(),
                        response_code: data.network.http_status_code,
                        timestamp: data.timestamp,
                        state: state.clone(),
                        credentials: crate::core::segments::network::types::ApiCredentials {
                            base_url: data.api_config.endpoint.clone(),
                            auth_token: "***".to_string(), // Don't expose token
                            source: match data.api_config.source.as_str() {
                                "environment" => crate::core::segments::network::types::CredentialSource::Environment,
                                _ => crate::core::segments::network::types::CredentialSource::Environment,
                            },
                        },
                    };
                    
                    (state, Some(data.timestamp), Some(cached_health_result))
                } else {
                    // Failed to parse JSON, start fresh
                    (MonitoringState::Healthy {
                        interval: Duration::from_secs(30),
                        consecutive_successes: 0,
                    }, None, None)
                }
            } else {
                // No status file exists, start fresh
                (MonitoringState::Healthy {
                    interval: Duration::from_secs(30),
                    consecutive_successes: 0,
                }, None, None)
            }
        } else {
            // Failed to create StatusFileWriter, start fresh
            (MonitoringState::Healthy {
                interval: Duration::from_secs(30),
                consecutive_successes: 0,
            }, None, None)
        };
        
        // Check if we should skip health check based on adaptive interval
        if let (Some(last_ts), Some(cached)) = (last_timestamp, cached_result) {
            let current_interval = match &initial_state {
                MonitoringState::Healthy { interval, .. } => *interval,
                MonitoringState::Degraded { interval, .. } => *interval,
                MonitoringState::Failed { interval, .. } => *interval,
            };
            
            let time_since_last = Local::now().signed_duration_since(last_ts);
            let interval_secs = current_interval.as_secs() as i64;
            
            // Only perform health check if enough time has passed according to adaptive interval
            if time_since_last.num_seconds() < interval_secs {
                logger.debug_sync("SyncHealthCheck", &format!(
                    "Skipping health check - only {}s passed, interval is {}s", 
                    time_since_last.num_seconds(), 
                    interval_secs
                ));
                return Ok(cached);
            } else {
                logger.debug_sync("SyncHealthCheck", &format!(
                    "Performing health check - {}s passed, interval is {}s", 
                    time_since_last.num_seconds(), 
                    interval_secs
                ));
            }
        }
        
        // Try to get credentials synchronously
        // CRITICAL FIX: Use multithreaded runtime to prevent async I/O deadlocks in credential retrieval
        let rt = match tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)  // Minimal threads for concurrent I/O scheduling
            .thread_name("ccstatus-sync-health")
            .enable_all()
            .build() {
            Ok(rt) => {
                // Log runtime creation success with detailed thread information
                logger.log_runtime_creation_sync("ccstatus-sync-health", 2, true, None);
                rt
            },
            Err(e) => {
                // Log runtime creation failure with detailed error information
                logger.log_runtime_creation_sync("ccstatus-sync-health", 2, false, Some(&e.to_string()));
                logger.error_sync("SyncHealthCheck", &format!("Failed to create runtime: {}", e));
                return Err(NetworkError::RuntimeError(e.to_string()));
            }
        };

        logger.debug_sync("SyncHealthCheck", "=== ABOUT TO ENTER rt.block_on async block ===");
        
        let result = rt.block_on(async {
            logger.debug_sync("SyncHealthCheck", "=== ENTERED async block ===");
            
            // Create credential manager
            logger.debug_sync("SyncHealthCheck", "Creating CredentialManager...");
            let credential_manager = match CredentialManager::new() {
                Ok(cm) => {
                    logger.debug_sync("SyncHealthCheck", "CredentialManager created successfully");
                    cm
                },
                Err(e) => {
                    logger.error_sync("SyncHealthCheck", &format!("CredentialManager creation failed: {}", e));
                    return Err(e);
                }
            };
            
            // Create StateMachine with the initial state
            logger.debug_sync("SyncHealthCheck", "Creating StateMachine from initial state...");
            let state_machine = StateMachine::from_state(initial_state);
            logger.debug_sync("SyncHealthCheck", "StateMachine created successfully");

            logger.debug_sync("SyncHealthCheck", "About to get credentials with timeout...");
            
            // Get credentials with timeout
            match tokio::time::timeout(
                Duration::from_millis(1000),
                credential_manager.get_credentials()
            ).await {
                Ok(Ok(Some(creds))) => {
                    logger.debug_sync("SyncHealthCheck", &format!("Credentials retrieved successfully: endpoint={}", creds.base_url));
                    
                    // Perform quick health check with timeout
                    let config = NetworkConfig::default();
                    logger.debug_sync("SyncHealthCheck", "About to create HttpMonitor...");
                    
                    match HttpMonitor::new(&config).await {
                        Ok(http_monitor) => {
                            logger.debug_sync("SyncHealthCheck", "HttpMonitor created, about to check endpoint...");
                            
                            match tokio::time::timeout(
                                Duration::from_millis(5000), 
                                http_monitor.check_endpoint(&creds.base_url, &creds.auth_token)
                            ).await {
                                Ok(http_result) => {
                                    logger.debug_sync("SyncHealthCheck", &format!("=== HTTP CHECK COMPLETED ===: status={:?}, latency={}ms", http_result.status, http_result.latency.total.as_millis()));
                                    
                                    // Convert HttpStatus to NetworkStatus
                                    logger.debug_sync("SyncHealthCheck", "Converting HttpStatus to NetworkStatus...");
                                    let network_status = match http_result.status {
                                        crate::core::segments::network::types::HttpStatus::Success => NetworkStatus::Healthy,
                                        crate::core::segments::network::types::HttpStatus::RateLimit => NetworkStatus::Degraded {
                                            reason: "Rate limited".to_string(),
                                            details: http_result.error.clone().unwrap_or_else(|| "API rate limited".to_string()),
                                        },
                                        crate::core::segments::network::types::HttpStatus::ServerError => NetworkStatus::Degraded {
                                            reason: "Server error".to_string(),
                                            details: http_result.error.clone().unwrap_or_else(|| "API server error".to_string()),
                                        },
                                        _ => NetworkStatus::Error {
                                            error_type: http_result.error_type.clone().unwrap_or_else(|| "HTTP_ERROR".to_string()),
                                            details: http_result.error.clone().unwrap_or_else(|| "HTTP request failed".to_string()),
                                        },
                                    };
                                    logger.debug_sync("SyncHealthCheck", "NetworkStatus conversion completed");
                                    
                                    // Transition StateMachine based on health check result
                                    logger.debug_sync("SyncHealthCheck", "About to convert HttpStatus to StateEvent...");
                                    let state_event = Self::http_status_to_state_event(&http_result.status);
                                    logger.debug_sync("SyncHealthCheck", &format!("StateEvent created: {:?}", state_event));
                                    
                                    logger.debug_sync("SyncHealthCheck", "=== ABOUT TO CALL state_machine.transition() ===");
                                    let transitioned_state = state_machine.transition(state_event).await;
                                    logger.debug_sync("SyncHealthCheck", "=== state_machine.transition() COMPLETED ===");
                                    
                                    // Return complete HealthCheckResult with transitioned state
                                    logger.debug_sync("SyncHealthCheck", "Creating HealthCheckResult...");
                                    let health_result = HealthCheckResult {
                                        status: network_status,
                                        latency: http_result.latency,
                                        error: http_result.error,
                                        error_type: http_result.error_type,
                                        response_code: http_result.response_code,
                                        timestamp: Local::now(),
                                        state: transitioned_state,
                                        credentials: creds,
                                    };
                                    logger.debug_sync("SyncHealthCheck", "=== HealthCheckResult CREATED - RETURNING SUCCESS ===");
                                    
                                    Ok(health_result)
                                },
                                Err(_) => {
                                    // Create error result for timeout
                                    let error_status = NetworkStatus::Error {
                                        error_type: "HEALTH_CHECK_TIMEOUT".to_string(),
                                        details: "Health check timed out after 2 seconds".to_string(),
                                    };
                                    
                                    // Transition StateMachine for failure
                                    let transitioned_state = state_machine.transition(crate::core::segments::network::types::StateEvent::Failure).await;
                                    
                                    Ok(HealthCheckResult {
                                        status: error_status,
                                        latency: crate::core::segments::network::types::LatencyData {
                                            total: Duration::from_millis(5000),
                                            dns: None,
                                            tcp: None,
                                            tls: None,
                                            ttfb: Duration::from_millis(5000),
                                        },
                                        error: Some("Health check timed out after 5 seconds".to_string()),
                                        error_type: Some("HEALTH_CHECK_TIMEOUT".to_string()),
                                        response_code: None,
                                        timestamp: Local::now(),
                                        state: transitioned_state,
                                        credentials: creds,
                                    })
                                }
                            }
                        },
                        Err(e) => {
                            Err(e)
                        }
                    }
                },
                Ok(Ok(None)) => {
                    Err(NetworkError::NoCredentials)
                },
                Ok(Err(e)) => {
                    Err(e)
                },
                Err(_) => {
                    Err(NetworkError::WriteTimeout("Credential retrieval timed out after 1 second".to_string()))
                },
            }
        });

        // PHASE 4: Ensure proper runtime cleanup before result handling
        logger.debug_sync("SyncHealthCheck", "=== EXITED rt.block_on async block ===");
        
        // Drop the runtime explicitly to prevent cleanup issues
        drop(rt);
        logger.debug_sync("SyncHealthCheck", "Runtime dropped successfully");

        match &result {
            Ok(health_result) => {
                logger.debug_sync("SyncHealthCheck", &format!("Synchronous health check completed: {:?}", health_result.status));
                logger.debug_sync("SyncHealthCheck", "About to return HealthCheckResult from perform_sync_health_check");
            },
            Err(e) => logger.error_sync("SyncHealthCheck", &format!("Synchronous health check failed: {}", e)),
        }
        
        result
    }

    /// Write status file synchronously to prevent race condition
    fn write_status_sync(
        writer: &StatusFileWriter, 
        health_result: &HealthCheckResult, 
        logger: &crate::core::segments::network::debug_logger::DebugLogger
    ) -> Result<(), NetworkError> {
        logger.debug_sync("SyncStatusWrite", "=== ENTERED write_status_sync function ===");
        logger.debug_sync("SyncStatusWrite", "About to start writing status file synchronously");
        
        // CRITICAL FIX: Use synchronous file I/O to eliminate async runtime contention
        // No async runtime needed - synchronous operations avoid the deadlock entirely
        logger.debug_sync("SyncStatusWrite", "About to call writer.write_status_sync (synchronous file I/O)");
        
        let result = writer.write_status_sync(health_result);
        
        logger.debug_sync("SyncStatusWrite", &format!("writer.write_status_sync completed with result: {:?}", result.is_ok()));
        logger.debug_sync("SyncStatusWrite", "Synchronous file write completed - about to process result");

        match &result {
            Ok(_) => logger.debug_sync("SyncStatusWrite", "Status file written successfully"),
            Err(e) => logger.error_sync("SyncStatusWrite", &format!("Status file write failed: {}", e)),
        }
        
        logger.debug_sync("SyncStatusWrite", "=== EXITING write_status_sync function ===");
        result
    }
}

impl Segment for NetworkSegment {
    fn collect(&self, _input: &InputData) -> Option<SegmentData> {
        // Fast, non-blocking status read
        let status = match self.current_status.try_read() {
            Ok(guard) => guard.clone(),
            Err(_) => {
                // Lock unavailable, return None to avoid blocking
                return None;
            }
        };
        
        // Don't display anything if disabled
        if matches!(status, NetworkStatus::Disabled) {
            return None;
        }
        
        let rendered_status = self.status_renderer.render(&status);
        
        if rendered_status.is_empty() {
            return None;
        }
        
        // Create metadata for debugging/analysis
        let mut metadata = HashMap::new();
        metadata.insert("status_type".to_string(), status.to_string());
        metadata.insert("monitoring_enabled".to_string(), self.config.enabled.to_string());
        
        Some(SegmentData {
            primary: rendered_status,
            secondary: String::new(), // Could add verbose status here if needed
            metadata,
        })
    }
    
    fn id(&self) -> SegmentId {
        SegmentId::Network
    }
}


impl NetworkSegment {
    /// PHASE 3: Acquire process lock to prevent concurrent sync spawns
    fn acquire_sync_lock(logger: &crate::core::segments::network::debug_logger::DebugLogger) -> Result<(), NetworkError> {
        use std::fs;
        use std::io::Write;
        
        let home = std::env::var("HOME")
            .or_else(|_| std::env::var("USERPROFILE"))
            .unwrap_or_else(|_| "/tmp".to_string());
        
        let lock_file = std::path::PathBuf::from(home)
            .join(".claude")
            .join("ccstatus")
            .join("ccstatus-sync.lock");
        
        logger.debug_sync("ProcessLock", &format!("Checking for lock file: {}", lock_file.display()));
        
        // Create parent directory if it doesn't exist
        if let Some(parent) = lock_file.parent() {
            let _ = fs::create_dir_all(parent);
        }
        
        // Check if lock file exists and is recent (less than 30 seconds old)
        if let Ok(metadata) = lock_file.metadata() {
            if let Ok(modified) = metadata.modified() {
                if let Ok(duration) = modified.elapsed() {
                    if duration.as_secs() < 30 {
                        logger.debug_sync("ProcessLock", "Recent lock file found, another sync process is likely running");
                        return Err(NetworkError::ProcessLocked);
                    } else {
                        logger.debug_sync("ProcessLock", "Stale lock file found, removing it");
                        let _ = fs::remove_file(&lock_file);
                    }
                }
            }
        }
        
        // Create lock file with current timestamp
        match fs::File::create(&lock_file) {
            Ok(mut file) => {
                let timestamp = chrono::Local::now().to_rfc3339();
                let _ = file.write_all(timestamp.as_bytes());
                logger.debug_sync("ProcessLock", "Process lock acquired successfully");
                Ok(())
            }
            Err(e) => {
                logger.warn_sync("ProcessLock", &format!("Failed to create lock file: {}", e));
                Err(NetworkError::ProcessLockError(e.to_string()))
            }
        }
    }
    
    /// PHASE 3: Create fallback segment when another sync process is running
    fn create_fallback_segment(logger: &crate::core::segments::network::debug_logger::DebugLogger) -> Self {
        logger.debug_sync("Fallback", "Creating fallback segment with cached status");
        
        // Try to read existing status file
        let cached_status = if let Ok(writer) = StatusFileWriter::new() {
            if let Ok(status_data) = std::fs::read_to_string(writer.get_status_file_path()) {
                if let Ok(data) = serde_json::from_str::<crate::core::segments::network::types::StatusFileData>(&status_data) {
                    let age = chrono::Local::now().signed_duration_since(data.timestamp);
                    if age.num_seconds() < 60 { // Use cached status if less than 1 minute old
                        match data.status.as_str() {
                            "healthy" => NetworkStatus::Healthy,
                            "degraded" => NetworkStatus::Degraded {
                                reason: "Cached from previous session".to_string(),
                                details: data.network.breakdown,
                            },
                            "error" => NetworkStatus::Error {
                                error_type: data.network.error_type.unwrap_or_else(|| "CACHED_ERROR".to_string()),
                                details: data.network.breakdown,
                            },
                            _ => NetworkStatus::Unknown,
                        }
                    } else {
                        NetworkStatus::Unknown
                    }
                } else {
                    NetworkStatus::Unknown
                }
            } else {
                NetworkStatus::Unknown
            }
        } else {
            NetworkStatus::Unknown
        };
        
        logger.debug_sync("Fallback", &format!("Using cached status: {:?}", cached_status));
        
        Self {
            current_status: Arc::new(RwLock::new(cached_status)),
            status_renderer: StatusRenderer::new(),
            config: NetworkConfig::default(),
            _monitoring_handle: None,
        }
    }
    
    /// Release process lock on completion
    fn release_sync_lock(logger: &crate::core::segments::network::debug_logger::DebugLogger) {
        let home = std::env::var("HOME")
            .or_else(|_| std::env::var("USERPROFILE"))
            .unwrap_or_else(|_| "/tmp".to_string());
        
        let lock_file = std::path::PathBuf::from(home)
            .join(".claude")
            .join("ccstatus")
            .join("ccstatus-sync.lock");
        
        if lock_file.exists() {
            if let Err(e) = std::fs::remove_file(&lock_file) {
                logger.warn_sync("ProcessLock", &format!("Failed to remove lock file: {}", e));
            } else {
                logger.debug_sync("ProcessLock", "Process lock released successfully");
            }
        }
    }

    /// Manual cleanup of ccstatus files - call only during explicit shutdown
    /// 
    /// This function should be called explicitly during graceful shutdown (e.g., SIGTERM/SIGINT),
    /// NOT during normal operation. Always removes status files, conditionally removes debug logs
    /// based on CCSTATUS_DEBUG environment variable.
    /// 
    /// Note: This is NOT called automatically via Drop trait to avoid premature cleanup.
    fn cleanup_files() {
        let logger = get_debug_logger();
        logger.debug_sync("Cleanup", "Starting cleanup process");
        
        // Always delete ccstatus-monitoring.json
        if let Ok(writer) = StatusFileWriter::new() {
            let status_file_path = writer.get_status_file_path();
            logger.debug_sync("Cleanup", &format!("Checking status file: {}", status_file_path.display()));
            
            if status_file_path.exists() {
                logger.debug_sync("Cleanup", &format!("Status file exists, attempting to delete: {}", status_file_path.display()));
                match std::fs::remove_file(status_file_path) {
                    Ok(()) => {
                        logger.info_sync("Cleanup", &format!("Deleted status file: {}", status_file_path.display()));
                    }
                    Err(e) => {
                        logger.warn_sync("Cleanup", &format!("Failed to delete status file {}: {}", status_file_path.display(), e));
                    }
                }
            } else {
                logger.debug_sync("Cleanup", &format!("Status file does not exist: {}", status_file_path.display()));
            }
        } else {
            logger.warn_sync("Cleanup", "Failed to create StatusFileWriter for cleanup");
        }
        
        // Conditionally delete network-debug.log if CCSTATUS_DEBUG=1
        let debug_env = env::var("CCSTATUS_DEBUG").unwrap_or_default();
        logger.debug_sync("Cleanup", &format!("CCSTATUS_DEBUG environment variable: '{}'", debug_env));
        
        if debug_env == "1" {
            if let Ok(debug_log_path) = crate::core::segments::network::debug_logger::DebugLogger::get_debug_log_path() {
                logger.debug_sync("Cleanup", &format!("Checking debug log file: {}", debug_log_path.display()));
                
                if debug_log_path.exists() {
                    logger.debug_sync("Cleanup", &format!("Debug log exists, attempting to delete: {}", debug_log_path.display()));
                    match std::fs::remove_file(&debug_log_path) {
                        Ok(()) => {
                            logger.info_sync("Cleanup", &format!("Deleted debug log: {}", debug_log_path.display()));
                        }
                        Err(e) => {
                            logger.warn_sync("Cleanup", &format!("Failed to delete debug log {}: {}", debug_log_path.display(), e));
                        }
                    }
                } else {
                    logger.debug_sync("Cleanup", &format!("Debug log does not exist: {}", debug_log_path.display()));
                }
            } else {
                logger.warn_sync("Cleanup", "Failed to get debug log path");
            }
        } else {
            logger.debug_sync("Cleanup", "Debug mode not enabled, skipping debug log cleanup");
        }
        
        logger.debug_sync("Cleanup", "Cleanup process completed");
    }
}

impl MonitoringEngine {
    /// Create new monitoring engine
    async fn new(
        current_status: Arc<RwLock<NetworkStatus>>, 
        config: NetworkConfig
    ) -> Result<Self, NetworkError> {
        let credential_manager = CredentialManager::new()?;
        let http_monitor = HttpMonitor::new(&config).await?;
        
        // Try to load previous state from status file
        let status_writer = StatusFileWriter::new()?;
        let state_machine = if let Ok(status_data) = std::fs::read_to_string(status_writer.get_status_file_path()) {
            if let Ok(data) = serde_json::from_str::<crate::core::segments::network::types::StatusFileData>(&status_data) {
                // Check if status is recent (within last 30 seconds)
                let age = Local::now().signed_duration_since(data.timestamp);
                if age.num_seconds() < 30 {
                    // Restore state from JSON with proper type conversion
                    let restored_state = NetworkSegment::parse_monitoring_state(&data.monitoring_state);
                    StateMachine::from_state(restored_state)
                } else {
                    // Status file is stale but preserve StateMachine progression
                    let restored_state = NetworkSegment::parse_monitoring_state(&data.monitoring_state);
                    StateMachine::from_state(restored_state)
                }
            } else {
                // Failed to parse JSON, start fresh
                StateMachine::new()
            }
        } else {
            // No status file exists, start fresh
            StateMachine::new()
        };
        
        // Initialize JSONL monitor for error capture
        let jsonl_monitor = Self::create_jsonl_monitor().await.ok();
        
        Ok(Self {
            credential_manager,
            http_monitor,
            state_machine,
            status_writer,
            jsonl_monitor,
            current_status,
        })
    }
    
    /// Create JSONL monitor with smart project directory detection
    async fn create_jsonl_monitor() -> Result<JsonlMonitor, NetworkError> {
        // Get current working directory (where ccstatus was started)
        let pwd = env::current_dir().map_err(|_| NetworkError::DirectoryDetectionError)?;
        
        // Convert absolute path to Claude project format by replacing '/' with '-'
        let pwd_str = pwd.to_string_lossy();
        let claude_project_name = pwd_str.replace('/', "-");
        
        // Get home directory
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        // Construct project-specific path: ~/.claude/projects/{project-name}/
        let project_dir = std::path::PathBuf::from(&home)
            .join(".claude")
            .join("projects")
            .join(claude_project_name);
        
        // Global error capture file: ~/.claude/ccstatus/ccstatus-captured-error.json
        let global_error_file = std::path::PathBuf::from(&home)
            .join(".claude")
            .join("ccstatus")
            .join("ccstatus-captured-error.json");
        
        let config = JsonlMonitorConfig {
            project_dir,
            global_error_file,
            check_interval: Duration::from_secs(5),
            max_file_age: Duration::from_secs(24 * 60 * 60), // 24 hours
        };
        
        Ok(JsonlMonitor::new(config))
    }
    
    /// Main monitoring loop
    async fn run_monitoring_loop(mut self) {
        let logger = get_debug_logger();
        logger.log_engine_event("Loop Started", "Main monitoring loop started").await;
        
        // Start JSONL monitoring in parallel if available
        if let Some(mut jsonl_monitor) = self.jsonl_monitor.take() {
            logger.debug("JSONL", "Starting JSONL monitoring in background").await;
            tokio::spawn(async move {
                if let Err(e) = jsonl_monitor.start_monitoring().await {
                    eprintln!("JSONL monitoring failed: {}", e);
                }
            });
            logger.debug("JSONL", "JSONL monitor spawned successfully").await;
        } else {
            logger.debug("JSONL", "No JSONL monitor available").await;
        }
        
        // Add debug log right before credential retrieval
        logger.debug("MonitoringLoop", "About to attempt credential retrieval").await;
        
        // Try to get credentials once at startup
        logger.debug("Credentials", "Attempting to retrieve credentials at startup").await;
        let credentials = match self.credential_manager.get_credentials().await {
            Ok(Some(creds)) => {
                // Log successful credential retrieval
                let source = match &creds.source {
                    crate::core::segments::network::types::CredentialSource::Environment => "environment",
                    crate::core::segments::network::types::CredentialSource::ShellConfig(_) => "shell_config",
                    crate::core::segments::network::types::CredentialSource::ClaudeConfig(_) => "claude_config",
                };
                logger.log_credential_event("Retrieved", source, true).await;
                logger.info("Credentials", &format!("Using endpoint: {}", creds.base_url)).await;
                logger.debug("Credentials", &"Credential retrieval SUCCESS - proceeding to health check loop".to_string()).await;
                creds
            },
            Ok(None) => {
                // Log credential failure
                logger.log_credential_event("Lookup", "all_sources", false).await;
                logger.error("Credentials", "No credentials found in any source").await;
                
                // No credentials - set specific error status and exit
                let error_status = NetworkStatus::Error {
                    error_type: "NO_CREDENTIALS".to_string(),
                    details: "Claude Code credentials not found. Set ANTHROPIC_BASE_URL and ANTHROPIC_AUTH_TOKEN as environment variables, or add exports to ~/.zshrc, or define them in shell functions (like cc-env)".to_string(),
                };
                
                logger.log_status_transition("Unknown", "Error", "No credentials found").await;
                self.set_status(error_status.clone()).await;
                let _ = self.status_writer.write_error_status(&error_status).await;
                logger.warn("MonitoringEngine", "Exiting monitoring loop due to missing credentials").await;
                return;
            }
            Err(e) => {
                // Log credential error
                logger.error("Credentials", &format!("Failed to retrieve credentials: {}", e)).await;
                
                // Error getting credentials - set specific error status and exit
                let error_status = NetworkStatus::Error {
                    error_type: "CREDENTIAL_ERROR".to_string(),
                    details: format!("Failed to retrieve credentials: {}", e),
                };
                
                logger.log_status_transition("Unknown", "Error", &format!("Credential error: {}", e)).await;
                self.set_status(error_status.clone()).await;
                let _ = self.status_writer.write_error_status(&error_status).await;
                logger.warn("MonitoringEngine", "Exiting monitoring loop due to credential error").await;
                return;
            }
        };
        
        logger.info("MonitoringEngine", "Starting main health check loop").await;
        logger.debug("MonitoringEngine", "ENTERED MAIN LOOP - about to start health check iterations").await;
        let mut loop_iteration = 0u64;
        
        loop {
            loop_iteration += 1;
            logger.debug("HealthCheck", &format!("Starting health check iteration #{}", loop_iteration)).await;
            logger.debug("HealthCheck", &format!("Iteration #{}: About to perform health check with endpoint: {}", loop_iteration, credentials.base_url)).await;
            // Perform health check
            logger.debug("HealthCheck", &format!("Iteration #{}: About to call perform_health_check", loop_iteration)).await;
            let start_time = std::time::Instant::now();
            let check_result = self.perform_health_check(&credentials).await;
            let check_duration = start_time.elapsed();
            logger.debug("HealthCheck", &format!("Iteration #{}: Health check completed in {}ms", loop_iteration, check_duration.as_millis())).await;
            
            // Log health check result
            logger.log_health_check(
                &credentials.base_url,
                check_result.response_code,
                check_result.latency.total.as_millis() as u64,
                check_result.error.as_deref()
            ).await;
            
            // Update status
            let old_status = {
                let status_guard = self.current_status.read().await;
                status_guard.clone()
            };
            
            self.set_status(check_result.status.clone()).await;
            
            // Log status transition if changed
            if !matches!((&old_status, &check_result.status), 
                (NetworkStatus::Healthy, NetworkStatus::Healthy) |
                (NetworkStatus::Unknown, NetworkStatus::Unknown) |
                (NetworkStatus::Disabled, NetworkStatus::Disabled)
            ) {
                let from = format!("{:?}", old_status).split(' ').next().unwrap_or("Unknown").to_string();
                let to = format!("{:?}", check_result.status).split(' ').next().unwrap_or("Unknown").to_string();
                logger.log_status_transition(&from, &to, &format!("Health check result after {}ms", check_duration.as_millis())).await;
            }
            
            // Write status to file (ignore errors - fail silent)
            let write_start = std::time::Instant::now();
            let write_result = self.status_writer.write_status(&check_result).await;
            let write_duration = write_start.elapsed();
            
            // Log status file write result
            let status_file_path = self.status_writer.get_status_file_path().to_string_lossy().to_string();
            logger.log_status_file_event(
                "Write",
                &status_file_path,
                write_result.is_ok(),
                Some(write_duration.as_millis() as u64)
            ).await;
            
            // Get next check interval from state machine
            let interval = self.state_machine.get_current_interval().await;
            
            // Log next check interval
            logger.debug("HealthCheck", &format!("Iteration #{} complete, sleeping for {}s until next check", loop_iteration, interval.as_secs())).await;
            
            // Sleep until next check
            tokio::time::sleep(interval).await;
        }
    }
    
    /// Perform a single health check
    async fn perform_health_check(&self, credentials: &crate::core::segments::network::types::ApiCredentials) -> HealthCheckResult {
        let logger = get_debug_logger();
        logger.debug("PerformHealthCheck", &format!("Starting health check with endpoint: {}", credentials.base_url)).await;
        
        let start_time = Local::now();
        
        // Perform HTTP health check
        logger.debug("PerformHealthCheck", "About to call http_monitor.check_endpoint").await;
        let http_result = self.http_monitor.check_endpoint(
            &credentials.base_url,
            &credentials.auth_token,
        ).await;
        
        logger.debug("PerformHealthCheck", &format!("HTTP check completed: status={:?}, latency={}ms", http_result.status, http_result.latency.total.as_millis())).await;
        
        // Update state machine based on result
        let state_event = NetworkSegment::http_status_to_state_event(&http_result.status);
        
        let new_state = self.state_machine.transition(state_event).await;
        
        // Determine final status based on HTTP result and state
        let final_status = self.determine_status(&http_result, &new_state);
        
        HealthCheckResult {
            status: final_status,
            latency: http_result.latency,
            error: http_result.error,
            error_type: http_result.error_type,
            timestamp: start_time,
            state: new_state,
            credentials: credentials.clone(),
            response_code: http_result.response_code,
        }
    }
    
    /// Determine final status based on HTTP result and state machine state
    fn determine_status(
        &self, 
        http_result: &crate::core::segments::network::types::HttpResult, 
        state: &MonitoringState
    ) -> NetworkStatus {
        use crate::core::segments::network::types::HttpStatus;
        
        match (&http_result.status, state) {
            (HttpStatus::Success, _) if http_result.latency.total < Duration::from_millis(500) => {
                NetworkStatus::Healthy
            }
            (HttpStatus::Success, _) => {
                NetworkStatus::Degraded {
                    reason: "High latency".to_string(),
                    details: http_result.latency.format_breakdown(),
                }
            }
            (HttpStatus::RateLimit, _) => {
                NetworkStatus::Degraded {
                    reason: "Rate limited".to_string(),
                    details: http_result.latency.format_breakdown(),
                }
            }
            (HttpStatus::AuthError, _) => {
                NetworkStatus::Error {
                    error_type: "AUTH_ERROR".to_string(),
                    details: "Invalid credentials".to_string(),
                }
            }
            _ => {
                NetworkStatus::Error {
                    error_type: http_result.error.clone().unwrap_or_else(|| "UNKNOWN_ERROR".to_string()),
                    details: http_result.latency.format_breakdown(),
                }
            }
        }
    }
    
    /// Update current status
    async fn set_status(&self, status: NetworkStatus) {
        let mut current = self.current_status.write().await;
        *current = status;
    }
}
