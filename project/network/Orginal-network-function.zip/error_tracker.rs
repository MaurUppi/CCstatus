//! Error tracking and categorization for network monitoring

use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;
use chrono::{DateTime, Utc};
use crate::core::segments::network::types::ErrorRecord;

/// Tracks and categorizes network errors
pub struct ErrorTracker {
    errors: Arc<RwLock<HashMap<String, ErrorRecord>>>,
}

impl ErrorTracker {
    /// Create new error tracker
    pub fn new() -> Self {
        Self {
            errors: Arc::new(RwLock::new(HashMap::new())),
        }
    }
    
    /// Record an error occurrence
    pub async fn record_error(&self, error_type: &str, error_code: Option<u16>) {
        let mut errors = self.errors.write().await;
        let now = Utc::now();
        
        match errors.get_mut(error_type) {
            Some(record) => {
                record.last_occurrence = now;
                record.count += 1;
                // Update error code if provided
                if error_code.is_some() {
                    record.error_code = error_code;
                }
            }
            None => {
                errors.insert(error_type.to_string(), ErrorRecord {
                    first_occurrence: now,
                    last_occurrence: now,
                    count: 1,
                    error_code,
                });
            }
        }
        
        // Maintain bounded size - keep only the most recent 50 error types
        if errors.len() > 50 {
            // Remove the oldest error types by first occurrence
            let mut error_list: Vec<_> = errors.iter()
                .map(|(k, v)| (k.clone(), v.first_occurrence))
                .collect();
            error_list.sort_by_key(|(_, time)| *time);
            
            // Remove the oldest 10 to get back under limit
            for (error_type, _) in error_list.into_iter().take(10) {
                errors.remove(&error_type);
            }
        }
    }
    
    /// Get summary of all errors with first and last occurrence times
    pub async fn get_error_summary(&self) -> HashMap<String, (DateTime<Utc>, DateTime<Utc>)> {
        let errors = self.errors.read().await;
        errors.iter()
            .map(|(k, v)| (k.clone(), (v.first_occurrence, v.last_occurrence)))
            .collect()
    }
    
    /// Get detailed error records
    pub async fn get_error_records(&self) -> HashMap<String, ErrorRecord> {
        let errors = self.errors.read().await;
        errors.clone()
    }
    
    /// Get error count for specific error type
    pub async fn get_error_count(&self, error_type: &str) -> u32 {
        let errors = self.errors.read().await;
        errors.get(error_type).map(|r| r.count).unwrap_or(0)
    }
    
    /// Get total error count across all types
    pub async fn get_total_error_count(&self) -> u32 {
        let errors = self.errors.read().await;
        errors.values().map(|r| r.count).sum()
    }
    
    /// Get most recent error
    pub async fn get_most_recent_error(&self) -> Option<(String, DateTime<Utc>)> {
        let errors = self.errors.read().await;
        errors.iter()
            .max_by_key(|(_, record)| record.last_occurrence)
            .map(|(error_type, record)| (error_type.clone(), record.last_occurrence))
    }
    
    /// Get most frequent error
    pub async fn get_most_frequent_error(&self) -> Option<(String, u32)> {
        let errors = self.errors.read().await;
        errors.iter()
            .max_by_key(|(_, record)| record.count)
            .map(|(error_type, record)| (error_type.clone(), record.count))
    }
    
    /// Clear errors older than the specified cutoff time
    pub async fn clear_old_errors(&self, cutoff: DateTime<Utc>) {
        let mut errors = self.errors.write().await;
        errors.retain(|_, record| record.last_occurrence > cutoff);
    }
    
    /// Clear all error records
    pub async fn clear_all(&self) {
        let mut errors = self.errors.write().await;
        errors.clear();
    }
    
    /// Get error types that occurred in the last N minutes
    pub async fn get_recent_errors(&self, minutes: i64) -> Vec<String> {
        let cutoff = Utc::now() - chrono::Duration::minutes(minutes);
        let errors = self.errors.read().await;
        
        errors.iter()
            .filter(|(_, record)| record.last_occurrence > cutoff)
            .map(|(error_type, _)| error_type.clone())
            .collect()
    }
    
    /// Check if a specific error type has occurred recently
    pub async fn has_recent_error(&self, error_type: &str, minutes: i64) -> bool {
        let cutoff = Utc::now() - chrono::Duration::minutes(minutes);
        let errors = self.errors.read().await;
        
        errors.get(error_type)
            .map(|record| record.last_occurrence > cutoff)
            .unwrap_or(false)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::Duration;

    #[tokio::test]
    async fn test_error_tracker_new() {
        let tracker = ErrorTracker::new();
        let count = tracker.get_total_error_count().await;
        assert_eq!(count, 0);
    }

    #[tokio::test]
    async fn test_record_and_count_errors() {
        let tracker = ErrorTracker::new();
        
        // Record some errors
        tracker.record_error("NETWORK_TIMEOUT", None).await;
        tracker.record_error("NETWORK_TIMEOUT", None).await;
        tracker.record_error("CONNECTION_FAILED", Some(500)).await;
        
        let timeout_count = tracker.get_error_count("NETWORK_TIMEOUT").await;
        assert_eq!(timeout_count, 2);
        
        let connection_count = tracker.get_error_count("CONNECTION_FAILED").await;
        assert_eq!(connection_count, 1);
        
        let total_count = tracker.get_total_error_count().await;
        assert_eq!(total_count, 3);
    }

    #[tokio::test]
    async fn test_error_summary() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("TEST_ERROR", Some(404)).await;
        
        let summary = tracker.get_error_summary().await;
        assert!(summary.contains_key("TEST_ERROR"));
        
        let (first, last) = summary["TEST_ERROR"];
        assert_eq!(first, last); // First occurrence should equal last for single error
    }

    #[tokio::test]
    async fn test_most_frequent_error() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("FREQUENT_ERROR", None).await;
        tracker.record_error("FREQUENT_ERROR", None).await;
        tracker.record_error("FREQUENT_ERROR", None).await;
        tracker.record_error("RARE_ERROR", None).await;
        
        let most_frequent = tracker.get_most_frequent_error().await;
        assert!(most_frequent.is_some());
        
        let (error_type, count) = most_frequent.unwrap();
        assert_eq!(error_type, "FREQUENT_ERROR");
        assert_eq!(count, 3);
    }

    #[tokio::test]
    async fn test_recent_errors() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("RECENT_ERROR", None).await;
        
        let recent = tracker.get_recent_errors(5).await; // Last 5 minutes
        assert_eq!(recent.len(), 1);
        assert_eq!(recent[0], "RECENT_ERROR");
        
        let has_recent = tracker.has_recent_error("RECENT_ERROR", 5).await;
        assert!(has_recent);
        
        let has_old = tracker.has_recent_error("NONEXISTENT_ERROR", 5).await;
        assert!(!has_old);
    }

    #[tokio::test]
    async fn test_clear_old_errors() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("OLD_ERROR", None).await;
        
        // Clear errors older than 1 minute ago
        let cutoff = Utc::now() + Duration::minutes(1);
        tracker.clear_old_errors(cutoff).await;
        
        let count = tracker.get_total_error_count().await;
        assert_eq!(count, 0); // All errors should be cleared
    }

    #[tokio::test]
    async fn test_bounded_error_types() {
        let tracker = ErrorTracker::new();
        
        // Record more than 50 different error types
        for i in 0..60 {
            tracker.record_error(&format!("ERROR_TYPE_{}", i), None).await;
        }
        
        let records = tracker.get_error_records().await;
        assert!(records.len() <= 50); // Should be bounded to 50 or fewer
    }

    #[tokio::test]
    async fn test_most_recent_error() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("FIRST_ERROR", None).await;
        // Small delay to ensure different timestamps
        tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
        tracker.record_error("SECOND_ERROR", None).await;
        
        let most_recent = tracker.get_most_recent_error().await;
        assert!(most_recent.is_some());
        
        let (error_type, _) = most_recent.unwrap();
        assert_eq!(error_type, "SECOND_ERROR");
    }

    #[tokio::test]
    async fn test_clear_all() {
        let tracker = ErrorTracker::new();
        
        tracker.record_error("TEST_ERROR", None).await;
        assert_eq!(tracker.get_total_error_count().await, 1);
        
        tracker.clear_all().await;
        assert_eq!(tracker.get_total_error_count().await, 0);
    }
}