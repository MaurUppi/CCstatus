//! Status file writer for shell integration
//! 
//! Writes network monitoring status to JSON file for consumption by shell scripts.

use std::env;
use std::path::PathBuf;
use tokio::fs;
use std::fs as sync_fs;
use chrono::Local;
use crate::core::segments::network::types::{
    NetworkError, HealthCheckResult, StatusFileData, ApiConfigData, NetworkData, 
    MonitoringStateData, NetworkStatus, CredentialSource
};
use crate::core::segments::network::debug_logger::get_debug_logger;

/// Writes status updates to file for shell integration
pub struct StatusFileWriter {
    status_file_path: PathBuf,
}

impl StatusFileWriter {
    /// Create new status file writer with global directory priority
    pub fn new() -> Result<Self, NetworkError> {
        // Use global path first for consistency with debug log location
        let status_file_path = Self::get_global_status_path();
        
        Ok(Self { status_file_path })
    }
    
    /// Fallback to global status file path (for backwards compatibility)
    fn get_global_status_path() -> PathBuf {
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .unwrap_or_else(|_| "/tmp".to_string());
        
        PathBuf::from(home)
            .join(".claude")
            .join("ccstatus")
            .join("ccstatus-monitoring.json")
    }
    
    /// Create status file writer with custom path
    pub fn with_path(path: PathBuf) -> Self {
        Self { status_file_path: path }
    }
    
    /// Ensure the parent directory exists for the status file
    async fn ensure_directory_exists(&self) -> Result<(), NetworkError> {
        if let Some(parent) = self.status_file_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).await
                    .map_err(|e| NetworkError::DirectoryCreationError(e))?
            }
        }
        Ok(())
    }
    
    /// Synchronous version of ensure_directory_exists (eliminates async runtime contention)
    fn ensure_directory_exists_sync(&self) -> Result<(), NetworkError> {
        if let Some(parent) = self.status_file_path.parent() {
            if !parent.exists() {
                sync_fs::create_dir_all(parent)
                    .map_err(|e| NetworkError::DirectoryCreationError(e))?
            }
        }
        Ok(())
    }
    
    /// Write health check result to status file
    pub async fn write_status(&self, result: &HealthCheckResult) -> Result<(), NetworkError> {
        let logger = get_debug_logger();
        let file_path_str = self.status_file_path.to_string_lossy().to_string();
        
        // Log the write attempt
        logger.debug("StatusWriter", &format!("Writing status to: {}", file_path_str)).await;
        
        // Ensure directory exists
        self.ensure_directory_exists().await?;
        
        let status_data = StatusFileData {
            status: result.status.to_string(),
            monitoring_enabled: true,
            api_config: ApiConfigData {
                endpoint: result.credentials.base_url.clone(),
                source: self.credential_source_to_string(&result.credentials.source),
            },
            network: NetworkData {
                latency_ms: result.latency.total.as_millis() as u32,
                breakdown: result.latency.format_breakdown(),
                http_status_code: result.response_code,
                error_type: result.error_type.clone(),
            },
            monitoring_state: MonitoringStateData::from(&result.state),
            timestamp: result.timestamp,
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Log the status data being written
        logger.debug("StatusWriter", &format!("Status: '{}', Error Type: {:?}, Latency: {}ms", 
            status_data.status, 
            status_data.network.error_type,
            status_data.network.latency_ms)).await;
        
        // Atomic write using temporary file
        let temp_file = self.status_file_path.with_extension("tmp");
        
        fs::write(&temp_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        fs::rename(&temp_file, &self.status_file_path).await
            .map_err(NetworkError::FileWriteError)?;
        
        logger.debug("StatusWriter", &format!("Successfully wrote status file: {}", file_path_str)).await;
        
        Ok(())
    }
    
    /// Synchronous version of write_status (eliminates async runtime contention)
    pub fn write_status_sync(&self, result: &HealthCheckResult) -> Result<(), NetworkError> {
        let logger = get_debug_logger();
        let file_path_str = self.status_file_path.to_string_lossy().to_string();
        
        // Log the write attempt (synchronous logging)
        logger.debug_sync("StatusWriter", &format!("Writing status synchronously to: {}", file_path_str));
        
        // Ensure directory exists synchronously
        self.ensure_directory_exists_sync()?;
        
        let status_data = StatusFileData {
            status: result.status.to_string(),
            monitoring_enabled: true,
            api_config: ApiConfigData {
                endpoint: result.credentials.base_url.clone(),
                source: self.credential_source_to_string(&result.credentials.source),
            },
            network: NetworkData {
                latency_ms: result.latency.total.as_millis() as u32,
                breakdown: result.latency.format_breakdown(),
                http_status_code: result.response_code,
                error_type: result.error_type.clone(),
            },
            monitoring_state: MonitoringStateData::from(&result.state),
            timestamp: result.timestamp,
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Log the status data being written (synchronous logging)
        logger.debug_sync("StatusWriter", &format!("Status: '{}', Error Type: {:?}, Latency: {}ms", 
            status_data.status, 
            status_data.network.error_type,
            status_data.network.latency_ms));
        
        // Atomic write using temporary file (SYNCHRONOUS FILE I/O)
        let temp_file = self.status_file_path.with_extension("tmp");
        
        sync_fs::write(&temp_file, json_content)
            .map_err(NetworkError::FileWriteError)?;
        
        sync_fs::rename(&temp_file, &self.status_file_path)
            .map_err(NetworkError::FileWriteError)?;
        
        logger.debug_sync("StatusWriter", &format!("Successfully wrote status file synchronously: {}", file_path_str));
        
        Ok(())
    }
    
    /// Write status with additional context information
    pub async fn write_detailed_status(
        &self, 
        result: &HealthCheckResult,
        endpoint: &str,
        credential_source: &CredentialSource,
        error_code: Option<u16>
    ) -> Result<(), NetworkError> {
        // Ensure directory exists
        self.ensure_directory_exists().await?;
        
        let status_data = StatusFileData {
            status: result.status.to_string(),
            monitoring_enabled: true,
            api_config: ApiConfigData {
                endpoint: endpoint.to_string(),
                source: self.credential_source_to_string(credential_source),
            },
            network: NetworkData {
                latency_ms: result.latency.total.as_millis() as u32,
                breakdown: result.latency.format_breakdown(),
                http_status_code: error_code,
                error_type: result.error_type.clone(),
            },
            monitoring_state: MonitoringStateData::from(&result.state),
            timestamp: result.timestamp,
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Atomic write using temporary file
        let temp_file = self.status_file_path.with_extension("tmp");
        
        fs::write(&temp_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        fs::rename(&temp_file, &self.status_file_path).await
            .map_err(NetworkError::FileWriteError)?;
        
        Ok(())
    }
    
    /// Write monitoring disabled status
    pub async fn write_disabled_status(&self) -> Result<(), NetworkError> {
        // Ensure directory exists
        self.ensure_directory_exists().await?;
        
        let status_data = StatusFileData {
            status: "disabled".to_string(),
            monitoring_enabled: false,
            api_config: ApiConfigData {
                endpoint: "none".to_string(),
                source: "none".to_string(),
            },
            network: NetworkData {
                latency_ms: 0,
                breakdown: "disabled".to_string(),
                http_status_code: None,
                error_type: None,
            },
            monitoring_state: MonitoringStateData {
                state: "disabled".to_string(),
                interval_seconds: 0,
                consecutive_successes: None,
                consecutive_failures: None,
            },
            timestamp: Local::now(),
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Atomic write using temporary file
        let temp_file = self.status_file_path.with_extension("tmp");
        
        fs::write(&temp_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        fs::rename(&temp_file, &self.status_file_path).await
            .map_err(NetworkError::FileWriteError)?;
        
        Ok(())
    }
    
    /// Read current status from file
    pub async fn read_current_status(&self) -> Result<StatusFileData, NetworkError> {
        let content = fs::read_to_string(&self.status_file_path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        let status_data: StatusFileData = serde_json::from_str(&content)
            .map_err(NetworkError::ConfigParseError)?;
        
        Ok(status_data)
    }
    
    /// Check if status file exists
    pub fn status_file_exists(&self) -> bool {
        self.status_file_path.exists()
    }
    
    /// Get status file path
    pub fn get_status_file_path(&self) -> &PathBuf {
        &self.status_file_path
    }
    
    /// Remove status file
    pub async fn remove_status_file(&self) -> Result<(), NetworkError> {
        if self.status_file_exists() {
            fs::remove_file(&self.status_file_path).await
                .map_err(NetworkError::FileWriteError)?;
        }
        Ok(())
    }
    

    
    /// Convert CredentialSource to string
    fn credential_source_to_string(&self, source: &CredentialSource) -> String {
        match source {
            CredentialSource::Environment => "environment".to_string(),
            CredentialSource::ShellConfig(path) => {
                format!("shell:{}", path.display())
            }
            CredentialSource::ClaudeConfig(path) => {
                format!("config:{}", path.display())
            }
        }
    }
    
    /// Write status if changed from previous write
    pub async fn write_status_if_changed(&self, result: &HealthCheckResult) -> Result<bool, NetworkError> {
        // Try to read current status
        if let Ok(current) = self.read_current_status().await {
            let new_status_str = result.status.to_string();
            let new_latency_ms = result.latency.total.as_millis() as u32;
            
            // Check if status or latency changed significantly
            let status_changed = current.status != new_status_str;
            let latency_changed = {
                let diff = if new_latency_ms > current.network.latency_ms {
                    new_latency_ms - current.network.latency_ms
                } else {
                    current.network.latency_ms - new_latency_ms
                };
                diff > 50 // Consider 50ms+ change significant
            };
            
            if status_changed || latency_changed {
                self.write_status(result).await?;
                Ok(true)
            } else {
                Ok(false) // No change, didn't write
            }
        } else {
            // No existing file, write status
            self.write_status(result).await?;
            Ok(true)
        }
    }
    
    /// Write error status directly from NetworkStatus
    pub async fn write_error_status(&self, status: &NetworkStatus) -> Result<(), NetworkError> {
        // Ensure directory exists
        self.ensure_directory_exists().await?;
        
        let (error_type, error_details) = match status {
            NetworkStatus::Error { error_type, details } => {
                (Some(error_type.clone()), Some(details.clone()))
            }
            _ => (None, None)
        };
        
        let status_data = StatusFileData {
            status: status.to_string(),
            monitoring_enabled: false, // Disabled when in error state
            api_config: ApiConfigData {
                endpoint: "unknown".to_string(),
                source: "error".to_string(),
            },
            network: NetworkData {
                latency_ms: 0,
                breakdown: error_details.unwrap_or_else(|| "error_state".to_string()),
                http_status_code: None,
                error_type,
            },
            monitoring_state: MonitoringStateData {
                state: "error".to_string(),
                interval_seconds: 0,
                consecutive_successes: None,
                consecutive_failures: None,
            },
            timestamp: Local::now(),
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Atomic write using temporary file
        let temp_file = self.status_file_path.with_extension("tmp");
        
        fs::write(&temp_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        fs::rename(&temp_file, &self.status_file_path).await
            .map_err(NetworkError::FileWriteError)?;
        
        Ok(())
    }
}

impl Clone for StatusFileWriter {
    fn clone(&self) -> Self {
        Self {
            status_file_path: self.status_file_path.clone(),
        }
    }
}

// Tests for this module have been moved to tests/network/status_file_writer_tests.rs