//! Credential management for network monitoring
//! 
//! Handles secure credential resolution from environment variables and Claude Code config files.

use std::env;
use std::path::PathBuf;
use serde_json::Value;
use crate::core::segments::network::types::{ApiCredentials, CredentialSource, NetworkError};
use crate::core::segments::network::shell_config_reader::ShellConfigReader;

/// Manages credential resolution from various sources
pub struct CredentialManager {
    claude_config_paths: Vec<PathBuf>,
}

impl CredentialManager {
    /// Create new credential manager
    pub fn new() -> Result<Self, NetworkError> {
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        let home_path = PathBuf::from(home);
        
        let claude_config_paths = vec![
            home_path.join(".claude").join("settings.json"),
            PathBuf::from(".claude").join("settings.local.json"),
            PathBuf::from(".claude").join("settings.json"),
        ];
        
        Ok(Self { claude_config_paths })
    }
    
    /// Get credentials from environment or config files
    /// 
    /// Priority order:
    /// 1. Environment variables (ANTHROPIC_BASE_URL + ANTHROPIC_AUTH_TOKEN)
    /// 2. Shell configuration files (.zshrc, .bashrc, PowerShell profiles)
    /// 3. Claude Code config files
    /// 4. None (fail silent)
    pub async fn get_credentials(&self) -> Result<Option<ApiCredentials>, NetworkError> {
        use crate::core::segments::network::debug_logger::get_debug_logger;
        let logger = get_debug_logger();
        
        logger.debug("CredentialManager", "Starting credential lookup from all sources").await;
        
        // Priority 1: Environment variables
        logger.debug("CredentialManager", "Checking environment variables...").await;
        let env_result = self.get_from_environment();
        logger.debug("CredentialManager", &format!("Environment check completed: {}", env_result.is_ok())).await;
        
        match env_result {
            Ok(Some(creds)) => {
                logger.debug("CredentialManager", &format!("Found env credentials: endpoint={}, token_len={}", creds.base_url, creds.auth_token.len())).await;
                return Ok(Some(creds));
            },
            Ok(None) => {
                logger.debug("CredentialManager", "Environment variables not set (ANTHROPIC_BASE_URL or ANTHROPIC_AUTH_TOKEN missing)").await;
            },
            Err(e) => {
                logger.debug("CredentialManager", &format!("Environment variable error: {}", e)).await;
                return Err(e);
            }
        }
        
        // Priority 2: Shell configuration files
        logger.debug("CredentialManager", "About to check shell config files...").await;
        
        // Try shell config with detailed error handling and logging
        match ShellConfigReader::new() {
            Ok(shell_reader) => {
                logger.debug("CredentialManager", "ShellConfigReader created successfully").await;
                
                match shell_reader.get_credentials().await {
                    Ok(Some(creds)) => {
                        logger.debug("CredentialManager", &format!("Found shell credentials: endpoint={}, token_len={}", creds.base_url, creds.auth_token.len())).await;
                        return Ok(Some(creds));
                    },
                    Ok(None) => {
                        logger.debug("CredentialManager", "ShellConfigReader returned None (no credentials found in shell configs)").await;
                    },
                    Err(e) => {
                        logger.debug("CredentialManager", &format!("ShellConfigReader credential error: {}", e)).await;
                    }
                }
            },
            Err(e) => {
                logger.debug("CredentialManager", &format!("Failed to create ShellConfigReader: {}", e)).await;
            }
        }
        
        logger.debug("CredentialManager", "Shell config check completed, no credentials found").await;
        
        // Priority 3: Claude Code config files
        logger.debug("CredentialManager", "About to check Claude config files...").await;
        
        for (index, config_path) in self.claude_config_paths.iter().enumerate() {
            logger.debug("CredentialManager", &format!("Checking config file #{}: {}", index + 1, config_path.display())).await;
            
            match self.get_from_claude_config(config_path).await {
                Ok(Some(creds)) => {
                    logger.debug("CredentialManager", &format!("Found config credentials in file #{}: endpoint={}, token_len={}", index + 1, creds.base_url, creds.auth_token.len())).await;
                    return Ok(Some(creds));
                },
                Ok(None) => {
                    logger.debug("CredentialManager", &format!("Config file #{} exists but has no credentials (file: {})", index + 1, config_path.display())).await;
                },
                Err(e) => {
                    logger.debug("CredentialManager", &format!("Config file #{} error: {} (file: {})", index + 1, e, config_path.display())).await;
                }
            }
        }
        logger.debug("CredentialManager", "All Claude config files checked, no credentials found").await;
        
        // No credentials found
        logger.error("CredentialManager", "FINAL RESULT: No credentials found in any source (env, shell, or config files)").await;
        Ok(None)
    }
    
    /// Try to get credentials from environment variables
    fn get_from_environment(&self) -> Result<Option<ApiCredentials>, NetworkError> {
        // Check for base URL + token combination
        if let (Ok(base_url), Ok(auth_token)) = (
            env::var("ANTHROPIC_BASE_URL"),
            env::var("ANTHROPIC_AUTH_TOKEN")
        ) {
            return Ok(Some(ApiCredentials {
                base_url,
                auth_token,
                source: CredentialSource::Environment,
            }));
        }
        
        Ok(None)
    }
    
    /// Try to get credentials from Claude Code config file
    async fn get_from_claude_config(
        &self, 
        config_path: &PathBuf
    ) -> Result<Option<ApiCredentials>, NetworkError> {
        if !config_path.exists() {
            return Ok(None);
        }
        
        let content = tokio::fs::read_to_string(config_path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        let config: Value = serde_json::from_str(&content)
            .map_err(NetworkError::ConfigParseError)?;
        
        // Try to extract credentials from Claude Code config
        // This matches the actual Claude Code config format
        if let (Some(base_url), Some(auth_token)) = (
            config.get("api_base_url").and_then(|v| v.as_str()),
            config.get("auth_token").and_then(|v| v.as_str())
        ) {
            return Ok(Some(ApiCredentials {
                base_url: base_url.to_string(),
                auth_token: auth_token.to_string(),
                source: CredentialSource::ClaudeConfig(config_path.clone()),
            }));
        }
        
        // Alternative config format - try different field names
        if let (Some(base_url), Some(auth_token)) = (
            config.get("base_url").and_then(|v| v.as_str()),
            config.get("auth_token").and_then(|v| v.as_str())
        ) {
            return Ok(Some(ApiCredentials {
                base_url: base_url.to_string(),
                auth_token: auth_token.to_string(),
                source: CredentialSource::ClaudeConfig(config_path.clone()),
            }));
        }
        
        Ok(None)
    }
}

