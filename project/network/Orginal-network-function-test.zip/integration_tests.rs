//! Integration tests for network monitoring
//! 
//! These tests verify the interactions between different components of the network monitoring system.

use ccstatus::{
    core::segments::{Segment, network::{
        segment::NetworkSegment,
        types::{NetworkConfig, NetworkStatus},
    }},
};
use crate::common::{create_test_input_data, IsolatedEnv};
use std::time::Duration;

#[tokio::test]
async fn test_end_to_end_disabled_monitoring() {
    // Test that a disabled network segment behaves correctly end-to-end
    let config = NetworkConfig {
        enabled: false,
        ..NetworkConfig::default()
    };
    
    let segment = NetworkSegment::new(config).await.unwrap();
    
    // Wait for initialization
    tokio::time::sleep(Duration::from_millis(100)).await;
    
    // Check status is disabled
    let status = segment.get_status().await;
    assert!(matches!(status, NetworkStatus::Disabled));
    
    // Check collect returns None
    let input = create_test_input_data();
    let result = segment.collect(&input);
    assert!(result.is_none());
    
    // Check monitoring is not enabled
    assert!(!segment.is_monitoring_enabled());
}

#[tokio::test]
async fn test_end_to_end_enabled_no_credentials() {
    let _env = IsolatedEnv::new();
    
    // Test enabled segment without credentials
    let config = NetworkConfig {
        enabled: true,
        timeout_seconds: 5,
        check_interval_seconds: 30,
    };
    
    let segment = NetworkSegment::new(config).await.unwrap();
    
    // Wait for initialization to detect missing credentials
    tokio::time::sleep(Duration::from_millis(200)).await;
    
    let status = segment.get_status().await;
    
    // Should be in an error state due to missing credentials
    match status {
        NetworkStatus::Error { error_type, details } => {
            assert!(error_type.contains("CREDENTIALS") || error_type.contains("INITIALIZATION"));
            assert!(!details.is_empty());
        }
        NetworkStatus::Disabled => {
            // Also acceptable - segment may disable itself when no credentials
            assert!(true);
        }
        NetworkStatus::Unknown => {
            // May still be initializing
            assert!(true);
        }
        other => {
            // Unexpected status for missing credentials scenario
            println!("Unexpected status for missing credentials: {:?}", other);
            assert!(true); // Don't fail - environment may have credentials
        }
    }
}

#[tokio::test]
async fn test_segment_trait_implementation() {
    // Test that NetworkSegment correctly implements the Segment trait
    use ccstatus::core::segments::Segment;
    use ccstatus::config::SegmentId;
    
    let segment = NetworkSegment::disabled();
    let input = create_test_input_data();
    
    // Test ID
    assert_eq!(segment.id(), SegmentId::Network);
    
    // Test collect (should return None for disabled)
    let result = segment.collect(&input);
    assert!(result.is_none());
}

#[tokio::test] 
async fn test_monitoring_lifecycle() {
    // Test the complete monitoring lifecycle for an enabled segment
    let config = NetworkConfig {
        enabled: true,
        timeout_seconds: 2, // Short timeout for faster testing
        check_interval_seconds: 10, // Short interval
    };
    
    match NetworkSegment::new(config).await {
        Ok(segment) => {
            // Test initial state
            let initial_status = segment.get_status().await;
            
            // Wait a bit for any initialization to occur
            tokio::time::sleep(Duration::from_millis(300)).await;
            
            let later_status = segment.get_status().await;
            
            // Status should be deterministic (not random Unknown)
            match later_status {
                NetworkStatus::Unknown => {
                    // Should only be unknown if truly uninitialized
                    println!("Status remained unknown - check if this is expected");
                }
                NetworkStatus::Error { .. } => {
                    // Expected for missing credentials
                    assert!(true);
                }
                NetworkStatus::Disabled => {
                    // May be disabled due to missing credentials
                    assert!(true);
                }
                NetworkStatus::Healthy | NetworkStatus::Degraded { .. } => {
                    // Great - monitoring is working
                    assert!(true);
                }
            }
            
            // Test that we can get a consistent status
            let status1 = segment.get_status().await;
            let status2 = segment.get_status().await;
            
            // Status should be stable between calls
            assert_eq!(
                std::mem::discriminant(&status1), 
                std::mem::discriminant(&status2),
                "Status should be stable between consecutive calls"
            );
        }
        Err(e) => {
            // Creation failure is acceptable in test environment
            assert!(e.should_fail_silent() || e.is_credentials_missing());
        }
    }
}