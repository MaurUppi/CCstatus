//! Tests for state machine functionality

use ccstatus::core::segments::network::{
    state_machine::StateMachine,
    types::{MonitoringState, StateEvent},
};
use std::time::Duration;
use chrono::Utc;

#[tokio::test]
async fn test_initial_state_is_healthy() {
    let sm = StateMachine::new();
    let state = sm.get_current_state().await;
    
    assert!(matches!(state, MonitoringState::Healthy { 
        interval, consecutive_successes: 0 
    } if interval == Duration::from_secs(30)));
    
    assert!(sm.is_healthy().await);
    assert!(!sm.is_degraded().await);
    assert!(!sm.is_failed().await);
}

#[tokio::test]
async fn test_healthy_to_degraded_transition() {
    let sm = StateMachine::new();
    let state = sm.transition(StateEvent::Failure).await;
    
    assert!(matches!(state, MonitoringState::Degraded { 
        interval, .. 
    } if interval == Duration::from_secs(5)));
    
    assert!(!sm.is_healthy().await);
    assert!(sm.is_degraded().await);
    assert!(!sm.is_failed().await);
}

#[tokio::test]
async fn test_ten_successes_extends_interval() {
    let sm = StateMachine::new();
    
    // Simulate 10 consecutive successes
    for _ in 0..10 {
        sm.transition(StateEvent::Success).await;
    }
    
    let interval = sm.get_current_interval().await;
    assert_eq!(interval, Duration::from_secs(300)); // 5 minutes
    
    let successes = sm.get_consecutive_successes().await;
    assert_eq!(successes, Some(10));
}

#[tokio::test]
async fn test_degraded_to_failed_transition() {
    let sm = StateMachine::new();
    
    // Go to degraded state
    sm.transition(StateEvent::Failure).await;
    assert!(sm.is_degraded().await);
    
    // Wait a bit and simulate time passing
    tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
    
    // To properly test this, we'd need to manipulate the `since` timestamp
    // For now, test the transition logic with multiple failures
    for _ in 0..15 {
        sm.transition(StateEvent::Failure).await;
        tokio::time::sleep(tokio::time::Duration::from_millis(5)).await;
    }
    
    // After enough time and failures, should transition to failed
    // Note: This test might need adjustment based on actual timing logic
}

#[tokio::test]
async fn test_recovery_from_degraded() {
    let sm = StateMachine::new();
    
    // Go to degraded state
    sm.transition(StateEvent::Failure).await;
    assert!(sm.is_degraded().await);
    
    // Recovery with success
    let state = sm.transition(StateEvent::Success).await;
    assert!(matches!(state, MonitoringState::Healthy { 
        consecutive_successes: 1, .. 
    }));
    
    assert!(sm.is_healthy().await);
}

#[tokio::test]
async fn test_failed_recovery_goes_through_degraded() {
    // Create state machine in failed state directly
    let failed_state = MonitoringState::Failed {
        interval: Duration::from_secs(60),
        consecutive_failures: 10,
        since: Utc::now(),
    };
    let sm = StateMachine::from_state(failed_state);
    
    assert!(sm.is_failed().await);
    
    // Recovery from failed should go to degraded first
    let state = sm.transition(StateEvent::Success).await;
    assert!(matches!(state, MonitoringState::Degraded { .. }));
    assert!(sm.is_degraded().await);
}

#[tokio::test]
async fn test_rate_limit_handling() {
    let sm = StateMachine::new();
    
    // Rate limit should move to degraded
    let state = sm.transition(StateEvent::RateLimit).await;
    assert!(matches!(state, MonitoringState::Degraded { .. }));
    
    // Rate limit in degraded should stay degraded
    let state = sm.transition(StateEvent::RateLimit).await;
    assert!(matches!(state, MonitoringState::Degraded { .. }));
}

#[tokio::test]
async fn test_reset_to_healthy() {
    let sm = StateMachine::new();
    
    // Move to degraded state
    sm.transition(StateEvent::Failure).await;
    assert!(sm.is_degraded().await);
    
    // Reset to healthy
    sm.reset_to_healthy().await;
    assert!(sm.is_healthy().await);
    
    let successes = sm.get_consecutive_successes().await;
    assert_eq!(successes, Some(0));
}

#[tokio::test]
async fn test_time_in_current_state() {
    let sm = StateMachine::new();
    
    // In healthy state, time in current state should be None
    let time = sm.get_time_in_current_state().await;
    assert!(time.is_none());
    
    // Move to degraded state
    sm.transition(StateEvent::Failure).await;
    
    // In degraded state, should have some time measurement
    let time = sm.get_time_in_current_state().await;
    assert!(time.is_some());
    assert!(time.unwrap().num_milliseconds() >= 0);
}

#[tokio::test]
async fn test_consecutive_failure_count() {
    // Create state machine in failed state directly
    let failed_state = MonitoringState::Failed {
        interval: Duration::from_secs(60),
        consecutive_failures: 5,
        since: Utc::now(),
    };
    let sm = StateMachine::from_state(failed_state);
    
    let failures = sm.get_consecutive_failures().await;
    assert_eq!(failures, Some(5));
    
    // Increment failures
    sm.transition(StateEvent::Failure).await;
    let failures = sm.get_consecutive_failures().await;
    assert_eq!(failures, Some(6));
}