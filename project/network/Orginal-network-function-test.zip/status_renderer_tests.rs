//! Tests for status rendering functionality

use ccstatus::core::segments::network::{
    status_renderer::StatusRenderer,
    types::NetworkStatus,
};

#[test]
fn test_healthy_status_rendering() {
    let renderer = StatusRenderer::new();
    let status = NetworkStatus::Healthy;
    
    assert_eq!(renderer.render(&status), "🟢");
    assert_eq!(renderer.render_compact(&status), "🟢");
    assert_eq!(renderer.render_verbose(&status), "🟢 Network: Healthy");
    assert_eq!(renderer.get_status_color(&status), "green");
    assert_eq!(renderer.get_status_indicator(&status), "OK");
}

#[test]
fn test_degraded_status_rendering() {
    let renderer = StatusRenderer::new();
    let status = NetworkStatus::Degraded {
        reason: "High latency".to_string(),
        details: "Total:250ms".to_string(),
    };
    
    assert_eq!(renderer.render(&status), "🟡 250ms");
    assert_eq!(renderer.render_compact(&status), "🟡");
    assert_eq!(renderer.render_verbose(&status), "🟡 Network: High latency - Total:250ms");
    assert_eq!(renderer.get_status_color(&status), "yellow");
    assert_eq!(renderer.get_status_indicator(&status), "WARN");
}

#[test]
fn test_error_status_rendering() {
    let renderer = StatusRenderer::new();
    let status = NetworkStatus::Error {
        error_type: "NETWORK_TIMEOUT".to_string(),
        details: "Total:5000ms".to_string(),
    };
    
    assert_eq!(renderer.render(&status), "🔴 5s [NETWORK_TIMEOUT]");
    assert_eq!(renderer.render_compact(&status), "🔴");
    assert!(renderer.render_verbose(&status).contains("NETWORK_TIMEOUT"));
    assert_eq!(renderer.get_status_color(&status), "red");
    assert_eq!(renderer.get_status_indicator(&status), "ERR");
}

#[test]
fn test_unknown_status_rendering() {
    let renderer = StatusRenderer::new();
    let status = NetworkStatus::Unknown;
    
    assert_eq!(renderer.render(&status), "⚪");
    assert_eq!(renderer.render_compact(&status), "⚪");
    assert_eq!(renderer.render_verbose(&status), "⚪ Network: Unknown");
    assert_eq!(renderer.get_status_color(&status), "white");
    assert_eq!(renderer.get_status_indicator(&status), "UNK");
}

#[test]
fn test_disabled_status_rendering() {
    let renderer = StatusRenderer::new();
    let status = NetworkStatus::Disabled;
    
    assert_eq!(renderer.render(&status), "");
    assert_eq!(renderer.render_compact(&status), "");
    assert_eq!(renderer.render_verbose(&status), "Network: Disabled");
    assert_eq!(renderer.get_status_color(&status), "default");
    assert_eq!(renderer.get_status_indicator(&status), "");
}

#[test]
fn test_details_disabled() {
    let renderer = StatusRenderer::with_details(false);
    let status = NetworkStatus::Degraded {
        reason: "High latency".to_string(),
        details: "Total:250ms".to_string(),
    };
    
    assert_eq!(renderer.render(&status), "🟡");
}

#[test]
fn test_latency_formatting() {
    let renderer = StatusRenderer::new();
    
    // Test private method indirectly through the public interface
    let test_cases = vec![
        ("Total:50ms", "50ms"),
        ("Total:150ms", "150ms"), 
        ("Total:1500ms", "1.5s"),
        ("Total:5000ms", "5s"),
        ("Total:15000ms", "15s"),
    ];
    
    for (input, expected) in test_cases {
        let status = NetworkStatus::Degraded {
            reason: "Test".to_string(),
            details: input.to_string(),
        };
        let rendered = renderer.render(&status);
        assert!(rendered.contains(expected), 
                "Expected '{}' in '{}' for input '{}'", expected, rendered, input);
    }
}

#[test]
fn test_latency_breakdown_parsing() {
    let renderer = StatusRenderer::new();
    let breakdown = "DNS:20ms|TCP:30ms|TLS:45ms|TTFB:71ms|Total:166ms";
    
    let status = NetworkStatus::Degraded {
        reason: "Test".to_string(),
        details: breakdown.to_string(),
    };
    
    let rendered = renderer.render(&status);
    assert!(rendered.contains("166ms"));
}

#[test]
fn test_latency_breakdown_with_reuse() {
    let renderer = StatusRenderer::new();
    let breakdown = "DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms";
    
    let status = NetworkStatus::Degraded {
        reason: "Test".to_string(),
        details: breakdown.to_string(),
    };
    
    let rendered = renderer.render(&status);
    assert!(rendered.contains("890ms"));
}

#[test]
fn test_should_display() {
    let renderer = StatusRenderer::new();
    
    assert!(renderer.should_display(&NetworkStatus::Healthy));
    assert!(renderer.should_display(&NetworkStatus::Degraded { 
        reason: "test".to_string(), 
        details: "test".to_string() 
    }));
    assert!(renderer.should_display(&NetworkStatus::Error { 
        error_type: "test".to_string(), 
        details: "test".to_string() 
    }));
    assert!(renderer.should_display(&NetworkStatus::Unknown));
    assert!(!renderer.should_display(&NetworkStatus::Disabled));
}

#[test]
fn test_priority_ordering() {
    let renderer = StatusRenderer::new();
    
    // Error should have highest priority
    assert!(renderer.get_priority(&NetworkStatus::Error { 
        error_type: "test".to_string(), 
        details: "test".to_string() 
    }) > renderer.get_priority(&NetworkStatus::Degraded { 
        reason: "test".to_string(), 
        details: "test".to_string() 
    }));
    
    // Degraded should have higher priority than healthy
    assert!(renderer.get_priority(&NetworkStatus::Degraded { 
        reason: "test".to_string(), 
        details: "test".to_string() 
    }) > renderer.get_priority(&NetworkStatus::Healthy));
    
    // Disabled should have lowest priority
    assert_eq!(renderer.get_priority(&NetworkStatus::Disabled), 0);
}