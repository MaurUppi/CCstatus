//! Tests for error tracking functionality

use ccstatus::core::segments::network::error_tracker::ErrorTracker;
use chrono::{Duration, Utc};

#[tokio::test]
async fn test_error_tracker_new() {
    let tracker = ErrorTracker::new();
    let count = tracker.get_total_error_count().await;
    assert_eq!(count, 0);
}

#[tokio::test]
async fn test_record_and_count_errors() {
    let tracker = ErrorTracker::new();
    
    // Record some errors
    tracker.record_error("NETWORK_TIMEOUT", None).await;
    tracker.record_error("NETWORK_TIMEOUT", None).await;
    tracker.record_error("CONNECTION_FAILED", Some(500)).await;
    
    let timeout_count = tracker.get_error_count("NETWORK_TIMEOUT").await;
    assert_eq!(timeout_count, 2);
    
    let connection_count = tracker.get_error_count("CONNECTION_FAILED").await;
    assert_eq!(connection_count, 1);
    
    let total_count = tracker.get_total_error_count().await;
    assert_eq!(total_count, 3);
}

#[tokio::test]
async fn test_error_summary() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("TEST_ERROR", Some(404)).await;
    
    let summary = tracker.get_error_summary().await;
    assert!(summary.contains_key("TEST_ERROR"));
    
    let (first, last) = summary["TEST_ERROR"];
    assert_eq!(first, last); // First occurrence should equal last for single error
}

#[tokio::test]
async fn test_most_frequent_error() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("FREQUENT_ERROR", None).await;
    tracker.record_error("FREQUENT_ERROR", None).await;
    tracker.record_error("FREQUENT_ERROR", None).await;
    tracker.record_error("RARE_ERROR", None).await;
    
    let most_frequent = tracker.get_most_frequent_error().await;
    assert!(most_frequent.is_some());
    
    let (error_type, count) = most_frequent.unwrap();
    assert_eq!(error_type, "FREQUENT_ERROR");
    assert_eq!(count, 3);
}

#[tokio::test]
async fn test_recent_errors() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("RECENT_ERROR", None).await;
    
    let recent = tracker.get_recent_errors(5).await; // Last 5 minutes
    assert_eq!(recent.len(), 1);
    assert_eq!(recent[0], "RECENT_ERROR");
    
    let has_recent = tracker.has_recent_error("RECENT_ERROR", 5).await;
    assert!(has_recent);
    
    let has_old = tracker.has_recent_error("NONEXISTENT_ERROR", 5).await;
    assert!(!has_old);
}

#[tokio::test]
async fn test_clear_old_errors() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("OLD_ERROR", None).await;
    
    // Clear errors older than 1 minute ago
    let cutoff = Utc::now() + Duration::minutes(1);
    tracker.clear_old_errors(cutoff).await;
    
    let count = tracker.get_total_error_count().await;
    assert_eq!(count, 0); // All errors should be cleared
}

#[tokio::test]
async fn test_bounded_error_types() {
    let tracker = ErrorTracker::new();
    
    // Record more than 50 different error types
    for i in 0..60 {
        tracker.record_error(&format!("ERROR_TYPE_{}", i), None).await;
    }
    
    let records = tracker.get_error_records().await;
    assert!(records.len() <= 50); // Should be bounded to 50 or fewer
}

#[tokio::test]
async fn test_most_recent_error() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("FIRST_ERROR", None).await;
    // Small delay to ensure different timestamps
    tokio::time::sleep(tokio::time::Duration::from_millis(10)).await;
    tracker.record_error("SECOND_ERROR", None).await;
    
    let most_recent = tracker.get_most_recent_error().await;
    assert!(most_recent.is_some());
    
    let (error_type, _) = most_recent.unwrap();
    assert_eq!(error_type, "SECOND_ERROR");
}

#[tokio::test]
async fn test_clear_all() {
    let tracker = ErrorTracker::new();
    
    tracker.record_error("TEST_ERROR", None).await;
    assert_eq!(tracker.get_total_error_count().await, 1);
    
    tracker.clear_all().await;
    assert_eq!(tracker.get_total_error_count().await, 0);
}