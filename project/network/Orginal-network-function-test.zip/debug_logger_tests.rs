//! Tests for debug logging functionality

use ccstatus::core::segments::network::debug_logger::{DebugLogger, get_debug_logger};
use crate::common::{create_temp_dir, IsolatedEnv};
use std::env;

#[test]
fn test_debug_logger_creation() {
    let _env = IsolatedEnv::new();
    let temp_dir = create_temp_dir();
    env::set_var("HOME", temp_dir.path());
    
    // Note: This test creates individual DebugLogger instances rather than using the global singleton
    // to avoid issues with concurrent test execution and global state
    
    // Test without CCSTATUS_DEBUG
    env::remove_var("CCSTATUS_DEBUG");
    let logger = DebugLogger::new();
    assert!(!logger.is_enabled(), "Logger should be disabled when CCSTATUS_DEBUG is not set");

    // Test with CCSTATUS_DEBUG=1
    env::set_var("CCSTATUS_DEBUG", "1");
    let logger = DebugLogger::new();
    assert!(logger.is_enabled(), "Logger should be enabled when CCSTATUS_DEBUG=1");
    
    // Clean up
    env::remove_var("CCSTATUS_DEBUG");
}

#[tokio::test]
async fn test_debug_logging_output() {
    let _env = IsolatedEnv::new();
    let temp_dir = create_temp_dir();
    env::set_var("HOME", temp_dir.path());
    
    // Save original CCSTATUS_DEBUG state
    let original_debug = env::var("CCSTATUS_DEBUG").ok();
    
    // Enable debug logging with isolated home directory
    env::set_var("CCSTATUS_DEBUG", "1");
    let logger = DebugLogger::new();
    
    // Test that logger is enabled but don't actually write to avoid production log pollution
    assert!(logger.is_enabled(), "Logger should be enabled with CCSTATUS_DEBUG=1");
    
    // Test that logging methods don't panic (but disable debug to avoid production log pollution)
    env::remove_var("CCSTATUS_DEBUG");
    let test_logger = DebugLogger::new();
    
    // These calls should not write to any log file since debug is disabled
    test_logger.info("TestComponent", "Test message").await;
    test_logger.warn("TestComponent", "Warning message").await;
    test_logger.error("TestComponent", "Error message").await;
    test_logger.debug("TestComponent", "Debug message").await;

    // Test specialized logging methods (should not write since debug disabled)
    test_logger.log_engine_event("TestStarted", "Test monitoring thread initialized").await;
    test_logger.log_credential_event("TestLookup", "test_environment", true).await;
    test_logger.log_status_file_event("TestWrite", "/temp/test/path.json", true, Some(50)).await;
    test_logger.log_health_check("https://test-isolated.example.com", Some(200), 150, None).await;
    test_logger.log_init_timeout(2000, "TestMonitoringEngine").await;
    test_logger.log_status_transition("TestUnknown", "TestError", "Test scenario").await;

    // Test summary for enabled logger
    let summary = logger.get_log_summary().await;
    assert!(summary.is_some());
    assert!(summary.unwrap().contains("Debug logging enabled"));
    
    // Test summary for disabled logger  
    let disabled_summary = test_logger.get_log_summary().await;
    assert!(disabled_summary.is_none(), "Disabled logger should not provide summary");

    // Restore original CCSTATUS_DEBUG state
    match original_debug {
        Some(val) => env::set_var("CCSTATUS_DEBUG", val),
        None => env::remove_var("CCSTATUS_DEBUG"),
    }
}

#[test]
fn test_debug_logger_sync_methods() {
    let _env = IsolatedEnv::new();
    let temp_dir = create_temp_dir();
    env::set_var("HOME", temp_dir.path());
    
    // Save original CCSTATUS_DEBUG state
    let original_debug = env::var("CCSTATUS_DEBUG").ok();
    
    env::set_var("CCSTATUS_DEBUG", "1");
    let logger = DebugLogger::new();
    assert!(logger.is_enabled(), "Logger should be enabled with CCSTATUS_DEBUG=1");
    
    // Test synchronous logging methods (disable debug to prevent production log pollution)
    env::remove_var("CCSTATUS_DEBUG");
    let test_logger = DebugLogger::new();
    
    // These calls should not write to any log file since debug is disabled
    test_logger.info_sync("TestSyncComponent", "Sync info message");
    test_logger.warn_sync("TestSyncComponent", "Sync warning message");  
    test_logger.error_sync("TestSyncComponent", "Sync error message");
    test_logger.debug_sync("TestSyncComponent", "Sync debug message");
    
    // Restore original CCSTATUS_DEBUG state
    match original_debug {
        Some(val) => env::set_var("CCSTATUS_DEBUG", val),
        None => env::remove_var("CCSTATUS_DEBUG"),
    }
}

#[test]
fn test_global_logger() {
    let logger1 = get_debug_logger();
    let logger2 = get_debug_logger();
    
    // Should be the same instance
    assert!(std::ptr::eq(logger1, logger2));
}