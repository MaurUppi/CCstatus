//! Tests for latency tracking functionality

use ccstatus::core::segments::network::{
    latency_tracker::LatencyTracker,
    types::LatencyData,
};
use std::time::Duration;

#[tokio::test]
async fn test_latency_tracker_new() {
    let tracker = LatencyTracker::new();
    let count = tracker.get_sample_count().await;
    assert_eq!(count, 0);
}

#[tokio::test]
async fn test_record_and_average() {
    let tracker = LatencyTracker::new();
    
    // Record some latencies
    let latencies = vec![
        Duration::from_millis(100),
        Duration::from_millis(200), 
        Duration::from_millis(150),
    ];
    
    for latency in latencies {
        let data = LatencyData {
            dns: None,
            tcp: None, 
            tls: None,
            ttfb: latency / 2,
            total: latency,
        };
        tracker.record(&data).await;
    }
    
    let average = tracker.get_average_latency(Duration::from_secs(60)).await;
    assert_eq!(average, Some(Duration::from_millis(150)));
    
    let count = tracker.get_sample_count().await;
    assert_eq!(count, 3);
}

#[tokio::test]
async fn test_bounded_size() {
    let tracker = LatencyTracker::new();
    
    // Record more than the maximum capacity
    for i in 0..150 {
        let data = LatencyData {
            dns: None,
            tcp: None, 
            tls: None,
            ttfb: Duration::from_millis(i),
            total: Duration::from_millis(i * 2),
        };
        tracker.record(&data).await;
    }
    
    let count = tracker.get_sample_count().await;
    assert_eq!(count, 100); // Should be bounded to 100
}

#[tokio::test]
async fn test_percentile_calculation() {
    let tracker = LatencyTracker::new();
    
    // Record latencies: 100, 200, 300, 400, 500 ms
    for i in 1..=5 {
        let latency = Duration::from_millis(i * 100);
        let data = LatencyData {
            dns: None,
            tcp: None, 
            tls: None,
            ttfb: latency / 2,
            total: latency,
        };
        tracker.record(&data).await;
    }
    
    let p95 = tracker.get_percentile_latency(95.0).await;
    assert!(p95.is_some());
    assert_eq!(p95.unwrap(), Duration::from_millis(500)); // 95th percentile should be 500ms
    
    let p50 = tracker.get_percentile_latency(50.0).await;
    assert!(p50.is_some());
    assert_eq!(p50.unwrap(), Duration::from_millis(300)); // 50th percentile (median) should be 300ms
}

#[tokio::test]
async fn test_latest_latency() {
    let tracker = LatencyTracker::new();
    
    let data = LatencyData {
        dns: Some(Duration::from_millis(10)),
        tcp: Some(Duration::from_millis(20)), 
        tls: Some(Duration::from_millis(30)),
        ttfb: Duration::from_millis(40),
        total: Duration::from_millis(100),
    };
    tracker.record(&data).await;
    
    let latest = tracker.get_latest_latency().await;
    assert!(latest.is_some());
    assert_eq!(latest.unwrap().total, Duration::from_millis(100));
}

#[tokio::test]
async fn test_clear() {
    let tracker = LatencyTracker::new();
    
    let data = LatencyData {
        dns: None,
        tcp: None, 
        tls: None,
        ttfb: Duration::from_millis(50),
        total: Duration::from_millis(100),
    };
    tracker.record(&data).await;
    
    assert_eq!(tracker.get_sample_count().await, 1);
    
    tracker.clear().await;
    assert_eq!(tracker.get_sample_count().await, 0);
}