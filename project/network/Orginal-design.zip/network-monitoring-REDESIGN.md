# Background: 
- existing implementation is design a MonitoringEngine in background and manage different thread.  
- Use `ccstatus-monitoring.json` to saving network status, use `network-debug.log` to saving debugLOG if `ccstatus_debug=1` env varis. use `ccstatus-captured-error.json` to saving captured error info from transcript jsonl.

# Redesign motivation: 
- statusline is Reactive display info by JSON stdin.
- reduce complex but met requirements.
- NO Proactive thread in background. 

# Usage scenarios in my mind that I want to know network status. 
1. when I kick in claude code. 
	- ccstatus received stdin
	- leverage exist HTTP checking pipeline (e.g Initial CredentialManager to get credential info, prepare for HttpMonitor. HttpMonitor receive credential, send HTTP request and received respone, if HTTP 200 OK ,then display GREEN ICON. )
	- GREEN frequency: use "total_duration_ms" data to trigger HttpMonitor action within the first 3-second window at the beginning of each 300-second cycle. algoritham: `if (total_duration_ms % 300000 < 3000) { trigger_action();}`
2. when .jsonl transcript record error msg. 
	- leverage exist JSONlMonitor
	- IF captured any defined error code, trigger same process like above but with detailed breakdown, network status in RED ICON.
	- breakdown sample: "DNS:20ms|TCP:30ms|TLS:40ms|TTFB:1414ms|Total:2829ms"
	- RED frequency: use "total_duration_ms" data to trigger HttpMonitor action within the first 3-second window at the beginning of each 10-second cycle. algoritham: `if (total_duration_ms % 300000 < 3000) { trigger_action();}`

## GREEN & RED frequency
- use "total_duration_ms" data to trigger HttpMonitor action 
- Algoritham sample:
```
let in_RED_window = total_duration_ms % 10000 < 1000;
let in_GREEN_window = total_duration_ms % 300000 < 3000;
let network_degraded = detect_network_issues(&json_data);

if (network_degraded && in_RED_window) || in_GREEN_window {
    trigger_action();
}
```

# Existing Architecture Diagrams
```mermaid
graph TB
    subgraph "Network Monitoring System"
        NS[NetworkSegment<br/>Public Interface]
        ME[MonitoringEngine<br/>Core Worker]

        CM[CredentialManager<br/>Authentication]
        HM[HttpMonitor<br/>HTTP + Metrics]
        SM[StateMachine<br/>Adaptive Intervals]
        SW[StatusWriter<br/>File Output]
        SR[StatusRenderer<br/>Display]
    end

    NS --> ME
    NS --> SR
    ME --> CM
    ME --> HM
    ME --> SM
    ME --> SW

    classDef interface fill:#e1f5fe
    classDef core fill:#f3e5f5
    classDef support fill:#f1f8e9

    class NS interface
    class ME core
    class CM,HM,SM,SW,SR support
```



# statusline
## Ref: "https://docs.anthropic.com/en/docs/claude-code/statusline"
## How statusline Works
- The status line is updated when the conversation messages update
- Updates run at most every 300ms
- The first line of stdout from your command becomes the status line text
- ANSI color codes are supported for styling your status line
- Claude Code passes contextual information about the current session (model, directories, etc.) as JSON to your script via stdin
- statusLine from my shell PS1 configuration

## How to config statusline
 `.claude/settings.json`
```
{
  "statusLine": {
    "type": "command",
    "command": "~/.claude/statusline.sh", // Your script or binary. 
    "padding": 0 // Optional: set to 0 to let status line go to edge
  }
}
```

## JSON Input Structure example
```
{
  "session_id": "772eaf12-e929-4d87-abdb-f3ad9669c4d0",
  "transcript_path": "/Users/ouzy/.claude/projects/-Users-ouzy-Documents-DevProjects-CCstatus/772eaf12-e929-4d87-abdb-f3ad9669c4d0.jsonl",
  "cwd": "/Users/ouzy/Documents/DevProjects/CCstatus",
  "model": {
    "id": "claude-sonnet-4-20250514",
    "display_name": "Sonnet 4"
  },
  "workspace": {
    "current_dir": "/Users/ouzy/Documents/DevProjects/CCstatus",
    "project_dir": "/Users/ouzy/Documents/DevProjects/CCstatus"
  },
  "version": "1.0.88",
  "output_style": {
    "name": "default"
  },
  "cost": {
    "total_cost_usd": 0.0009232000000000001,
    "total_duration_ms": 54146,
    "total_api_duration_ms": 2024,
    "total_lines_added": 0,
    "total_lines_removed": 0
  },
  "exceeds_200k_tokens": false
}

```

# Jsonl transcript ERROR msg
```
{
"parentUuid": "d4b75640-9df9-4caf-98b9-d8591b1f9983",
"isSidechain": false,
"userType": "external",
"cwd": "/Users/ouzy/Documents/DevProjects/CCstatus",
"sessionId": "ae3a3af0-40d7-47e8-915b-d22b65710147",
"version": "1.0.86",
"gitBranch": "feature/network-monitoring",
"type": "assistant",
"uuid": "8bd1ad3f-1a5e-42d9-a89f-5f3be3b58128",
"timestamp": "2025-08-21T15:17:29.521Z",
"message": {
  "id": "d31d058a-0d24-4c88-b760-b028e560e904",
  "model": "<synthetic>",
  "role": "assistant",
  "stop_reason": "stop_sequence",
  "stop_sequence": "",
  "type": "message",
  "usage": {
    "input_tokens": 0,
    "output_tokens": 0,
    "cache_creation_input_tokens": 0,
    "cache_read_input_tokens": 0,
    "server_tool_use": {
      "web_search_requests": 0
    },
    "service_tier": null
  },
  "content": [
    {
      "type": "text",
      "text": "API Error: 529 {\"type\":\"error\",\"error\":{\"type\":\"overloaded_error\",\"message\":\"Overloaded\"},\"request_id\":null}"
    }
  ]
},
"isApiErrorMessage": true
}
```