# CCstatus Network Monitoring System - Technical Design

**Version**: 1.0  
**Date**: 2025-08-19  
**Project**: CCstatus Network Monitoring  
**Platform**: Rust  
**Requirements**: [Requirements.md](./network-monitoring-Requirements.md)

## Design Overview

This document provides the detailed technical design for the CCstatus network monitoring system, translating functional requirements into concrete system architecture, component specifications, and implementation patterns.

### Design Principles

1. **Zero Regression**: Additive-only changes to CCometixLine
2. **Security First**: No credential storage, read-only access
3. **Resource Efficiency**: Minimal CPU, memory, and battery impact
4. **Adaptive Behavior**: Smart frequency adjustment based on health
5. **Fail Silent**: Graceful degradation without user interruption

## System Architecture

### High-Level Architecture

```mermaid
graph TB
    A[CCometixLine Core] --> B[Segment Manager]
    B --> C[Network Segment]
    
    C --> D[Monitoring Engine]
    C --> E[Status Renderer]
    
    D --> F[Credential Manager]
    D --> G[HTTP Monitor]
    D --> H[State Machine]
    
    G --> I[Latency Tracker]
    G --> J[Error Tracker]
    
    H --> K[Status File Writer]
    E --> L[Shell Integration]
    
    F --> M[Environment Reader]
    F --> N[Shell Config Reader]  
    F --> O[Claude Config Reader]
    
    subgraph "External Systems"
        P[Claude API / Proxy]
        Q[File System]
        R[Shell Environment]
    end
    
    G --> P
    K --> Q
    L --> R
```

### Component Hierarchy

```
NetworkSegment
├── MonitoringEngine
│   ├── CredentialManager
│   ├── HttpMonitor
│   │   ├── LatencyTracker
│   │   └── ErrorTracker
│   └── StateMachine
├── StatusRenderer
└── StatusFileWriter
```

## Core Component Design

### NetworkSegment - Main Component

```rust
use std::sync::Arc;
use tokio::sync::RwLock;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

pub struct NetworkSegment {
    /// Core monitoring engine
    monitoring_engine: Arc<MonitoringEngine>,
    
    /// Status renderer for shell display
    status_renderer: StatusRenderer,
    
    /// Status file writer
    status_writer: StatusFileWriter,
    
    /// Current status (cached for fast access)
    current_status: Arc<RwLock<NetworkStatus>>,
    
    /// Configuration
    config: NetworkConfig,
}

impl NetworkSegment {
    pub async fn new(config: &Config) -> Result<Self, NetworkError> {
        // Initialize credential manager
        let credential_manager = CredentialManager::new()?;
        
        // Attempt to get credentials
        let credentials = match credential_manager.get_credentials().await? {
            Some(creds) => creds,
            None => {
                // No credentials found - fail silent
                return Err(NetworkError::NoCredentials);
            }
        };
        
        // Initialize monitoring engine
        let monitoring_engine = Arc::new(
            MonitoringEngine::new(credentials, config.network.clone()).await?
        );
        
        // Initialize other components
        let status_renderer = StatusRenderer::new();
        let status_writer = StatusFileWriter::new()?;
        let current_status = Arc::new(RwLock::new(NetworkStatus::default()));
        
        // Start monitoring loop
        let engine_clone = Arc::clone(&monitoring_engine);
        let status_clone = Arc::clone(&current_status);
        let writer_clone = status_writer.clone();
        
        tokio::spawn(async move {
            Self::monitoring_loop(engine_clone, status_clone, writer_clone).await;
        });
        
        Ok(Self {
            monitoring_engine,
            status_renderer,
            status_writer,
            current_status,
            config: config.network.clone(),
        })
    }
    
    async fn monitoring_loop(
        engine: Arc<MonitoringEngine>,
        status: Arc<RwLock<NetworkStatus>>,
        writer: StatusFileWriter,
    ) {
        loop {
            // Execute monitoring check
            let check_result = engine.check_health().await;
            
            // Update status
            {
                let mut status_guard = status.write().await;
                *status_guard = check_result.status.clone();
            }
            
            // Write status to file
            let _ = writer.write_status(&check_result).await;
            
            // Get next check interval from state machine
            let interval = engine.get_check_interval().await;
            tokio::time::sleep(interval).await;
        }
    }
}

impl Segment for NetworkSegment {
    fn new(config: &Config) -> Result<Self> {
        // Convert async new to sync for compatibility
        match tokio::runtime::Handle::try_current() {
            Ok(handle) => {
                handle.block_on(Self::new(config))
                    .map_err(|_| SegmentError::InitializationFailed)
            }
            Err(_) => {
                // No runtime - fail silent
                Err(SegmentError::InitializationFailed)
            }
        }
    }
    
    fn render(&self) -> String {
        // Fast, non-blocking status read
        if let Ok(status) = self.current_status.try_read() {
            self.status_renderer.render(&status)
        } else {
            String::new() // Fail silent if lock unavailable
        }
    }
}
```

### MonitoringEngine - Core Logic

```rust
pub struct MonitoringEngine {
    /// HTTP client for API calls
    http_monitor: HttpMonitor,
    
    /// State machine for adaptive frequency
    state_machine: StateMachine,
    
    /// Credentials for API access
    credentials: ApiCredentials,
    
    /// Configuration
    config: NetworkConfig,
}

impl MonitoringEngine {
    pub async fn new(
        credentials: ApiCredentials, 
        config: NetworkConfig
    ) -> Result<Self, NetworkError> {
        let http_monitor = HttpMonitor::new(&config).await?;
        let state_machine = StateMachine::new();
        
        Ok(Self {
            http_monitor,
            state_machine,
            credentials,
            config,
        })
    }
    
    pub async fn check_health(&self) -> HealthCheckResult {
        let start_time = Utc::now();
        
        // Perform HTTP health check
        let http_result = self.http_monitor.check_endpoint(
            &self.credentials.base_url,
            &self.credentials.auth_token,
        ).await;
        
        // Update state machine
        let state_update = match http_result.status {
            HttpStatus::Success => StateEvent::Success,
            HttpStatus::RateLimit => StateEvent::RateLimit,
            _ => StateEvent::Failure,
        };
        
        let new_state = self.state_machine.transition(state_update).await;
        
        // Build result
        HealthCheckResult {
            status: self.determine_status(&http_result, &new_state),
            latency: http_result.latency,
            error: http_result.error,
            timestamp: start_time,
            state: new_state,
        }
    }
    
    pub async fn get_check_interval(&self) -> Duration {
        self.state_machine.get_current_interval().await
    }
    
    fn determine_status(
        &self, 
        http_result: &HttpResult, 
        state: &MonitoringState
    ) -> NetworkStatus {
        match (&http_result.status, state) {
            (HttpStatus::Success, _) if http_result.latency.total < Duration::from_millis(500) => {
                NetworkStatus::Healthy
            }
            (HttpStatus::Success, _) => {
                NetworkStatus::Degraded {
                    reason: "High latency".to_string(),
                    details: http_result.latency.format_breakdown(),
                }
            }
            (HttpStatus::RateLimit, _) => {
                NetworkStatus::Degraded {
                    reason: "Rate limited".to_string(), 
                    details: http_result.latency.format_breakdown(),
                }
            }
            _ => {
                NetworkStatus::Error {
                    error_type: http_result.error.clone().unwrap_or_default(),
                    details: http_result.latency.format_breakdown(),
                }
            }
        }
    }
}
```

### HttpMonitor - Network Operations

```rust
use isahc::{HttpClient, Request, Body};
use isahc::config::{Configurable, RedirectPolicy, SslOption};
use std::time::Instant;

pub struct HttpMonitor {
    /// HTTP client with timing support
    client: HttpClient,
    
    /// Latency tracker
    latency_tracker: LatencyTracker,
    
    /// Error tracker
    error_tracker: ErrorTracker,
    
    /// Request payload for health checks
    health_check_payload: String,
}

impl HttpMonitor {
    pub async fn new(config: &NetworkConfig) -> Result<Self, NetworkError> {
        // Configure HTTP client with detailed timing
        let client = HttpClient::builder()
            .redirect_policy(RedirectPolicy::Follow)
            .timeout(Duration::from_secs(30))
            .connect_timeout(Duration::from_secs(10))
            .ssl_options(SslOption::DANGER_ACCEPT_INVALID_CERTS) // For dev proxies
            .build()
            .map_err(NetworkError::HttpClientError)?;
        
        // Prepare lightweight health check payload
        let health_check_payload = serde_json::to_string(&json!({
            "model": "claude-3-haiku-20240307",
            "max_tokens": 1,
            "messages": [{
                "role": "user",
                "content": "ping"
            }]
        }))?;
        
        Ok(Self {
            client,
            latency_tracker: LatencyTracker::new(),
            error_tracker: ErrorTracker::new(),
            health_check_payload,
        })
    }
    
    pub async fn check_endpoint(
        &self,
        base_url: &str,
        auth_token: &str,
    ) -> HttpResult {
        let endpoint = format!("{}/v1/messages", base_url.trim_end_matches('/'));
        let overall_start = Instant::now();
        
        // Build request
        let request = Request::post(&endpoint)
            .header("Content-Type", "application/json")
            .header("Authorization", format!("Bearer {}", auth_token))
            .header("anthropic-version", "2023-06-01")
            .body(Body::from(self.health_check_payload.clone()))
            .map_err(|e| HttpResult::error("Request build failed", e))?;
        
        // Execute request with detailed timing
        let latency_breakdown = self.execute_with_timing(request).await;
        let total_duration = overall_start.elapsed();
        
        // Combine timing data
        let latency = LatencyData {
            dns: latency_breakdown.dns,
            tcp: latency_breakdown.tcp,
            tls: latency_breakdown.tls,
            ttfb: latency_breakdown.ttfb,
            total: total_duration,
        };
        
        // Track results
        self.latency_tracker.record(&latency).await;
        
        match latency_breakdown.result {
            Ok(response) => {
                let status = response.status();
                let status_type = self.categorize_status(status.as_u16());
                
                if !status_type.is_success() {
                    self.error_tracker.record_error(
                        &format!("API_{}", status.as_u16()),
                        Some(status.as_u16()),
                    ).await;
                }
                
                HttpResult {
                    status: status_type,
                    latency,
                    error: None,
                }
            }
            Err(e) => {
                let error_type = self.categorize_error(&e);
                self.error_tracker.record_error(&error_type, None).await;
                
                HttpResult {
                    status: HttpStatus::NetworkError,
                    latency,
                    error: Some(error_type),
                }
            }
        }
    }
    
    async fn execute_with_timing(&self, request: Request<Body>) -> TimedResult {
        let mut timing = TimingData::default();
        
        // Note: isahc doesn't provide detailed timing breakdowns
        // This is a simplified implementation focusing on total time
        let start = Instant::now();
        
        let result = self.client.send_async(request).await;
        
        let total_time = start.elapsed();
        
        // For detailed timing, we'd need to integrate with system-level
        // network monitoring or use a different HTTP client
        // For now, estimate based on total time and connection reuse
        
        TimedResult {
            result,
            dns: if total_time > Duration::from_millis(100) {
                Some(Duration::from_millis(20)) // Estimated
            } else {
                None // Likely connection reuse
            },
            tcp: if total_time > Duration::from_millis(50) {
                Some(Duration::from_millis(30)) // Estimated
            } else {
                None // Likely connection reuse
            },
            tls: if total_time > Duration::from_millis(80) {
                Some(Duration::from_millis(40)) // Estimated
            } else {
                None // Likely connection reuse
            },
            ttfb: Duration::from_millis(total_time.as_millis() as u64 / 2), // Server processing estimate
        }
    }
    
    fn categorize_status(&self, status_code: u16) -> HttpStatus {
        match status_code {
            200..=299 => HttpStatus::Success,
            401 | 403 => HttpStatus::AuthError,
            429 => HttpStatus::RateLimit,
            500..=599 => HttpStatus::ServerError,
            _ => HttpStatus::ClientError,
        }
    }
    
    fn categorize_error(&self, error: &isahc::Error) -> String {
        if error.is_timeout() {
            "NETWORK_TIMEOUT".to_string()
        } else if error.is_connect() {
            "CONNECTION_FAILED".to_string()
        } else if error.is_tls() {
            "TLS_ERROR".to_string()
        } else {
            "NETWORK_ERROR".to_string()
        }
    }
}
```

### StateMachine - Adaptive Frequency

```rust
#[derive(Debug, Clone)]
pub enum MonitoringState {
    Healthy { 
        interval: Duration, 
        consecutive_successes: u32 
    },
    Degraded { 
        interval: Duration,
        since: DateTime<Utc>,
    },
    Failed { 
        interval: Duration, 
        consecutive_failures: u32,
        since: DateTime<Utc>,
    },
}

pub enum StateEvent {
    Success,
    RateLimit,
    Failure,
}

pub struct StateMachine {
    current_state: Arc<RwLock<MonitoringState>>,
}

impl StateMachine {
    pub fn new() -> Self {
        Self {
            current_state: Arc::new(RwLock::new(
                MonitoringState::Healthy {
                    interval: Duration::from_secs(30),
                    consecutive_successes: 0,
                }
            )),
        }
    }
    
    pub async fn transition(&self, event: StateEvent) -> MonitoringState {
        let mut state = self.current_state.write().await;
        let now = Utc::now();
        
        let new_state = match (&*state, event) {
            // From Healthy
            (MonitoringState::Healthy { consecutive_successes, .. }, StateEvent::Success) => {
                let new_successes = consecutive_successes + 1;
                if new_successes >= 10 {
                    // Switch to long interval
                    MonitoringState::Healthy {
                        interval: Duration::from_secs(300), // 5 minutes
                        consecutive_successes: new_successes,
                    }
                } else {
                    MonitoringState::Healthy {
                        interval: Duration::from_secs(30),
                        consecutive_successes: new_successes,
                    }
                }
            }
            
            (MonitoringState::Healthy { .. }, StateEvent::RateLimit) => {
                MonitoringState::Degraded {
                    interval: Duration::from_secs(5),
                    since: now,
                }
            }
            
            (MonitoringState::Healthy { .. }, StateEvent::Failure) => {
                MonitoringState::Degraded {
                    interval: Duration::from_secs(5),
                    since: now,
                }
            }
            
            // From Degraded
            (MonitoringState::Degraded { .. }, StateEvent::Success) => {
                MonitoringState::Healthy {
                    interval: Duration::from_secs(30),
                    consecutive_successes: 1,
                }
            }
            
            (MonitoringState::Degraded { since, .. }, StateEvent::Failure) => {
                // Check if we've been degraded for too long (10 consecutive failures)
                // This is simplified - in practice, we'd track failure count
                if now.signed_duration_since(*since).num_seconds() > 50 { // ~10 failures at 5s
                    MonitoringState::Failed {
                        interval: Duration::from_secs(60), // 1 minute
                        consecutive_failures: 10,
                        since: *since,
                    }
                } else {
                    MonitoringState::Degraded {
                        interval: Duration::from_secs(5),
                        since: *since,
                    }
                }
            }
            
            (MonitoringState::Degraded { since, .. }, StateEvent::RateLimit) => {
                MonitoringState::Degraded {
                    interval: Duration::from_secs(5),
                    since: *since,
                }
            }
            
            // From Failed
            (MonitoringState::Failed { .. }, StateEvent::Success) => {
                MonitoringState::Degraded {
                    interval: Duration::from_secs(5),
                    since: now,
                }
            }
            
            (MonitoringState::Failed { consecutive_failures, since, .. }, StateEvent::Failure) => {
                MonitoringState::Failed {
                    interval: Duration::from_secs(60),
                    consecutive_failures: consecutive_failures + 1,
                    since: *since,
                }
            }
            
            (MonitoringState::Failed { consecutive_failures, since, .. }, StateEvent::RateLimit) => {
                MonitoringState::Failed {
                    interval: Duration::from_secs(60),
                    consecutive_failures: *consecutive_failures,
                    since: *since,
                }
            }
        };
        
        *state = new_state.clone();
        new_state
    }
    
    pub async fn get_current_interval(&self) -> Duration {
        let state = self.current_state.read().await;
        match &*state {
            MonitoringState::Healthy { interval, .. } => *interval,
            MonitoringState::Degraded { interval, .. } => *interval,
            MonitoringState::Failed { interval, .. } => *interval,
        }
    }
    
    pub async fn get_current_state(&self) -> MonitoringState {
        self.current_state.read().await.clone()
    }
}
```

### CredentialManager - Secure Access

```rust
use std::env;
use std::path::PathBuf;
use serde_json::Value;

pub struct CredentialManager {
    claude_config_paths: Vec<PathBuf>,
}

#[derive(Debug, Clone)]
pub struct ApiCredentials {
    pub base_url: String,
    pub auth_token: String,
    pub source: CredentialSource,
}

#[derive(Debug, Clone)]
pub enum CredentialSource {
    Environment,
    ShellConfig(PathBuf),
    ClaudeConfig(PathBuf),
}

impl CredentialManager {
    pub fn new() -> Result<Self, NetworkError> {
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        let home_path = PathBuf::from(home);
        
        let claude_config_paths = vec![
            home_path.join(".claude").join("settings.json"),
            PathBuf::from(".claude").join("settings.local.json"),
            PathBuf::from(".claude").join("settings.json"),
        ];
        
        Ok(Self { claude_config_paths })
    }
    
    pub async fn get_credentials(&self) -> Result<Option<ApiCredentials>, NetworkError> {
        // Priority 1: System-wide Environment Variables (ANTHROPIC_BASE_URL + ANTHROPIC_AUTH_TOKEN)
        if let Some(creds) = self.get_from_environment()? {
            return Ok(Some(creds));
        }
        
        // Priority 2: Shell configuration files (.zshrc, .bashrc, PowerShell profiles)
        if let Ok(shell_reader) = ShellConfigReader::new() {
            if let Ok(Some(creds)) = shell_reader.get_credentials().await {
                return Ok(Some(creds));
            }
        }
        
        // Priority 3: Claude Code config files (.claude/settings.json hierarchy)
        for config_path in &self.claude_config_paths {
            if let Some(creds) = self.get_from_claude_config(config_path).await? {
                return Ok(Some(creds));
            }
        }
        
        // No credentials found (fail silent with disabled status)
        Ok(None)
    }
    
    fn get_from_environment(&self) -> Result<Option<ApiCredentials>, NetworkError> {
        // Check for base URL + token combination (both required)
        if let (Ok(base_url), Ok(auth_token)) = (
            env::var("ANTHROPIC_BASE_URL"),
            env::var("ANTHROPIC_AUTH_TOKEN")
        ) {
            return Ok(Some(ApiCredentials {
                base_url,
                auth_token,
                source: CredentialSource::Environment,
            }));
        }
        
        Ok(None)
    }
    
    async fn get_from_claude_config(
        &self, 
        config_path: &PathBuf
    ) -> Result<Option<ApiCredentials>, NetworkError> {
        if !config_path.exists() {
            return Ok(None);
        }
        
        let content = tokio::fs::read_to_string(config_path).await
            .map_err(NetworkError::ConfigReadError)?;
        
        let config: Value = serde_json::from_str(&content)
            .map_err(NetworkError::ConfigParseError)?;
        
        // Try to extract credentials from Claude Code config
        // This would need to match the actual Claude Code config format
        if let (Some(base_url), Some(auth_token)) = (
            config.get("api_base_url").and_then(|v| v.as_str()),
            config.get("api_key").and_then(|v| v.as_str())
        ) {
            return Ok(Some(ApiCredentials {
                base_url: base_url.to_string(),
                auth_token: auth_token.to_string(),
                source: CredentialSource::ClaudeConfig(config_path.clone()),
            }));
        }
        
        Ok(None)
    }
}
```

### StatusRenderer - Display Logic

```rust
pub struct StatusRenderer;

impl StatusRenderer {
    pub fn new() -> Self {
        Self
    }
    
    pub fn render(&self, status: &NetworkStatus) -> String {
        match status {
            NetworkStatus::Healthy => "🟢".to_string(),
            
            NetworkStatus::Degraded { reason: _, details } => {
                format!("🟡 {}", details)
            }
            
            NetworkStatus::Error { error_type, details } => {
                format!("🔴 {} [{}]", details, error_type)
            }
            
            NetworkStatus::Unknown => "⚪".to_string(),
            
            NetworkStatus::Disabled => String::new(),
        }
    }
}

#[derive(Debug, Clone)]
pub enum NetworkStatus {
    Healthy,
    Degraded { 
        reason: String, 
        details: String 
    },
    Error { 
        error_type: String, 
        details: String 
    },
    Unknown,
    Disabled,
}

impl Default for NetworkStatus {
    fn default() -> Self {
        Self::Unknown
    }
}
```

### LatencyTracker - Performance Metrics

```rust
#[derive(Debug, Clone)]
pub struct LatencyData {
    pub dns: Option<Duration>,
    pub tcp: Option<Duration>, 
    pub tls: Option<Duration>,
    pub ttfb: Duration,
    pub total: Duration,
}

impl LatencyData {
    pub fn format_breakdown(&self) -> String {
        format!(
            "DNS:{}|TCP:{}|TLS:{}|TTFB:{}ms|Total:{}ms",
            self.format_duration(self.dns),
            self.format_duration(self.tcp),
            self.format_duration(self.tls),
            self.ttfb.as_millis(),
            self.total.as_millis()
        )
    }
    
    fn format_duration(&self, duration: Option<Duration>) -> String {
        match duration {
            Some(d) if d.as_millis() == 0 => "reuse".to_string(),
            Some(d) => format!("{}ms", d.as_millis()),
            None => "reuse".to_string(),
        }
    }
}

pub struct LatencyTracker {
    recent_samples: Arc<RwLock<VecDeque<LatencyData>>>,
}

impl LatencyTracker {
    pub fn new() -> Self {
        Self {
            recent_samples: Arc::new(RwLock::new(VecDeque::with_capacity(100))),
        }
    }
    
    pub async fn record(&self, latency: &LatencyData) {
        let mut samples = self.recent_samples.write().await;
        
        if samples.len() >= 100 {
            samples.pop_front();
        }
        
        samples.push_back(latency.clone());
    }
    
    pub async fn get_average_latency(&self, window: Duration) -> Option<Duration> {
        let samples = self.recent_samples.read().await;
        
        if samples.is_empty() {
            return None;
        }
        
        let sum: u64 = samples.iter()
            .map(|s| s.total.as_millis() as u64)
            .sum();
        
        Some(Duration::from_millis(sum / samples.len() as u64))
    }
}
```

### ErrorTracker - Error Management

```rust
pub struct ErrorTracker {
    errors: Arc<RwLock<HashMap<String, ErrorRecord>>>,
}

#[derive(Debug, Clone)]
struct ErrorRecord {
    first_occurrence: DateTime<Utc>,
    last_occurrence: DateTime<Utc>,
    count: u32,
    error_code: Option<u16>,
}

impl ErrorTracker {
    pub fn new() -> Self {
        Self {
            errors: Arc::new(RwLock::new(HashMap::new())),
        }
    }
    
    pub async fn record_error(&self, error_type: &str, error_code: Option<u16>) {
        let mut errors = self.errors.write().await;
        let now = Utc::now();
        
        match errors.get_mut(error_type) {
            Some(record) => {
                record.last_occurrence = now;
                record.count += 1;
            }
            None => {
                errors.insert(error_type.to_string(), ErrorRecord {
                    first_occurrence: now,
                    last_occurrence: now,
                    count: 1,
                    error_code,
                });
            }
        }
    }
    
    pub async fn get_error_summary(&self) -> HashMap<String, (DateTime<Utc>, DateTime<Utc>)> {
        let errors = self.errors.read().await;
        errors.iter()
            .map(|(k, v)| (k.clone(), (v.first_occurrence, v.last_occurrence)))
            .collect()
    }
    
    pub async fn clear_old_errors(&self, cutoff: DateTime<Utc>) {
        let mut errors = self.errors.write().await;
        errors.retain(|_, record| record.last_occurrence > cutoff);
    }
}
```

### StatusFileWriter - Persistence

```rust
use tokio::fs;
use std::path::PathBuf;

pub struct StatusFileWriter {
    status_file_path: PathBuf,
}

#[derive(Serialize)]
struct StatusFileData {
    status: String,
    monitoring_enabled: bool,
    api_config: ApiConfigData,
    network: NetworkData,
    monitoring_state: MonitoringStateData,
    timestamp: DateTime<Utc>,
}

impl StatusFileWriter {
    pub fn new() -> Result<Self, NetworkError> {
        let home = env::var("HOME")
            .or_else(|_| env::var("USERPROFILE"))
            .map_err(|_| NetworkError::HomeDirNotFound)?;
        
        let ccstatus_dir = PathBuf::from(home)
            .join(".claude")
            .join("ccstatus");
        
        // Ensure directory exists
        if !ccstatus_dir.exists() {
            std::fs::create_dir_all(&ccstatus_dir)
                .map_err(NetworkError::DirectoryCreationError)?;
        }
        
        let status_file_path = ccstatus_dir.join("ccstatus-monitoring.json");
        
        Ok(Self { status_file_path })
    }
    
    pub async fn write_status(&self, result: &HealthCheckResult) -> Result<(), NetworkError> {
        let status_data = StatusFileData {
            status: self.status_to_string(&result.status),
            monitoring_enabled: true,
            api_config: ApiConfigData {
                endpoint: result.endpoint.clone(),
                source: result.credential_source.clone(),
            },
            network: NetworkData {
                latency_ms: result.latency.total.as_millis() as u32,
                breakdown: result.latency.format_breakdown(),
                last_error_code: result.error_code,
                error_type: result.error.clone(),
            },
            monitoring_state: MonitoringStateData::from(&result.state),
            timestamp: result.timestamp,
        };
        
        let json_content = serde_json::to_string_pretty(&status_data)
            .map_err(NetworkError::SerializationError)?;
        
        // Atomic write using temporary file
        let temp_file = self.status_file_path.with_extension("tmp");
        
        fs::write(&temp_file, json_content).await
            .map_err(NetworkError::FileWriteError)?;
        
        fs::rename(&temp_file, &self.status_file_path).await
            .map_err(NetworkError::FileWriteError)?;
        
        Ok(())
    }
    
    fn status_to_string(&self, status: &NetworkStatus) -> String {
        match status {
            NetworkStatus::Healthy => "healthy".to_string(),
            NetworkStatus::Degraded { .. } => "degraded".to_string(),
            NetworkStatus::Error { .. } => "error".to_string(),
            NetworkStatus::Unknown => "unknown".to_string(),
            NetworkStatus::Disabled => "disabled".to_string(),
        }
    }
}

impl Clone for StatusFileWriter {
    fn clone(&self) -> Self {
        Self {
            status_file_path: self.status_file_path.clone(),
        }
    }
}
```

## Data Flow Design

### Monitoring Flow

```mermaid
sequenceDiagram
    participant MS as MonitoringEngine
    participant HM as HttpMonitor
    participant SM as StateMachine
    participant ET as ErrorTracker
    participant LT as LatencyTracker
    participant SW as StatusWriter
    participant SR as StatusRenderer
    
    loop Monitoring Loop
        MS->>HM: check_endpoint()
        HM->>HM: execute_with_timing()
        HM->>LT: record(latency)
        
        alt Success
            HM->>MS: HttpResult::Success
            MS->>SM: transition(Success)
        else Error
            HM->>ET: record_error()
            HM->>MS: HttpResult::Error
            MS->>SM: transition(Failure)
        end
        
        MS->>SW: write_status()
        SW->>SW: atomic_file_write()
        
        MS->>SM: get_check_interval()
        SM->>MS: next_interval
        
        MS->>MS: sleep(interval)
    end
    
    Note over SR: Rendering happens independently
    SR->>SR: render(current_status)
```

### Credential Resolution Flow

```mermaid
flowchart TD
    A[CredentialManager.get_credentials()] --> B{Check Environment Variables}
    
    B -->|ANTHROPIC_BASE_URL + ANTHROPIC_AUTH_TOKEN| C[Return Environment Credentials]
    B -->|None Found| D[Check Shell Config Files]
    
    D --> E[Shell Config Reader]
    E -->|Found| F[Parse Shell Variables]
    E -->|Not Found| G[Check Claude Config Files]
    
    F --> H{Valid Shell Credentials?}
    H -->|Yes| I[Return Shell Credentials]
    H -->|No| G
    
    G --> J[~/.claude/settings.json]
    J -->|Found| K[Parse and Extract]
    J -->|Not Found| L[.claude/settings.local.json]
    
    L -->|Found| K
    L -->|Not Found| M[.claude/settings.json]
    
    M -->|Found| K
    M -->|Not Found| N[No Credentials Found]
    
    K --> O{Valid Config Credentials?}
    O -->|Yes| P[Return Config Credentials]
    O -->|No| Q[Continue Search]
    
    C --> R[Success]
    I --> R
    P --> R
    N --> S[Fail Silent]
    
    Q --> L
```

### State Machine Transitions

```mermaid
stateDiagram-v2
    [*] --> Healthy_30s
    
    state Healthy {
        Healthy_30s --> Healthy_5min : 10 consecutive successes
        Healthy_5min --> Healthy_30s : after error
    }
    
    Healthy --> Degraded : any error/rate limit
    Degraded --> Failed : 10 consecutive failures
    Degraded --> Healthy_30s : success
    Failed --> Degraded : success
    
    state Healthy_30s {
        interval: 30 seconds
        successes: 0-9
    }
    
    state Healthy_5min {
        interval: 5 minutes
        successes: ≥10
    }
    
    state Degraded {
        interval: 5 seconds
        quick_recovery: true
    }
    
    state Failed {
        interval: 1 minute
        respectful_backoff: true
    }
```

## Integration Patterns

### CCometixLine Integration

```rust
// In src/core/segments/mod.rs
mod network;
pub use network::NetworkSegment;

// In src/core/config.rs
#[derive(Deserialize)]
pub struct Config {
    // Existing fields...
    pub network: NetworkConfig,
}

#[derive(Deserialize, Default)]
pub struct NetworkConfig {
    pub enabled: bool,
    pub timeout_seconds: Option<u64>,
    pub check_interval_seconds: Option<u64>,
}

// In src/core/segments/manager.rs
impl SegmentManager {
    pub fn load_segments(config: &Config) -> Vec<Box<dyn Segment>> {
        let mut segments = Vec::new();
        
        // Load existing segments...
        
        // Load network segment if enabled
        if config.network.enabled {
            if let Ok(network_segment) = NetworkSegment::new(config) {
                segments.push(Box::new(network_segment));
            }
            // Fail silent if initialization fails
        }
        
        segments
    }
}
```

### Shell Integration Pattern

```bash
# Shell function template (cross-platform)
claude_status() {
    local status_file="${HOME}/.claude/ccstatus/ccstatus-monitoring.json"
    
    # Quick existence check
    [[ -f "$status_file" ]] || return
    
    # Parse status using fastest available JSON parser
    if command -v jq >/dev/null 2>&1; then
        local status=$(jq -r '.status // empty' "$status_file" 2>/dev/null)
        local breakdown=$(jq -r '.network.breakdown // empty' "$status_file" 2>/dev/null)
    else
        # Fallback parsing without jq
        local status=$(grep -o '"status"[[:space:]]*:[[:space:]]*"[^"]*"' "$status_file" 2>/dev/null | cut -d'"' -f4)
        local breakdown=$(grep -o '"breakdown"[[:space:]]*:[[:space:]]*"[^"]*"' "$status_file" 2>/dev/null | cut -d'"' -f4)
    fi
    
    # Display logic
    case "$status" in
        "healthy") echo "🟢" ;;
        "degraded") echo "🟡 $breakdown" ;;
        "error") echo "🔴 $breakdown" ;;
        *) return ;; # Unknown status - show nothing
    esac
}

# Integration examples
# Bash/Zsh: PS1="$(claude_status) $PS1"
# PowerShell: function prompt { "$(claude_status) PS $($executionContext.SessionState.Path.CurrentLocation)>" }
```

## Error Handling Strategy

### Error Categories and Responses

```rust
#[derive(Debug, thiserror::Error)]
pub enum NetworkError {
    #[error("No credentials found")]
    NoCredentials,
    
    #[error("HTTP client error: {0}")]
    HttpClientError(#[from] isahc::Error),
    
    #[error("Configuration read error: {0}")]
    ConfigReadError(#[from] tokio::io::Error),
    
    #[error("Configuration parse error: {0}")]
    ConfigParseError(#[from] serde_json::Error),
    
    #[error("Home directory not found")]
    HomeDirNotFound,
    
    #[error("Directory creation failed: {0}")]
    DirectoryCreationError(std::io::Error),
    
    #[error("File write error: {0}")]
    FileWriteError(tokio::io::Error),
    
    #[error("Serialization error: {0}")]
    SerializationError(serde_json::Error),
}

impl NetworkError {
    pub fn should_fail_silent(&self) -> bool {
        matches!(self, 
            NetworkError::NoCredentials |
            NetworkError::HomeDirNotFound
        )
    }
}
```

### Recovery Strategies

1. **Initialization Failures**: Fail silent, no segment display
2. **Network Failures**: Continue monitoring, track errors
3. **Configuration Errors**: Disable monitoring, log error
4. **File System Errors**: Continue monitoring, skip file writes

## Performance Considerations

### Memory Management

- **Bounded Collections**: Limit error and latency sample storage
- **Efficient Serialization**: Use serde with minimal allocations
- **Connection Pooling**: Reuse HTTP connections
- **Async Operations**: Non-blocking I/O throughout

### Resource Optimization

```rust
// HTTP client with connection pooling
let client = HttpClient::builder()
    .max_connections(1) // Limit connections for single endpoint
    .max_connections_per_host(1) // Single connection to Claude API
    .build()?;

// Bounded error storage
const MAX_ERROR_RECORDS: usize = 50;
const MAX_LATENCY_SAMPLES: usize = 100;

// Efficient status file updates
impl StatusFileWriter {
    async fn write_status_if_changed(&self, new_status: &StatusData) -> Result<(), NetworkError> {
        // Only write if status actually changed
        if let Ok(current) = self.read_current_status().await {
            if current == *new_status {
                return Ok(()); // Skip write
            }
        }
        
        self.write_status(new_status).await
    }
}
```

## Design Changes from Original Specification

### Removed ANTHROPIC_API_KEY Fallback

**Original Design**: Environment credential resolution included a fallback to `ANTHROPIC_API_KEY` with automatic assumption of the official Anthropic API endpoint.

**Updated Design**: Removed `ANTHROPIC_API_KEY` fallback to enforce explicit configuration.

**Rationale**:
- **Proxy Support**: Many deployments use custom endpoints (corporate proxies, Claude Code servers)
- **Explicit Configuration**: Prevents accidental connections to wrong endpoints
- **Security**: No implicit API endpoint assumptions
- **Clarity**: Forces users to explicitly configure both URL and credentials

**Migration Path**: Users relying on `ANTHROPIC_API_KEY` should set:
```bash
export ANTHROPIC_BASE_URL="https://api.anthropic.com"
export ANTHROPIC_AUTH_TOKEN="$ANTHROPIC_API_KEY"
```

### Updated Credential Resolution Priority

**Current Priority Order**:
1. **System-wide Environment Variables**: `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN` 
2. **Shell Configuration Files**: `.zshrc`, `.bashrc`, PowerShell profiles (via ShellConfigReader)
3. **Claude Code Configuration Files**: `.claude/settings.json` hierarchy
4. **None Found**: Fail silent with disabled status

**Note**: Shell configuration parsing supports `export` statements and PowerShell `$env:` syntax for comprehensive credential discovery across different shell environments.

## Testing Strategy

### Test Organization Structure

```
tests/
├── network_segment_basic.rs          # Basic functionality tests
├── network_segment_edge.rs           # Edge cases and error conditions
├── network_segment_integration.rs    # Integration with CCometixLine
├── monitoring_engine_basic.rs        # Core monitoring logic
├── monitoring_engine_edge.rs         # Error scenarios and timeouts
├── monitoring_engine_integration.rs  # End-to-end monitoring tests
├── state_machine_basic.rs            # State transitions
├── state_machine_edge.rs             # Boundary conditions
├── http_monitor_basic.rs             # HTTP client functionality
├── http_monitor_edge.rs              # Network failures and errors
├── http_monitor_integration.rs       # Real API endpoint tests
├── credential_manager_basic.rs       # Credential resolution
├── credential_manager_edge.rs        # Missing credentials, malformed configs
└── status_renderer_basic.rs          # Display formatting tests
```

### Test Examples

**tests/state_machine_basic.rs**:
```rust
use ccstatus::network::{StateMachine, StateEvent, MonitoringState};
use std::time::Duration;
use tokio_test;

#[tokio::test]
async fn test_initial_state_is_healthy() {
    let sm = StateMachine::new();
    let state = sm.get_current_state().await;
    
    assert!(matches!(state, MonitoringState::Healthy { 
        interval, consecutive_successes: 0 
    } if interval == Duration::from_secs(30)));
}

#[tokio::test]
async fn test_healthy_to_degraded_transition() {
    let sm = StateMachine::new();
    let state = sm.transition(StateEvent::Failure).await;
    
    assert!(matches!(state, MonitoringState::Degraded { 
        interval, .. 
    } if interval == Duration::from_secs(5)));
}

#[tokio::test]
async fn test_ten_successes_extends_interval() {
    let sm = StateMachine::new();
    
    // Simulate 10 consecutive successes
    for _ in 0..10 {
        sm.transition(StateEvent::Success).await;
    }
    
    let interval = sm.get_current_interval().await;
    assert_eq!(interval, Duration::from_secs(300)); // 5 minutes
}
```

**tests/credential_manager_edge.rs**:
```rust
use ccstatus::network::{CredentialManager, NetworkError};
use std::env;
use tempfile::TempDir;

#[tokio::test]
async fn test_no_credentials_returns_none() {
    // Clear environment variables
    env::remove_var("ANTHROPIC_BASE_URL");
    env::remove_var("ANTHROPIC_AUTH_TOKEN");
    
    let cm = CredentialManager::new().unwrap();
    let result = cm.get_credentials().await.unwrap();
    
    assert!(result.is_none());
}

#[tokio::test]
async fn test_malformed_config_file_ignored() {
    let temp_dir = TempDir::new().unwrap();
    let config_path = temp_dir.path().join("settings.json");
    
    // Write malformed JSON
    std::fs::write(&config_path, "{ invalid json }").unwrap();
    
    let cm = CredentialManager::new().unwrap();
    let result = cm.get_from_claude_config(&config_path).await;
    
    assert!(result.is_ok());
    assert!(result.unwrap().is_none());
}
```

**tests/http_monitor_integration.rs**:
```rust
use ccstatus::network::{HttpMonitor, NetworkConfig};
use wiremock::{Mock, MockServer, ResponseTemplate};
use wiremock::matchers::{method, path, header};

#[tokio::test]
async fn test_successful_health_check_with_mock_server() {
    // Start mock server
    let mock_server = MockServer::start().await;
    
    Mock::given(method("POST"))
        .and(path("/v1/messages"))
        .and(header("authorization", "Bearer test-token"))
        .respond_with(ResponseTemplate::new(200).set_body_json(json!({
            "content": [{"text": "Hi"}],
            "usage": {"input_tokens": 4, "output_tokens": 1}
        })))
        .mount(&mock_server)
        .await;
    
    let config = NetworkConfig::default();
    let monitor = HttpMonitor::new(&config).await.unwrap();
    
    let result = monitor.check_endpoint(
        &mock_server.uri(),
        "test-token"
    ).await;
    
    assert!(matches!(result.status, HttpStatus::Success));
    assert!(result.error.is_none());
}

#[tokio::test] 
async fn test_rate_limit_handling() {
    let mock_server = MockServer::start().await;
    
    Mock::given(method("POST"))
        .and(path("/v1/messages"))
        .respond_with(ResponseTemplate::new(429).set_body_json(json!({
            "error": {"type": "rate_limit_error", "message": "Rate limited"}
        })))
        .mount(&mock_server)
        .await;
    
    let config = NetworkConfig::default();
    let monitor = HttpMonitor::new(&config).await.unwrap();
    
    let result = monitor.check_endpoint(
        &mock_server.uri(),
        "test-token"
    ).await;
    
    assert!(matches!(result.status, HttpStatus::RateLimit));
}
```

**tests/latency_tracker_basic.rs**:
```rust
use ccstatus::network::{LatencyTracker, LatencyData};
use std::time::Duration;

#[test]
fn test_latency_breakdown_formatting() {
    let latency = LatencyData {
        dns: Some(Duration::from_millis(12)),
        tcp: None, // Connection reuse
        tls: Some(Duration::from_millis(45)),
        ttfb: Duration::from_millis(71),
        total: Duration::from_millis(156),
    };
    
    let formatted = latency.format_breakdown();
    assert_eq!(formatted, "DNS:12ms|TCP:reuse|TLS:45ms|TTFB:71ms|Total:156ms");
}

#[test]
fn test_connection_reuse_display() {
    let latency = LatencyData {
        dns: None,
        tcp: None,
        tls: None,
        ttfb: Duration::from_millis(890),
        total: Duration::from_millis(890),
    };
    
    let formatted = latency.format_breakdown();
    assert_eq!(formatted, "DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms");
}

#[tokio::test]
async fn test_latency_recording_and_average() {
    let tracker = LatencyTracker::new();
    
    // Record some latencies
    let latencies = vec![
        Duration::from_millis(100),
        Duration::from_millis(200), 
        Duration::from_millis(150),
    ];
    
    for latency in latencies {
        let data = LatencyData {
            dns: None,
            tcp: None, 
            tls: None,
            ttfb: latency / 2,
            total: latency,
        };
        tracker.record(&data).await;
    }
    
    let average = tracker.get_average_latency(Duration::from_secs(60)).await;
    assert_eq!(average, Some(Duration::from_millis(150)));
}
```

### Integration Test Scenarios

1. **Mock HTTP Server**: Test against controlled API responses
2. **Configuration Variations**: Test credential resolution paths
3. **State Transitions**: Test adaptive frequency changes
4. **Error Scenarios**: Test graceful degradation
5. **File System Tests**: Test status file management

## Deployment Considerations

### Build Configuration

```toml
[dependencies]
# Additional dependencies for network monitoring
isahc = { version = "1.7", features = ["json", "timing"] }
notify = "6.0"
tokio = { version = "1.0", features = ["full"] }
chrono = { version = "0.4", features = ["serde"] }
thiserror = "1.0"

# Existing dependencies (unchanged)
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
clap = { version = "4.0", features = ["derive"] }

[dev-dependencies]
# Test dependencies for organized test structure
tokio-test = "0.4"
wiremock = "0.6"
tempfile = "3.0"
assert_matches = "1.5"

[profile.release]
opt-level = "s"        # Optimize for size
lto = true             # Link-time optimization
codegen-units = 1      # Better optimization
panic = "abort"        # Smaller binary size
strip = true           # Remove debug symbols

[features]
default = ["network-monitoring"]
network-monitoring = ["isahc", "tokio"]
```

### Installation Script Template

```bash
#!/bin/bash
# CCstatus Network Monitoring Installation

set -euo pipefail

# Detect platform and shell
PLATFORM=$(uname -s)
SHELL_TYPE="unknown"

if [[ -n "${ZSH_VERSION:-}" ]]; then
    SHELL_TYPE="zsh"
    PROFILE_FILE="${HOME}/.zshrc"
elif [[ -n "${BASH_VERSION:-}" ]]; then
    SHELL_TYPE="bash"
    PROFILE_FILE="${HOME}/.bash_profile"
fi

# Add shell integration function
add_shell_integration() {
    local profile_file="$1"
    
    if ! grep -q "claude_status" "$profile_file" 2>/dev/null; then
        echo "Adding CCstatus integration to $profile_file"
        cat >> "$profile_file" << 'EOF'

# CCstatus Network Monitoring
claude_status() {
    local status_file="$HOME/.claude/ccstatus/ccstatus-monitoring.json"
    [[ -f "$status_file" ]] || return
    
    if command -v jq >/dev/null 2>&1; then
        local status=$(jq -r '.status // empty' "$status_file" 2>/dev/null)
        local breakdown=$(jq -r '.network.breakdown // empty' "$status_file" 2>/dev/null)
        
        case "$status" in
            "healthy") echo "🟢" ;;
            "degraded") echo "🟡 $breakdown" ;;
            "error") echo "🔴 $breakdown" ;;
        esac
    fi
}

# Add to prompt (customize as needed)
# PS1="$(claude_status) $PS1"
EOF
    fi
}

case "$PLATFORM" in
    "Darwin"|"Linux")
        if [[ "$SHELL_TYPE" != "unknown" ]]; then
            add_shell_integration "$PROFILE_FILE"
            echo "Shell integration added. Restart your shell or run: source $PROFILE_FILE"
        else
            echo "Unsupported shell. Manual integration required."
        fi
        ;;
    *)
        echo "Platform $PLATFORM not officially supported. Manual integration may be required."
        ;;
esac
```

---

This design document provides the comprehensive technical foundation for implementing the CCstatus network monitoring system. Each component is designed to be modular, testable, and efficient while maintaining the zero-regression principle with existing CCometixLine functionality.