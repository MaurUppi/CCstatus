# CCstatus Network Monitoring Implementation Workflow (Revised)

**Version**: 2.0  
**Date**: 2025-08-19  
**Project**: CCstatus Network Monitoring  
**Platform**: Rust  
**Design Document**: [network-monitoring-design.md](./network-monitoring-design.md)  
**Current Version**: v1.0.3 → **Target Version**: v1.1.0

## Overview

Pragmatic implementation workflow for CCstatus network monitoring feature. Focus on clean implementation with essential testing and zero regression.

### Core Principles

1. **Feature Branch Development**: `feature/network-monitoring` branch
2. **Zero Regression**: Additive-only changes to existing functionality
3. **Practical Testing**: Test actual feature logic, not hypotheticals
4. **Simple CI/CD**: Stable Rust on Linux, macOS, Windows
5. **Atomic Commits**: Commit after each completed task for clear history

## Commit Strategy

Follow atomic commit practices:
- Commit after each completed task or logical unit
- Use clear, descriptive commit messages
- Format: `feat(component): description` for features
- Format: `test(component): description` for tests
- Format: `docs: description` for documentation

Example commit sequence:
```bash
git commit -m "feat(network): add module structure and dependencies"
git commit -m "feat(network): implement credential manager"
git commit -m "feat(network): add HTTP monitor with health checks"
git commit -m "test(network): add credential resolution tests"
git commit -m "docs: update README with network monitoring"
```

## Implementation Phases

### Phase 1: Core Implementation

#### Setup and Foundation

**Tasks:**
- [ ] Create feature branch: `git checkout -b feature/network-monitoring`
- [ ] Update `Cargo.toml` with network monitoring dependencies
- [ ] Create `src/core/segments/network/` module structure
- [ ] Define core types: `NetworkError`, `NetworkConfig`, `NetworkStatus`

**Dependencies:**
```toml
[dependencies]
isahc = { version = "1.7", features = ["json"], optional = true }
tokio = { version = "1.0", features = ["rt", "time", "sync", "fs"], optional = true }
thiserror = "1.0"

[features]
default = ["tui", "self-update"]
network-monitoring = ["isahc", "tokio"]  # Optional initially
```

#### Core Components

**Credential Manager:**
- [ ] Environment variable resolution (`ANTHROPIC_BASE_URL`, `ANTHROPIC_AUTH_TOKEN`)
- [ ] Claude Code config file parsing (`~/.claude/settings.json`)
- [ ] Priority: Environment → Claude config → None (fail silent)

**HTTP Monitor:**
- [ ] Simple health check using minimal Claude API call
- [ ] Latency tracking and error categorization
- [ ] Connection reuse for efficiency

**State Machine:**
- [ ] Three states: Healthy (30s/5min), Degraded (5s), Failed (60s)
- [ ] Adaptive frequency based on health status
- [ ] State transitions on success/failure events

**Network Segment:**
- [ ] Implement `Segment` trait for integration
- [ ] Async monitoring loop
- [ ] Non-blocking `render()` method
- [ ] Status file writing to `~/.claude/ccstatus/ccstatus-monitoring.json`

### Phase 2: Integration & Testing

#### Integration Points

**Segment Manager Integration:**
```rust
// src/core/segments/mod.rs
mod network;
pub use network::NetworkSegment;

// src/core/segments/manager.rs
if config.network.enabled {
    if let Ok(network_segment) = NetworkSegment::new(config) {
        segments.push(Box::new(network_segment));
    }
    // Fail silent if initialization fails
}
```

#### Essential Testing

**Test Structure:**
```
tests/
├── network_monitoring.rs      # Core functionality tests
├── integration.rs             # End-to-end tests
└── helpers/
    └── mock_server.rs        # Mock HTTP server utilities
```

**Focus Areas:**
- [ ] Credential resolution from actual sources
- [ ] Real HTTP health checks with mock server
- [ ] State machine transitions with actual events
- [ ] Status file writing and atomic updates
- [ ] Zero regression - existing features still work

**Key Tests:**
```rust
// tests/network_monitoring.rs
#[test]
fn test_credential_from_environment()
#[test]
fn test_credential_from_claude_config()
#[test]
fn test_no_credentials_fails_silent()

#[tokio::test]
async fn test_successful_health_check()
#[tokio::test]
async fn test_network_error_handling()
#[tokio::test]
async fn test_rate_limit_response()

#[tokio::test]
async fn test_state_transitions()
#[tokio::test]
async fn test_adaptive_intervals()

// tests/integration.rs
#[tokio::test]
async fn test_network_segment_integration()
#[tokio::test]
async fn test_status_file_updates()
#[tokio::test]
async fn test_existing_features_unaffected()
```

### Phase 3: CI/CD & Documentation

#### CI Pipeline

**Review Existing CI/CD:**
- [ ] Review `.github/workflows/ci.yml` for network monitoring test integration
- [ ] Update existing CI workflow to test network-monitoring feature
- [ ] Ensure release workflow handles new version properly

**Updates to existing `.github/workflows/ci.yml`:**
```yaml
# Add to existing test job in .github/workflows/ci.yml:
- name: Test network monitoring
  run: cargo test --features network-monitoring

- name: Build with all features
  run: cargo build --all-features
```

#### Documentation

**README Updates:**
- [ ] README.md - Add network monitoring section with brief summary:
  ```markdown
  ## Network Monitoring (v1.1.0+)
  
  CCstatus includes Claude API connectivity monitoring that displays real-time status in your statusline:
  - 🟢 Healthy connection
  - 🟡 Degraded performance
  - 🔴 Connection issues
  
  Enable in your config with `network.enabled = true`
  ```
- [ ] README.zh.md - Add Chinese translation of network monitoring section
- [ ] Configuration example in docs
- [ ] Shell integration examples

**CHANGELOG.md Update:**
```markdown
## [1.1.0] - 2025-XX-XX

### Added
- **Network Monitoring**: Real-time Claude API connectivity status in statusline
  - Automatic credential detection from environment or Claude Code config
  - Adaptive health check frequency (30s healthy → 5min stable, 5s degraded, 60s failed)
  - Visual indicators: 🟢 healthy, 🟡 degraded, 🔴 error
  - Status file at `~/.claude/ccstatus/ccstatus-monitoring.json` for shell integration
  - Zero-impact when disabled or credentials unavailable

### Changed
- Updated default features to include optional network monitoring
- Enhanced segment system to support async monitoring components

### Technical Details
- New dependencies: isahc (HTTP client), tokio (async runtime)
- Non-blocking architecture with separate monitoring thread
- Fail-silent design: no impact on statusline if monitoring unavailable
- Cross-platform support: Linux, macOS, Windows
```

**Shell Integration Example:**
```bash
# Add to .bashrc/.zshrc
claude_status() {
    local status_file="$HOME/.claude/ccstatus/ccstatus-monitoring.json"
    [[ -f "$status_file" ]] || return
    
    local status=$(jq -r '.status' "$status_file" 2>/dev/null)
    case "$status" in
        "healthy") echo "🟢" ;;
        "degraded") echo "🟡" ;;
        "error") echo "🔴" ;;
    esac
}

# Add to prompt
PS1="$(claude_status) $PS1"
```

## Quality Gates

### Gate 1: Core Complete
**Before Phase 2:**
- [ ] All core components implemented
- [ ] Project compiles without warnings
- [ ] Basic functionality works locally

### Gate 2: Ready to Merge
**Before merging to main:**
- [ ] All tests passing on all platforms
- [ ] No regression in existing features
- [ ] Documentation updated
- [ ] Code review approved

## Risk Management

### Technical Risks

**Async Runtime Conflicts:**
- Use `Handle::try_current()` pattern
- Fail silent if no runtime available

**Performance Impact:**
- Bounded resource usage (max 100 latency samples, 50 error records)
- Non-blocking render method
- Efficient connection reuse

**Cross-platform Issues:**
- Test on all three platforms in CI
- Handle path separators correctly
- Account for different home directory patterns

## Success Criteria

### Functional
- [ ] Network status correctly reflects API connectivity
- [ ] Adaptive frequency works as designed
- [ ] Status file updates reliably
- [ ] Graceful degradation on errors
- [ ] Zero false positives when healthy

### Technical
- [ ] Memory usage stays bounded
- [ ] CPU usage minimal (<1% idle, <5% active)
- [ ] No blocking operations in render path
- [ ] Clean integration with existing segments
- [ ] Feature can be disabled via config

### Quality
- [ ] Core functionality thoroughly tested
- [ ] Cross-platform compatibility verified
- [ ] No regressions in existing features
- [ ] Documentation clear and complete

## Deployment Strategy

### Feature Flags

```toml
[features]
# Initial release - optional
network-monitoring = ["isahc", "tokio"]

# After validation - include in default
default = ["tui", "self-update", "network-monitoring"]
```

### Rollout
1. **Alpha**: Feature branch testing
2. **Beta**: Optional feature flag in v1.1.0-beta
3. **Stable**: v1.1.0 release with optional flag
4. **Default**: v1.2.0 enabled by default (future)

## Implementation Checklist

### Phase 1 Checklist
- [ ] Dependencies added to Cargo.toml
- [ ] Network module structure created
- [ ] Credential manager implemented
- [ ] HTTP monitor with health checks
- [ ] State machine with adaptive intervals
- [ ] Network segment with Segment trait
- [ ] Status file writer

### Phase 2 Checklist
- [ ] Integration with segment manager
- [ ] Core functionality tests written
- [ ] Integration tests with mock server
- [ ] Regression tests passing
- [ ] Manual testing on local machine

### Phase 3 Checklist
- [ ] Review and update existing CI workflows
- [ ] Tests passing on all platforms
- [ ] README.md and README.zh.md updated
- [ ] CHANGELOG.md updated following Keep a Changelog format
- [ ] Version bumped to v1.1.0 in Cargo.toml
- [ ] Shell integration examples documented
- [ ] Ready for code review

## Summary

This revised workflow focuses on pragmatic implementation over process. The goal is clean, well-tested code that integrates smoothly with existing CCstatus functionality without regression. Total effort should be manageable with three focused phases.

---

**Document Status**: Ready for Implementation  
**Next Action**: Create feature branch and begin Phase 1