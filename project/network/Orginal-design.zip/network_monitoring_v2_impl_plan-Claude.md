# Network Monitoring Pipeline v2 - Implementation Plan

## Current State Analysis
- **Existing**: Only `credential.rs` and `credential.md` in network module
- **Missing**: NetworkSegment implementation and all monitoring components  
- **Gap**: No integration with statusline segment trait

## Architecture Overview
Event-driven pipeline triggered by stdin, no background threads:
```
stdin → NetworkSegment → CredentialManager → HttpMonitor/JsonlMonitor → StateManager → StatusRenderer
```

## Implementation Modules

### 1. **mod.rs** - Module orchestrator
- Export NetworkSegment and all submodules
- Public API surface for the network module

### 2. **segment.rs** - NetworkSegment implementation
- Implement Segment trait for statusline integration
- Coordinate credential resolution, monitoring, and rendering
- Handle stdin trigger and frequency windows (GREEN: 300s/3s, RED: 10s/1s)

### 3. **types.rs** - Core data structures
```rust
- ApiCredentials (already in credential.rs, move here)
- NetworkStatus (healthy, degraded, error, unknown)
- MonitoringState (window IDs, state tracking)
- NetworkMetrics (latency, breakdown, P95)
- CredentialSource enum
```

### 4. **http_monitor.rs** - API health monitoring
- Light POST to /v1/messages with minimal payload
- Adaptive timeout: GREEN (P95+500ms, 2.5-4s), RED (fixed 2s)
- Timing breakdown: DNS|TCP|TLS|TTFB|Total
- Error classification: Authentication, RateLimit, ServerError, Network

### 5. **jsonl_monitor.rs** - Transcript error detection
- Scan transcript tail for `isApiErrorMessage:true`
- Trigger RED monitoring window on error detection
- Extract error metadata (code, message, timestamp)

### 6. **state_manager.rs** - Persistent state management
- Write to `~/.claude/ccstatus-monitoring.json`
- Schema: status, api_config, network metrics, rolling_totals, P95
- Single writer pattern (only HttpMonitor writes)
- Atomic file operations with proper locking

### 7. **status_renderer.rs** - Statusline rendering
- Map NetworkStatus to emoji (🟢🟡🔴⚪)
- Format display text with latency and status
- Handle unknown/no-credential states gracefully

### 8. **debug_logger.rs** - Debug utilities
- Async logging with CCSTATUS_DEBUG env var
- Structured logging for each component
- Performance metrics tracking

### 9. **error_tracker.rs** - Error management
- Track last error events
- Classify HTTP status codes
- Maintain error history for RED window decisions

## Key Implementation Details

### Frequency Control Logic
```rust
// GREEN window: every 300s, first 3s
let in_green_window = (total_duration_ms % 300_000) < 3_000;

// RED window: every 10s, first 1s (only if error detected)
let in_red_window = has_error && (total_duration_ms % 10_000) < 1_000;
```

### P95 Calculation (GREEN samples only)
- Maintain rolling_totals array (capacity: 12 for ~60min)
- Only append successful GREEN probes (HTTP 200)
- Calculate P80/P95 for adaptive thresholds

### Credential Resolution Flow
1. Check environment variables (highest priority)
2. Parse shell configs (.zshrc/.bashrc)
3. Read Claude config JSON (lowest priority)
4. If no credentials: status=unknown, skip monitoring

## Migration Path
1. Create mod.rs to export NetworkSegment
2. Implement minimal NetworkSegment in segment.rs
3. Add types.rs with core structures
4. Implement http_monitor.rs with credential integration
5. Add state_manager.rs for persistence
6. Implement jsonl_monitor.rs for error detection
7. Add status_renderer.rs for display
8. Integrate debug_logger.rs and error_tracker.rs
9. Write comprehensive tests in tests/ directory
10. Update main statusline.rs integration

## Testing Strategy
All test code will be saved in separate test files in the `tests/` directory, NOT included in source code:

### Test File Organization
- `tests/network/segment_tests.rs` - NetworkSegment integration tests
- `tests/network/http_monitor_tests.rs` - HTTP monitoring tests with mock responses
- `tests/network/jsonl_monitor_tests.rs` - Transcript parsing tests
- `tests/network/state_manager_tests.rs` - State persistence tests
- `tests/network/credential_manager_tests.rs` - Credential resolution tests (existing)
- `tests/network/status_renderer_tests.rs` - Rendering logic tests
- `tests/network/debug_logger_tests.rs` - Logging functionality tests
- `tests/network/error_tracker_tests.rs` - Error tracking tests

### Test Coverage Areas
- Unit tests for each module's public functions
- Integration test with mock stdin/transcript
- Credential resolution test suite (all 3 sources)
- HTTP monitor with mock responses
- State persistence and atomic write verification
- End-to-end statusline rendering test
- Frequency window calculation tests
- P95 calculation with various sample sizes
- Error classification and RED window triggering

## Environment Variables
- `ANTHROPIC_BASE_URL` - API endpoint
- `ANTHROPIC_AUTH_TOKEN` - Auth token
- `CCSTATUS_TIMEOUT_MS` - Override timeout (max 6000ms)
- `CCSTATUS_DEBUG` - Enable debug logging

## Implementation Notes
This implementation maintains backward compatibility while adding comprehensive monitoring capabilities as specified in the v2 design document. The modular design allows for incremental development and testing of each component independently.