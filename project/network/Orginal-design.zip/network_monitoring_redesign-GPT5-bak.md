# Network Monitoring Pipeline — Redesign

---

## 🎯 设计目标

* **无后台线程**：完全由 statusline 的 stdin 输入触发。
* **轻量探测**：每次仅在必要时执行一次轻量 POST `/v1/messages`。
* **诊断能力**：输出详细的 `DNS|TCP|TLS|TTFB|Total` 分解时序和错误类型。
* **事件驱动**：通过 transcript 实时写入的 API error 触发 RED 高频检测。
* **趋势可见性**：在 ccstatus-monitoring.json 中维护 Total 延迟的滚动窗口，实时计算 **P95**，用于显示稳定性趋势。

---

## 🔑 输入与触发

* **触发时机**：每次 **Claude API 返回** 后，CLI 会把一次性 payload 通过 **statusline 的 stdin** 传入（包含 `transcript_path`、`cost.total_duration_ms` 等）。
* **statusline stdin JSON**：作为本次渲染/监控的唯一触发源，无需任何后台线程或轮询。
* **transcript\_path**：指向当前 session 的 jsonl 文件；仅在 **异常（RED）路径**用于错误检测。
* **JsonlMonitor（仅 RED 路径使用）**：每次调用时读取 transcript 文件尾部 N KB，检查是否存在 `isApiErrorMessage: true`。**GREEN 巡检路径不读取 transcript**。

---

## ⚙️ 频率控制

* **GREEN（巡检）**：每 300 秒的前 3 秒窗口。
* **RED（错误追踪）**：每 10 秒的前 1 秒窗口。
* **逻辑**：

  ```pseudo
  if (network_degraded && in_RED_window) || in_GREEN_window:
      trigger_probe_once_per_window()
  ```
* **去重**：通过 `window_id = floor(total_ms / window_size)` 与 `ccstatus-monitoring.json` 的记录避免重复探测。

---

## 📡 探测实现

* **请求**：POST `/v1/messages`，payload 最小化（Haiku + `max_tokens=1`）。
* **超时**：整体 2s，避免 statusline 阻塞。
* **结果分解**：输出 `DNS|TCP|TLS|TTFB|Total`。
* **错误分类**：

  * 401/403 → Authentication
  * 429 → RateLimit
  * 5xx/502/504/529 → ServerError（529 可视为 Overloaded）
  * 超时/连接失败 → Network

POST sample
```
curl -X POST {ANTHROPIC_BASE_URL}/v1/messages \
  -H "Content-Type: application/json" \
  -H "x-api-key: {ANTHROPIC_AUTH_TOKEN}" \
  -d '{
    "model": "claude-3-haiku-20240307",
    "max_tokens": 1,
    "messages": [
      {"role": "user", "content": "Hi"}
    ]
  }'
```

RESPONES sample
```
{"id":"msg_014aLUQSouuj3wj2qP3ThkWw","type":"message","role":"assistant","model":"claude-3-haiku-20240307","content":[{"type":"text","text":"Hello"}],"stop_reason":"max_tokens","stop_sequence":null,"usage":{"input_tokens":22,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"cache_creation":{"ephemeral_5m_input_tokens":0,"ephemeral_1h_input_tokens":0},"output_tokens":1,"service_tier":"standard"}}%
```
---

## 📂 状态存储（ccstatus-monitoring.json）

示例扩展 schema：

```json
{
  "status": "healthy",
  "monitoring_enabled": true,
  "api_config": {
    "endpoint": "{ANTHROPIC_BASE_URL}",
    "source": "environment"
  },
  "network": {
    "latency_ms": 2650,
    "breakdown": "DNS:20ms|TCP:30ms|TLS:40ms|TTFB:1324ms|Total:2650ms",
    "last_http_status": 200,
    "error_type": null,
    "rolling_totals": [300, 280, 2650, 420, 500],
    "p95_latency_ms": 1200
  },
  "monitoring_state": {
    "last_green_window_id": 123,
    "last_red_window_id": 456,
    "state": "healthy"
  },
  "last_error_event": {
    "timestamp": "2025-08-21T15:17:29.521Z",
    "code": 529,
    "message": "Overloaded"
  },
  "timestamp": "2025-08-21T13:45:19.586212+08:00"
}
```

### 滚动 P95

* 每次探测成功后，将 `Total latency` 推入 `rolling_totals`（固定长度 N，例如 20）。
* 从该数组实时计算 **P95**，写入 `p95_latency_ms`。
* 渲染时：

  * 仅显示单次 Total → 用于诊断。
  * 显示 P95 → 用于趋势。

---

## 🎨 渲染逻辑

* 🟢 **正常**：200 且 Total < 500ms → 显示绿点。
* 🟡 **退化**：429 或 Total ≥ 500ms → 黄点 + 分解时序。
* 🔴 **错误**：4xx/5xx/超时 → 红点 + 分解时序 + 错误类型。
* ⚪ 未配置；⚫ 显式禁用。

### 渲染效果示例

* 🟢

  ```
  🟢 Total=320ms | P95=450ms
  ```
* 🟡

  ```
  🟡 DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms | P95=1100ms
  ```
* 🔴

  ```
  🔴 DNS:12ms|TCP:28ms|TLS:45ms|TTFB:-|Total:2000ms [504 Gateway Timeout | ServerError] | P95=1700ms
  ```

---

## 📊 时序图

> 为准确反映触发时机，分为两条独立链路：**巡检（GREEN）** 与 **异常（RED）**。

### 1) 巡检（GREEN）

```mermaid
sequenceDiagram
    participant User as 用户输入
    participant API as Claude API
    participant Statusline as statusline(stdin)
    participant HttpMonitor as HttpMonitor
    participant State as ccstatus-monitoring.json

    User->>API: 发送请求
    API-->>Statusline: 返回响应并触发 stdin payload（含 total_duration_ms）
    Statusline->>HttpMonitor: 判断是否命中 GREEN 窗口
    alt 命中
        HttpMonitor->>API: 轻量探测 (POST /v1/messages)
        API-->>HttpMonitor: 返回 (200/429/5xx)
        HttpMonitor-->>State: 更新 latency/breakdown/rolling_totals/p95/status
    else 未命中
        Statusline-->>State: 跳过探测，沿用上次状态
    end
    State-->>Statusline: 渲染状态 🟢/🟡/🔴
```

### 2) 异常（RED）

```mermaid
sequenceDiagram
    participant User as 用户输入
    participant API as Claude API
    participant Transcript as transcript.jsonl
    participant Statusline as statusline(stdin)
    participant JsonlMonitor as JsonlMonitor
    participant HttpMonitor as HttpMonitor
    participant State as ccstatus-monitoring.json

    User->>API: 发送请求
    API-->>Transcript: 写入响应/错误行
    API-->>Statusline: 返回响应并触发 stdin payload（含 transcript_path）
    Statusline->>JsonlMonitor: 读取 transcript 尾部 N KB
    JsonlMonitor->>JsonlMonitor: 发现 isApiErrorMessage:true ?
    alt 是
        JsonlMonitor->>HttpMonitor: 标记 degraded
        HttpMonitor->>HttpMonitor: 判定 RED 窗口
        alt 命中
            HttpMonitor->>API: 轻量探测 (POST /v1/messages)
            API-->>HttpMonitor: 返回 (200/429/5xx)
        end
        HttpMonitor-->>State: 更新 latency/breakdown/rolling_totals/p95/status
    else 否
        Statusline->>HttpMonitor: （可选）走 GREEN 窗口判定
    end
    State-->>Statusline: 渲染状态
```

---

## ✅ 总结

* `transcript_path` 让我们总是聚焦当前 session 文件 → JsonlMonitor 不需要偏移量。
* Statusline 驱动，JsonlMonitor 读取尾部即可捕获实时 API error。
* API error 触发 RED 高频探测，HttpMonitor 执行轻量请求并更新状态。
* `ccstatus-monitoring.json` 记录最近 N 次 Total → 实时计算 P95，增强趋势可视化。
* 最终渲染既包含单次诊断，也包含滚动稳定性趋势。

