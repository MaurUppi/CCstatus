# Network Monitoring Pipeline v2 — Implementation Plan (GPT‑5)

## Alignment with Redesign (network_monitoring_redesign‑GPT5.md)
- Single writer: Only `HttpMonitor` persists to `ccstatus-monitoring.json`.
- GREEN-only P95: Only successful GREEN (HTTP 200) samples append to `rolling_totals` (MAX_LEN=12).
- RED flow: Error-driven. `JsonlMonitor` detects errors from transcript; only then apply RED window (10s/1s). RED never writes `rolling_totals/p95`.
- Status values (root-level `status`): `healthy | degraded | error | unconfigured`.
- State path: project-scoped `~/.claude/projects/<workspace>/ccstatus-monitoring.json` (not a single global file).
- Env vars: `ccstatus_TIMEOUT_MS` (int, ms), `ccstatus_debug` (bool), plus `ANTHROPIC_BASE_URL`, `ANTHROPIC_AUTH_TOKEN`.

---

## Architecture Overview
Event-driven, no background threads.
```
stdin → NetworkSegment → CredentialManager → JsonlMonitor(error detect) → Frequency Gate → HttpMonitor → StateManager(atomic write) → StatusRenderer
```

---

## Implementation Modules

### 1) mod.rs — Orchestrator
- Re-export `segment`, `http_monitor`, `jsonl_monitor`, `state_manager`, `status_renderer`, `types`, `error_tracker`, `debug_logger`, `credential` (existing).

### 2) segment.rs — NetworkSegment
- Implements Segment trait for statusline; entrypoint invoked per stdin update.
- Steps per call:
  1) Resolve credentials via `CredentialManager` (env > shell > claude config). If none → write `status=unconfigured, monitoring_enabled=false`, render and exit.
  2) Run `JsonlMonitor::scan_tail(transcript_path)` to detect `isApiErrorMessage:true` and extract `code/message/timestamp`.
  3) If `error_detected=true` and in RED window (10s/1s) → call `HttpMonitor::probe(RED)` with credentials.
  4) If in GREEN window (300s/3s) → call `HttpMonitor::probe(GREEN)` with credentials.
  5) Render status using `StatusRenderer`.

### 3) types.rs — Core types (shared)
- `pub use` credential types from existing module; do not move.
- `enum NetworkStatus { Healthy, Degraded, Error, Unknown }`
- `struct MonitoringState { last_green_window_id: u64, last_red_window_id: u64 }`
- `struct NetworkMetrics { latency_ms: u32, breakdown: String, last_http_status: u16, error_type: Option<String>, rolling_totals: Vec<u32>, p95_latency_ms: u32 }`
- `enum CredentialSource { Environment, ShellConfig(PathBuf), ClaudeConfig(PathBuf) }` (align with credential.md)
- Error metadata struct: `JsonlError { timestamp: String, code: u16, message: String }`

### 4) http_monitor.rs — HTTP probe
- Minimal POST to `{base_url}/v1/messages` with `x-api-key` header.
- Timeout policy:
  - GREEN: `timeout_ms = clamp(p95_latency_ms + 500, 2500, 4000)`; if `rolling_totals.len() < 4`, use `3500`.
  - RED: fixed `2000`.
  - Env override: if `ccstatus_TIMEOUT_MS` set, both take `min(env_value, 6000)`.
- Produces: timing breakdown `DNS|TCP|TLS|TTFB|Total`, HTTP status, error_type.
- Writes via `StateManager`:
  - GREEN: update instant fields; if HTTP 200 then append to `rolling_totals` (cap=12) and recompute `p95_latency_ms`; set `status` = `healthy` or `degraded` by P80/P95 rules.
  - RED: update instant fields + `last_jsonl_error_event`; set `status=error`; do not touch `rolling_totals/p95`.

### 5) jsonl_monitor.rs — Transcript scanner
- Read tail N KB of transcript each stdin call.
- Detect `isApiErrorMessage:true`; extract `timestamp`, `code`, `message`.
- Return `(error_detected: bool, last_error_event: Option<JsonlError>)` (only for RED gating; does not set `status`).

### 6) state_manager.rs — Persistence
- Resolve project-scoped state path: `~/.claude/projects/<workspace>/ccstatus-monitoring.json` using stdin `workspace.project_dir`/`cwd`.
- Single-writer discipline: only invoked by `HttpMonitor`.
- Atomic write: write to temp, `fsync`, `rename`.
- Optional advisory file lock to avoid concurrent writers if process concurrency is introduced later.

### 7) status_renderer.rs — UI mapping
- Emoji: 🟢/🟡/🔴/⚪ map to `healthy/degraded/error/unconfigured`.
- Text: show `P95` for healthy/degraded; show breakdown and error_type for degraded/error.
- Thresholds (from GREEN-only samples):
  - healthy: HTTP 200 and `Total ≤ P80`
  - degraded: HTTP 200 and `P80 < Total ≤ P95`, or HTTP 429
  - error: HTTP 4xx/5xx (except 429), timeout/connect error, or HTTP 200 with `Total > P95`

### 8) debug_logger.rs — Logging
- Controlled by env `ccstatus_debug` (bool). Default `false`.
- No secret logging; print credential source and token length only.

### 9) error_tracker.rs — Classification utils
- Classify HTTP status → `error_type` buckets.
- Not a writer; only provides helpers used by `HttpMonitor`.

---

## Frequency Control Logic
```rust
// GREEN window: every 300s, first 3s
let in_green_window = (total_duration_ms % 300_000) < 3_000;

// RED window: only if error detected, then every 10s, first 1s
let in_red_window = error_detected && ((total_duration_ms % 10_000) < 1_000);
```

---

## P95 Calculation (GREEN samples only)
- `rolling_totals` capacity: `12` (≈60 min at 300s cadence).
- Append only on GREEN HTTP 200 success.
- Compute `P80/P95` for rendering thresholds; keep simple percentile from array.

---

## Credential Resolution Flow
1) Environment variables (highest priority)
2) Shell configs (.zshrc/.bashrc) export and function patterns
3) Claude Code JSON config
4) If none: write `status=Unknown`, `monitoring_enabled=false`, skip monitoring

Note: `ApiCredentials` struct and helpers remain in `credential` module; re-export via `types.rs` if needed.

---

## Migration Path
1) Create `mod.rs` to export modules.
2) Implement `segment.rs` with stdin parsing and orchestration.
3) Add `types.rs` with enums/structs (re-export credentials).
4) Implement `http_monitor.rs` with credential injection and timeout policy.
5) Implement `state_manager.rs` with project-scoped path + atomic writes.
6) Implement `jsonl_monitor.rs` (tail scanner).
7) Implement `status_renderer.rs` threshold mapping.
8) Add `debug_logger.rs` and `error_tracker.rs` utilities.
9) Wire into statusline integration; add tests.

---

## Testing Strategy
- Unit tests per module.
- Integration test with mock stdin/transcript.
- Credential resolution across three sources.
- HTTP monitor with mocked responses and timeout override paths.
- State persistence path resolution and atomicity.
- Frequency window calculations (edge boundaries).
- P95 computation with small/large samples; RED does not affect `rolling_totals`.
- Rendering mapping at P80/P95 boundaries; 429 and timeout cases.

Suggested test files:
- `tests/network/segment_tests.rs`
- `tests/network/http_monitor_tests.rs`
- `tests/network/jsonl_monitor_tests.rs`
- `tests/network/state_manager_tests.rs`
- `tests/network/credential_manager_tests.rs`
- `tests/network/status_renderer_tests.rs`
- `tests/network/debug_logger_tests.rs`
- `tests/network/error_tracker_tests.rs`

---

## Environment Variables
- `ANTHROPIC_BASE_URL` — API endpoint (e.g., https://api.anthropic.com)
- `ANTHROPIC_AUTH_TOKEN` — API auth token
- `ccstatus_TIMEOUT_MS` — integer ms; overrides GREEN/RED HTTP timeouts; both use `min(env_value, 6000)`
- `ccstatus_debug` — boolean; enable verbose logs (default false)

---

## Implementation Notes
- Consistent with redesign v2: GREEN-only P95, RED error-driven, single writer, project-scoped state path.
- Timeout policy matches endpoint latency logs (2.7–3.5s): GREEN adaptive, RED 2s fixed; env override available.
- No background threads; all work is triggered per stdin event.
