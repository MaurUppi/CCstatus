# Network Monitoring Pipeline — v2 (Credential‑enabled)

---

## 🎯 设计目标（继承 + 增强）

- 无后台线程：完全由 statusline 的 stdin 输入触发。
- 轻量探测：必要时执行一次轻量 POST `/v1/messages`。
- 诊断能力：输出 `DNS|TCP|TLS|TTFB|Total` 分解时序与错误类型。
- 事件驱动：transcript 中的 API error 触发 RED 高频检测。
- 趋势可见性：`rolling_totals` 计算 P95，用于趋势展示（仅 GREEN 样本）。
- 凭证集成：HttpMonitor 通过 CredentialManager 解析凭证（优先级：环境变量 > Shell 配置 > Claude 配置），无凭证则以 `status=unknown` 呈现，跳过探测。

---

## 🔑 输入与触发

- 触发时机：每次 Claude API 返回后，CLI 将一次性 payload 通过 statusline 的 stdin 传入（含 `transcript_path`、`cost.total_duration_ms` 等）。
- stdin JSON：作为本次渲染/监控的唯一触发源，无后台线程或轮询。
- transcript_path：指向当前 session 的 jsonl，用于错误检测。
- JsonlMonitor（错误检测）：每次 stdin 触发时读取 transcript 尾部 N KB，若检测到 `isApiErrorMessage:true`（degraded=true），再进入 RED（每 10 秒前 1 秒）的频率窗口判定；GREEN 巡检不依赖 transcript。

---

## 🔐 CredentialManager 模块

- 代码: @src/core/segments/network/credential.rs
- 文档: @src/core/segments/network/credential.md
- 解析优先级（三层）：
  - 环境变量：`ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`（最高优先级）
  - Shell 配置：解析 `.zshrc/.bashrc` 导出与函数变量
  - Claude Code 配置：JSON 键值读取
- 使用模式（每次 stdin 触发时解析一次，结果仅在本次流程内使用，无缓存）：
  - 成功：提供 `base_url` 与 `auth_token`，HttpMonitor 以此构造请求。
  - 失败（None）：写入 `status=unknown`，可选设置 `monitoring_enabled=false`，跳过 RED/GREEN 探测，沿用上次 `p95_latency_ms`。
- 状态持久化：在 `api_config` 中记录 `endpoint` 与 `source`（环境变量、Shell 路径或配置文件路径），用于审计与调试。

---

## ⚙️ 频率控制

- GREEN（巡检）：每 300 秒的前 3 秒窗口（基于 `total_duration_ms` 计算）。
- RED（错误追踪）：仅当 JsonlMonitor 检测到错误后，才套用“每 10 秒的前 1 秒”窗口。
- 逻辑：

```pseudo
resolve_credentials() -> creds | None
if creds is None:
    write_state(status=unknown, monitoring_enabled=false, api_config.source=null)
    render_and_exit()

scan_transcript_tail() -> degraded (true/false)
if degraded and in_RED_window:
    trigger_RED_probe_once()

if in_GREEN_window:
    trigger_GREEN_probe_once()
```

---

## 📡 探测实现（凭证注入）

- 请求：POST `{base_url}/v1/messages`，Header `x-api-key: {auth_token}`，payload 最小（Haiku + `max_tokens=1`）。
- 超时（依据真实端到端 2.7–3.5s 数据修订）：
  - GREEN 探测：自适应超时，`timeout_ms = clamp(p95_latency_ms + 500, 2500, 4000)`；当样本不足（`rolling_totals` < 4）时，临时使用 3500ms。
  - RED 探测：固定 2000ms，保证故障场景下状态线快速返回。
  - 可配置覆盖：环境变量 `ccstatus_TIMEOUT_MS` 若设置，则两类探测均取 `min(env_value, 6000)` 作为上限。
- 结果分解：输出 `DNS|TCP|TLS|TTFB|Total`。
- 错误分类：
  - 401/403 → Authentication
  - 429 → RateLimit
  - 5xx/502/504/529 → ServerError（529 → Overloaded）
  - 超时/连接失败 → Network

---

## 📂 状态存储（ccstatus-monitoring.json）

示例扩展 schema：

```json
{
  "status": "healthy",
  "monitoring_enabled": true,
  "api_config": {
    "endpoint": "{ANTHROPIC_BASE_URL}/v1/messages",
    "source": "environment"  
  },
  "network": {
    "latency_ms": 2650,
    "breakdown": "DNS:20ms|TCP:30ms|TLS:40ms|TTFB:1324ms|Total:2650ms",
    "last_http_status": 200,
    "error_type": null,
    "rolling_totals": [300, 280, 2650, 420, 500],
    "p95_latency_ms": 1200
  },
  "monitoring_state": {
    "last_green_window_id": 123,
    "last_red_window_id": 456,
    "state": "healthy"  
  },
  "last_jsonl_error_event": {
    "timestamp": "2025-08-21T15:17:29.521Z",
    "code": 529,
    "message": "Overloaded"
  },
  "timestamp": "2025-08-21T13:45:19.586212+08:00"
}
```

说明：
- 无凭证时：`status=unknown`，`monitoring_enabled=false`，`api_config.source=null` 或省略，跳过探测。
- RED 路径不写 `rolling_totals/p95`；`p95_latency_ms` 仅由 GREEN 成功样本计算。

---

## 滚动 P95（仅 GREEN 采样）

- 写入时机：仅在 GREEN 探测成功（HTTP 200）时，将本次 Total 追加到 `rolling_totals`。
- 固定窗口容量（MAX_LEN）：当 GREEN 窗口为每 300 秒一次时，设定 `MAX_LEN = 12`（覆盖最近约 60 分钟的基线趋势）。如调整 GREEN 频率，可按“期望分钟数 × 每分钟采样次数”重算 MAX_LEN。
- P95 计算：每次写入后，从 `rolling_totals` 计算 95 分位写入 `p95_latency_ms`。
- 错误样本处理：429/5xx/超时仅用于“本次渲染颜色判定”，不写入 `rolling_totals`。

伪代码：

```
if is_green_window and probe_succeeded_with_http_200:
  rolling_totals.push(total_latency_ms)
  trim_to_N(rolling_totals, MAX_LEN)   // MAX_LEN = 12 （≈60 分钟）
  p95_latency_ms = percentile(rolling_totals, 0.95)
```

---

## 🎨 渲染逻辑与状态机（自适应阈值）

在线阈值来自 `rolling_totals` 的分位数（每次 GREEN 200 成功更新），并写入 `status`：

- 🟢 healthy：HTTP 200 且 `Total ≤ P80(rolling_totals)`
- 🟡 degraded：
  - HTTP 200 且 `P80 < Total ≤ P95`，或
  - HTTP 429（速率限制）
- 🔴 error：
  - HTTP 4xx/5xx（除 429）、超时/连接失败，或
  - HTTP 200 但 `Total > P95`
- ⚪ unknown：无可用凭证或尚未有检测结果

写入职责（单写者：HttpMonitor）：
- GREEN：更新 `network.latency_ms/breakdown/last_http_status/error_type/status`；若 200 成功则追加 `rolling_totals` 并重算 `p95_latency_ms`，`status` 设为 healthy/degraded。
- RED：基于 JsonlMonitor 错误检测且命中 RED 窗口后，更新 `network.latency_ms/breakdown/last_http_status/error_type/status` 与 `last_error_event`，`status` 设为 error；不写 `rolling_totals/p95`。
- 无凭证：直接写 `status=unknown`，不触发探测。

---

## 环境变量

- ANTHROPIC_BASE_URL：API 端点，例如 `https://api.anthropic.com`
- ANTHROPIC_AUTH_TOKEN：API 认证 Token
- ccstatus_TIMEOUT_MS：整数（ms）。覆盖 GREEN/RED 探测 HTTP 超时；两类探测均取 `min(env_value, 6000)`。
- ccstatus_debug：布尔。启用详细日志（`true`/`false`），默认 `false`。

- 说明：
    - 凭证解析优先级为 环境变量 > Shell 配置 > Claude 配置；
    - `ccstatus_TIMEOUT_MS` 与 `ccstatus_debug` 为 ccstatus 本地运行时参数，不影响凭证解析优先级。

---

## 📊 统一时序图（含 CredentialManager）

```mermaid
sequenceDiagram
    participant User as 用户输入
    participant API as Claude API
    participant Transcript as transcript.jsonl
    participant Statusline as statusline(stdin)
    participant CredentialMgr as CredentialManager
    participant JsonlMonitor as JsonlMonitor
    participant HttpMonitor as HttpMonitor
    participant State as ccstatus-monitoring.json

    User->>API: 发送请求
    API-->>Transcript: 追加响应/错误行
    API-->>Statusline: 触发 stdin JSON（含 total_duration_ms, transcript_path）

    Statusline->>CredentialMgr: 解析凭证（env > shell > claude config）
    alt 无凭证
        CredentialMgr-->>State: 写入 status=unknown, monitoring_enabled=false
        State-->>Statusline: 渲染 ⚪ unknown
        Note over Statusline: 结束本次流程
    else 有凭证
        CredentialMgr-->>HttpMonitor: base_url + auth_token

        Statusline->>Statusline: 基于 total_duration_ms 计算 in_GREEN_window
        Statusline->>JsonlMonitor: 扫描 transcript 尾部 N KB（错误检测）
        JsonlMonitor->>JsonlMonitor: 发现 isApiErrorMessage:true ?

        alt degraded=true
            Statusline->>Statusline: 计算 in_RED_window（每 10 秒的前 1 秒）
            alt 命中 RED 窗口
                JsonlMonitor->>HttpMonitor: 传递错误元数据
                HttpMonitor->>API: 轻量探测 (凭证注入)
                API-->>HttpMonitor: 返回 (200/429/5xx)
                HttpMonitor-->>State: 更新 latency/breakdown/status/last_error_event（不写 rolling_totals/p95）
            else 未命中 RED 窗口
                Statusline->>Statusline: 跳过 RED 探测
            end
        else degraded=false
            Statusline->>Statusline: 未检测到错误，跳过 RED
        end

        alt 命中 GREEN 窗口
            Statusline->>HttpMonitor: 触发 GREEN 探测 (凭证注入)
            HttpMonitor->>API: 轻量探测
            API-->>HttpMonitor: 返回 (200/429/5xx)
            HttpMonitor-->>State: 更新 latency/breakdown/rolling_totals/p95/status（仅 200 写入 rolling_totals）
        else 未命中 GREEN 窗口
            Statusline-->>State: 沿用上次状态
        end

        State-->>Statusline: 渲染状态 🟢/🟡/🔴
    end
```

---

## GREEN 时序图（凭证注入 + P95）

```mermaid
sequenceDiagram
    participant User as 用户输入
    participant API as Claude API
    participant Transcript as transcript.jsonl
    participant Statusline as statusline(stdin)
    participant CredentialMgr as CredentialManager
    participant HttpMonitor as HttpMonitor
    participant State as ccstatus-monitoring.json

    User->>API: 发送请求
    API-->>Transcript: 追加响应/错误行
    API-->>Statusline: 触发 stdin JSON

    Statusline->>CredentialMgr: 解析凭证
    alt 无凭证
        CredentialMgr-->>State: 写入 status=unknown, monitoring_enabled=false
        State-->>Statusline: 渲染 ⚪ unknown
    else 有凭证
        CredentialMgr-->>HttpMonitor: base_url + auth_token
        Statusline->>Statusline: 计算 in_GREEN_window
        alt 命中 GREEN 窗口
            Statusline->>HttpMonitor: 触发 GREEN 探测
            HttpMonitor->>API: 轻量探测 (凭证注入)
            API-->>HttpMonitor: 返回 (200/429/5xx)
            alt 返回 200
                HttpMonitor-->>State: 更新 latency/breakdown/last_http_status/error_type/status；追加 rolling_totals 并重算 p95
            else 返回 429/5xx/超时
                HttpMonitor-->>State: 更新 latency/breakdown/last_http_status/error_type/status（不写 rolling_totals/p95）
            end
        else 未命中 GREEN 窗口
            Statusline-->>State: 沿用上次状态
        end
        State-->>Statusline: 渲染（healthy/degraded/error）
    end
```

---

## RED 时序图（错误驱动 + 频率门控 + 凭证注入）

```mermaid
sequenceDiagram
    participant User as 用户输入
    participant API as Claude API
    participant Transcript as transcript.jsonl
    participant Statusline as statusline(stdin)
    participant CredentialMgr as CredentialManager
    participant JsonlMonitor as JsonlMonitor
    participant HttpMonitor as HttpMonitor
    participant State as ccstatus-monitoring.json

    User->>API: 发送请求
    API-->>Transcript: 追加响应/错误行
    API-->>Statusline: 触发 stdin JSON

    Statusline->>CredentialMgr: 解析凭证
    alt 无凭证
        CredentialMgr-->>State: 写入 status=unknown, monitoring_enabled=false
        State-->>Statusline: 渲染 ⚪ unknown
    else 有凭证
        CredentialMgr-->>HttpMonitor: base_url + auth_token
        Statusline->>JsonlMonitor: 扫描 transcript 尾部 N KB（错误检测）
        JsonlMonitor->>JsonlMonitor: 发现 isApiErrorMessage:true ?
        alt 发现错误
            Statusline->>Statusline: 计算 in_RED_window（每 10 秒的前 1 秒）
            alt 命中 RED 窗口
                JsonlMonitor->>HttpMonitor: 传递错误元数据
                HttpMonitor->>API: 轻量探测 (凭证注入)
                API-->>HttpMonitor: 返回 (200/429/5xx)
                HttpMonitor-->>State: 更新 latency/breakdown/last_http_status/error_type/status 与 last_error_event（不写 rolling_totals/p95）
            else 未命中 RED 窗口
                Statusline->>Statusline: 跳过 RED 探测
            end
        else 未发现错误
            Statusline->>Statusline: 不进入 RED 流程
        end
        State-->>Statusline: 渲染（error 或维持上次状态）
    end
```

---

## ✅ 总结

- 单写者：仅 HttpMonitor 写状态文件，避免并发冲突。
- 凭证优先级：环境 > Shell > Claude 配置；无凭证 → `status=unknown` 并跳过探测。
- GREEN：基于 `total_duration_ms` 的 300s/3s 窗口；仅 200 成功写入 `rolling_totals`；P95 由 GREEN 样本计算；阈值 P80/P95 自适应渲染。
- RED：错误驱动 + 10s/1s 窗口门控；更新即时字段与 `last_error_event`；不写 `rolling_totals/p95`。
- Schema 对齐：`api_config.endpoint/source` 记录凭证来源；`monitoring_enabled` 与 `status` 统一口径；`rolling_totals` 容量默认 12（≈60 分钟）。


# statusline

## Ref: "https://docs.anthropic.com/en/docs/claude-code/statusline"
## How statusline Works
- The status line is updated when the conversation messages update
- Updates run at most every 300ms
- The first line of stdout from your command becomes the status line text
- ANSI color codes are supported for styling your status line
- Claude Code passes contextual information about the current session (model, directories, etc.) as JSON to your script via stdin
- statusLine from my shell PS1 configuration

## How to config statusline
- `.claude/settings.json`
```
{
  "statusLine": {
    "type": "command",
    "command": "~/.claude/statusline.sh", // Your script or binary. 
    "padding": 0 // Optional: set to 0 to let status line go to edge
  }
}
```

## StdIN Input JSON Structure example
```
{
  "session_id": "772eaf12-e929-4d87-abdb-f3ad9669c4d0",
  "transcript_path": "/Users/ouzy/.claude/projects/-Users-ouzy-Documents-DevProjects-CCstatus/772eaf12-e929-4d87-abdb-f3ad9669c4d0.jsonl",
  "cwd": "/Users/ouzy/Documents/DevProjects/CCstatus",
  "model": {
    "id": "claude-sonnet-4-20250514",
    "display_name": "Sonnet 4"
  },
  "workspace": {
    "current_dir": "/Users/ouzy/Documents/DevProjects/CCstatus",
    "project_dir": "/Users/ouzy/Documents/DevProjects/CCstatus"
  },
  "version": "1.0.88",
  "output_style": {
    "name": "default"
  },
  "cost": {
    "total_cost_usd": 0.0009232000000000001,
    "total_duration_ms": 54146,
    "total_api_duration_ms": 2024,
    "total_lines_added": 0,
    "total_lines_removed": 0
  },
  "exceeds_200k_tokens": false
}

```

## Jsonl transcript ERROR JSON example
```
{
"parentUuid": "d4b75640-9df9-4caf-98b9-d8591b1f9983",
"isSidechain": false,
"userType": "external",
"cwd": "/Users/ouzy/Documents/DevProjects/CCstatus",
"sessionId": "ae3a3af0-40d7-47e8-915b-d22b65710147",
"version": "1.0.86",
"gitBranch": "feature/network-monitoring",
"type": "assistant",
"uuid": "8bd1ad3f-1a5e-42d9-a89f-5f3be3b58128",
"timestamp": "2025-08-21T15:17:29.521Z",
"message": {
  "id": "d31d058a-0d24-4c88-b760-b028e560e904",
  "model": "<synthetic>",
  "role": "assistant",
  "stop_reason": "stop_sequence",
  "stop_sequence": "",
  "type": "message",
  "usage": {
    "input_tokens": 0,
    "output_tokens": 0,
    "cache_creation_input_tokens": 0,
    "cache_read_input_tokens": 0,
    "server_tool_use": {
      "web_search_requests": 0
    },
    "service_tier": null
  },
  "content": [
    {
      "type": "text",
      "text": "API Error: 529 {\"type\":\"error\",\"error\":{\"type\":\"overloaded_error\",\"message\":\"Overloaded\"},\"request_id\":null}"
    }
  ]
},
"isApiErrorMessage": true
}
```