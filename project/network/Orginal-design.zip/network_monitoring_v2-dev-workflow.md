# Network Monitoring v2 - Development Workflow

## Reference Documentation
- [Implementation Plan (Revised)](network_monitoring_v2_impl_plan-revised.md)
- [network_monitoring_v2-Requirement-GPT5.md](network_monitoring_v2-Requirement-GPT5.md.md)

## Branch Strategy
**All development MUST be on `feature/network-monitoring` branch**

### Initial Setup
```bash
git checkout -b feature/network-monitoring
```

## Development Phases

### Phase 0: Branch Setup & Preparation
**Task**: Set up development branch and verify environment
```bash
git checkout -b feature/network-monitoring
cargo check
cargo test --package ccstatus --test network
```
**Commit**: `feat(network): initialize network monitoring feature branch`

---

### Phase 1: Core Module Structure
**Objective**: Establish module foundation and exports

#### Task 1.1: Create mod.rs
- **File**: `src/core/segments/network/mod.rs`
- **Actions**:
  - Export existing credential module
  - Add placeholder exports for future modules
  - Define public API surface
- **Validation**: `cargo check`
- **Commit**: `feat(network): add module orchestrator with exports`

#### Task 1.2: Implement NetworkSegment skeleton
- **File**: `src/core/segments/network/segment.rs`
- **Actions**:
  - Create NetworkSegment struct
  - Implement Segment trait
  - Add basic collect() method returning mock data
  - Add new_sync() constructor
- **Validation**: `cargo build`
- **Commit**: `feat(network): implement NetworkSegment with Segment trait`

---

### Phase 2: Data Types and Structures
**Objective**: Define core data structures

#### Task 2.1: Create types module
- **File**: `src/core/segments/network/types.rs`
- **Actions**:
  - Define NetworkStatus enum (Healthy, Degraded, Error, Unknown)
  - Create MonitoringState struct
  - Add NetworkMetrics struct
  - Define JsonlError struct
  - Re-export credential types (don't move)
- **Validation**: `cargo check`
- **Commit**: `feat(network): add core data types and structures`

---

### Phase 3: Monitoring Components
**Objective**: Implement monitoring functionality

#### Task 3.1: HTTP Monitor
- **File**: `src/core/segments/network/http_monitor.rs`
- **Actions**:
  - Create HttpMonitor struct
  - Implement probe() method with GREEN/RED modes
  - Add timeout policies (adaptive for GREEN, fixed for RED)
  - Integrate credential injection
  - Add timing breakdown (DNS|TCP|TLS|TTFB|Total)
- **Test**: `tests/network/http_monitor_tests.rs`
- **Validation**: Unit tests pass
- **Commit**: `feat(network): implement HTTP monitoring with adaptive timeouts`

#### Task 3.2: JSONL Monitor
- **File**: `src/core/segments/network/jsonl_monitor.rs`
- **Actions**:
  - Create JsonlMonitor struct
  - Implement scan_tail() method
  - Add error detection for `isApiErrorMessage:true`
  - Extract error metadata (code, message, timestamp)
- **Test**: `tests/network/jsonl_monitor_tests.rs`
- **Validation**: Unit tests pass
- **Commit**: `feat(network): add transcript error detection via JSONL monitor`

#### Task 3.3: Error Tracker
- **File**: `src/core/segments/network/error_tracker.rs`
- **Actions**:
  - Create ErrorTracker struct
  - Add HTTP status classification
  - Implement error history tracking
  - Add helper methods for RED window decisions
- **Test**: `tests/network/error_tracker_tests.rs`
- **Validation**: Unit tests pass
- **Commit**: `feat(network): implement error tracking and classification`

---

### Phase 4: State Management
**Objective**: Implement persistent state handling

#### Task 4.1: State Manager
- **File**: `src/core/segments/network/state_manager.rs`
- **Actions**:
  - Create StateManager struct
  - Implement atomic write to `~/.claude/ccstatus/ccstatus-monitoring.json`
  - Add single-writer discipline enforcement
  - Implement state schema (status, api_config, metrics, rolling_totals, p95)
  - Add file locking mechanism
- **Test**: `tests/network/state_manager_tests.rs`
- **Validation**: Atomic write tests pass
- **Commit**: `feat(network): add persistent state management with atomic writes`

---

### Phase 5: Rendering and UI
**Objective**: Implement status visualization

#### Task 5.1: Status Renderer
- **File**: `src/core/segments/network/status_renderer.rs`
- **Actions**:
  - Create StatusRenderer struct
  - Map NetworkStatus to emojis (🟢🟡🔴⚪)
  - Implement P80/P95 threshold logic
  - Format display text with metrics
  - Handle unknown states
- **Test**: `tests/network/status_renderer_tests.rs`
- **Validation**: Rendering tests pass
- **Commit**: `feat(network): implement status rendering with emoji indicators`

#### Task 5.2: Debug Logger
- **File**: `src/core/segments/network/debug_logger.rs`
- **Actions**:
  - Create DebugLogger struct
  - Add async logging methods
  - Implement CCSTATUS_DEBUG env var check
  - Add structured logging per component
  - Ensure no secret logging
- **Test**: `tests/network/debug_logger_tests.rs`
- **Validation**: Logger tests pass
- **Commit**: `feat(network): add debug logging utilities`

---

### Phase 6: Integration
**Objective**: Wire components together

#### Task 6.1: Complete NetworkSegment implementation
- **File**: `src/core/segments/network/segment.rs`
- **Actions**:
  - Wire credential resolution
  - Integrate JsonlMonitor for error detection
  - Add frequency window calculations
  - Connect HttpMonitor for probing
  - Integrate StateManager for persistence
  - Add StatusRenderer for output
- **Test**: `tests/network/segment_tests.rs`
- **Validation**: Integration tests pass
- **Commit**: `feat(network): complete NetworkSegment with all components integrated`

#### Task 6.2: Update module exports
- **File**: `src/core/segments/network/mod.rs`
- **Actions**:
  - Export all implemented modules
  - Ensure public API completeness
- **Validation**: `cargo build`
- **Commit**: `feat(network): finalize module exports`

---

### Phase 7: Testing and Validation
**Objective**: Comprehensive testing

#### Task 7.1: Unit Tests
- **Files**: All `tests/network/*_tests.rs`
- **Coverage**:
  - Credential resolution (env, shell, config)
  - HTTP monitoring with mocked responses
  - JSONL parsing edge cases
  - State persistence atomicity
  - Frequency window calculations
  - P95 computation scenarios
  - Error classification
- **Validation**: `cargo test --package ccstatus --test network`
- **Commit**: `test(network): add comprehensive unit tests`

#### Task 7.2: Integration Tests
- **File**: `tests/network/integration_tests.rs`
- **Actions**:
  - End-to-end stdin → render flow
  - Mock transcript with errors
  - Verify state persistence
  - Test frequency windows
- **Validation**: All tests green
- **Commit**: `test(network): add end-to-end integration tests`

---

### Phase 8: Final Integration
**Objective**: Connect to main statusline

#### Task 8.1: Update statusline.rs
- **File**: `src/core/statusline.rs`
- **Actions**:
  - Verify NetworkSegment integration
  - Test with real stdin data
  - Validate rendering output
- **Validation**: Manual testing with ccstatus binary
- **Commit**: `feat(network): integrate with main statusline`

---

## Validation Checklist

### Pre-merge Requirements
- [x] All unit tests passing
- [x] Integration tests passing
- [x] Manual testing with real API calls
- [x] State file correctly written to `~/.claude/ccstatus/`
- [x] Credential resolution verified (env, shell, config)
- [x] Frequency windows working (GREEN: 300s/3s, RED: 10s/1s)
- [x] P95 calculation accurate
- [x] Status emojis rendering correctly
- [x] Debug logging functional with CCSTATUS_DEBUG
- [x] No credential leaks in logs
- [x] Atomic writes verified
- [x] Error handling comprehensive

### Performance Verification
- [x] Stdin processing < 50ms
- [x] State write < 10ms
- [x] HTTP timeout respects limits
- [x] Memory usage stable
- [x] No goroutine/thread leaks

---

## Environment Setup

### Required Environment Variables (for testing)
Use CredentialManager to load env vairs with
```bash
export CCSTATUS_DEBUG=true
export CCSTATUS_TIMEOUT_MS=3000
```

### Test Commands
```bash
# Build and check
cargo build --release
cargo check

# Run all network tests
cargo test --package ccstatus --test network

# Run specific test
cargo test --package ccstatus --test network::http_monitor_tests

# Manual testing
./target/release/ccstatus
```

---

## Commit Message Format
```
feat(network): <description>
test(network): <description>
fix(network): <description>
docs(network): <description>
refactor(network): <description>
```

---

## Rollback Strategy
If issues arise:
1. `git checkout main`
2. `git branch -D feature/network-monitoring`
3. Start fresh from Phase 0

---

## Success Criteria
- All phases completed with commits
- Tests achieve >85% coverage
- Manual testing confirms all features work
- No regressions in existing functionality
- Performance meets requirements
- Documentation updated

---

## Notes
- Each task should be committed immediately upon completion
- Run tests after each phase
- Keep debug logging active during development
- Validate state file format after each write
- Monitor memory usage during long-running tests