# 🧹 Network Monitoring System Cleanup Preview Report

**Generated**: 2025-08-21  
**Scope**: Network Monitoring System (`src/core/segments/network/`)  
**Mode**: Preview (--safe --type imports --type dead-code)

## 📊 Analysis Summary

Found **18 warnings** across network monitoring components with opportunities for safe cleanup:
- **2 unused imports** 
- **3 unused variables**
- **13 dead code instances** (unused methods, fields, and associated items)

## 🔍 Detailed Cleanup Opportunities

### 🚫 Unused Imports (Safe to Remove)

1. **`src/core/segments/network/jsonl_monitor.rs:9`**
   ```rust
   use chrono::{DateTime, Utc, Local}; // Remove: Local
   ```
   **Fix**: `use chrono::{DateTime, Utc};`

2. **`src/core/segments/network/debug_logger.rs:8`**
   ```rust
   use tokio::fs; // Remove: unused import
   ```

### 🔧 Unused Variables (Safe to Remove)

3. **`src/core/segments/network/http_monitor.rs:32`**
   ```rust
   pub fn new(config: NetworkConfig) -> Self // unused variable: config
   ```

4. **`src/core/segments/network/jsonl_monitor.rs:220`**
   ```rust
   // unused variable: line_num
   ```

5. **`src/core/segments/network/jsonl_monitor.rs:317`**
   ```rust
   // unused variable: file_path
   ```

### 💀 Dead Code - Unused Methods (Review Needed)

6. **`src/core/segments/network/shell_config_reader.rs:372`**
   - `get_shell_type()` and `get_checked_paths()` - **Candidate for removal**
   - *Analysis*: Public API methods that may be intended for future use

7. **`src/core/segments/network/http_monitor.rs:255`**
   - `get_average_latency()`, `get_error_summary()`, `clear_old_errors()` - **Candidate for removal**
   - *Analysis*: Statistics methods not currently integrated into UI

8. **`src/core/segments/network/latency_tracker.rs:35`**
   - `get_average_latency()`, `get_latest_latency()`, `get_percentile_latency()`, `get_sample_count()`, `clear()` - **Consider removal**
   - *Analysis*: Comprehensive latency API that's not being utilized

9. **`src/core/segments/network/state_machine.rs:145`**
   - Multiple unused methods - **Review state machine API**

10. **`src/core/segments/network/error_tracker.rs:62`**
    - Multiple unused methods - **Review error tracking API**

11. **`src/core/segments/network/status_renderer.rs:21`**
    - Multiple unused associated items - **Review rendering API**

12. **`src/core/segments/network/status_file_writer.rs:31`**
    - Multiple unused associated items - **Review file writing API**

13. **`src/core/segments/network/debug_logger.rs:35`**
    - `is_enabled()`, `write_to_file()`, `log_init_timeout()`, `get_log_summary()` - **Keep (Debug Tools)**
    - *Analysis*: Debug utilities that should be preserved for troubleshooting

### 🏗️ Dead Code - Unused Fields (Structural Issues)

14. **`src/core/segments/network/jsonl_monitor.rs:94`**
    - Unused fields: `entry_type`, `uuid`

15. **`src/core/segments/network/jsonl_monitor.rs:111`**
    - Unused fields: `id`, `model`, `usage`, `role`

16. **`src/core/segments/network/jsonl_monitor.rs:121`**
    - Unused fields: `input_tokens`, `output_tokens`

17. **`src/core/segments/network/segment.rs:47`**
    - Unused field: `config` - **Consider removal or activation**

### ⚠️ **Code Quality Issues**

18. **`src/core/segments/network/debug_logger.rs:260`**
    - Creating shared reference to mutable static - **Safety concern**

## 🎯 Safe Cleanup Recommendations

### ✅ **Immediate Safe Actions** (Preview Mode)

1. **Remove unused imports** (2 instances)
   - Low risk, immediate build improvement
   - No functional impact

2. **Remove unused variables** (3 instances)
   - Eliminates compiler warnings
   - Clean code practice

### ⚠️ **Review Needed Before Removal**

3. **Public API methods** 
   - Shell config reader methods may be intended for external use
   - Latency tracker methods could be valuable for future monitoring dashboards
   - State machine, error tracker APIs may be part of planned features

4. **Debug logging methods**
   - Keep all debug utilities despite unused status
   - Critical for troubleshooting production issues

### 🔄 **Structural Improvements**

5. **JSONL monitor data structures**
   - Consider simplifying structs if fields truly unused
   - May indicate feature incompleteness or over-engineering

6. **Mutable static safety**
   - Review debug logger global instance for thread safety

## 📋 Cleanup Priority Matrix

| Priority | Action | Risk Level | Impact | Files Affected |
|----------|--------|------------|--------|----------------|
| 🟢 High | Remove unused imports | Very Low | Cleaner builds | 2 |
| 🟢 High | Remove unused variables | Very Low | Warning elimination | 3 |
| 🟡 Medium | Review public methods | Medium | API completeness | 6+ |
| 🟡 Medium | Simplify data structures | Medium | Architecture | 4 |
| 🔵 Low | Review mutable static | High | Thread safety | 1 |
| 🟤 Keep | Debug utilities | N/A | Troubleshooting | - |

## 🚨 **Preview Mode - No Changes Applied**

All analysis complete. No files were modified. 

## 📝 **Recommended Action Plan**

### Phase 1: Safe Cleanup (Immediate)
```bash
# Apply safe fixes automatically
cargo fix --lib -p ccstatus
```

### Phase 2: Manual Review (Requires Decision)
1. Review each unused public method for future roadmap alignment
2. Decide on JSONL monitor field necessity based on feature requirements
3. Address mutable static safety in debug logger

### Phase 3: Architectural Review (Optional)
1. Consider if unused methods represent incomplete features
2. Evaluate if simplified APIs would improve maintainability

## 📈 **Expected Benefits**

- **Build Performance**: Faster compilation with fewer warnings
- **Code Quality**: Cleaner, more maintainable codebase
- **Developer Experience**: Reduced warning noise during development
- **Binary Size**: Potential reduction from dead code elimination

---

**Safe to proceed with**: Import cleanup (2 files) + Variable cleanup (3 locations)  
**Requires review**: Public method removal (13+ methods across 6+ files)

**Command to apply safe fixes**: `cargo fix --lib -p ccstatus`