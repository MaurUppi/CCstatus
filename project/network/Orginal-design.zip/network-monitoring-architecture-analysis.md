# Overview

This document provides a comprehensive architectural analysis of CCstatus's network monitoring system, examining component structure, data flows, state management, and design patterns.

## High-Level Architecture

The network monitoring system follows a facade pattern with clear separation of concerns:

- **NetworkSegment**: Public interface implementing the Segment trait
- **MonitoringEngine**: Internal asynchronous worker handling the core monitoring logic
- **Shared State**: Thread-safe status sharing via `Arc<RwLock<NetworkStatus>>`

## Core Components

### 1. NetworkSegment (Public Interface)

```rust
pub struct NetworkSegment {
    current_status: Arc<RwLock<NetworkStatus>>,
    status_renderer: StatusRenderer,
    config: NetworkConfig,
    _monitoring_handle: Option<tokio::task::JoinHandle<()>>,
}

```

**Responsibilities:**

- Implements the public Segment trait
- Manages the monitoring task lifecycle
- Provides status access to the UI layer

### 2. MonitoringEngine (Core Worker)

```rust
struct MonitoringEngine {
    credential_manager: CredentialManager,
    http_monitor: HttpMonitor,
    state_machine: StateMachine,
    status_writer: StatusFileWriter,
    jsonl_monitor: Option<JsonlMonitor>,
    current_status: Arc<RwLock<NetworkStatus>>,
    config: NetworkConfig,
}

```

**Responsibilities:**

- Orchestrates the monitoring workflow
- Manages credential retrieval and validation
- Executes the main monitoring loop
- Coordinates between all monitoring components

## Authentication Layer

### CredentialManager

```rust
pub struct CredentialManager {
    claude_config_paths: Vec<PathBuf>,
}

```

**Credential Sources (Priority Order):**

1. Environment variables (`ANTHROPIC_BASE_URL`, `ANTHROPIC_AUTH_TOKEN`)
2. Shell configuration exports (`.zshrc`, `.bashrc`)
3. Claude configuration files

**Key Features:**

- Multi-source credential resolution
- Graceful fallback between sources
- Startup validation with specific error reporting

## HTTP Monitoring Layer

### HttpMonitor

```rust
pub struct HttpMonitor {
    client: HttpClient,
    latency_tracker: LatencyTracker,
    error_tracker: ErrorTracker,
    health_check_payload: String,
}

```

**Integrated Tracking:**

- **LatencyTracker**: Maintains sliding window of recent latency samples
- **ErrorTracker**: Categorizes and tracks error patterns
- **Health Check Payload**: Standardized API request for consistency

## State Management System

### State Machine Architecture

```rust
pub struct StateMachine {
    current_state: Arc<RwLock<MonitoringState>>,
}

```

### Monitoring States

### 1. Healthy State

- **Initial Interval**: 30 seconds
- **Extended Interval**: 5 minutes (after 10 consecutive successes)
- **Transition**: Success → Healthy, Failure/RateLimit → Degraded

### 2. Degraded State

- **Interval**: 5 seconds (fast recovery detection)
- **Transition**: Success → Healthy, Extended failure → Failed
- **Timeout**: Transitions to Failed after 50+ seconds

### 3. Failed State

- **Interval**: 60 seconds (reduced load during prolonged failures)
- **Transition**: Success → Degraded (gradual recovery)
- **Persistence**: Maintains failure count and timestamp

### State Events

```rust
pub enum StateEvent {
    Success,     // HTTP 200 with valid response
    RateLimit,   // HTTP 429 or rate limiting
    Failure,     // Network errors, timeouts, invalid responses
}

```

## Status System

### NetworkStatus Enum

```rust
pub enum NetworkStatus {
    Healthy,
    Degraded { reason: String, details: String },
    Error { error_type: String, details: String },
    Unknown,
    Disabled,
}

```

**Status Determination Logic:**

- **Healthy**: Successful HTTP requests with acceptable latency
- **Degraded**: Rate limiting or intermittent failures
- **Error**: Persistent failures, credential issues, or network errors
- **Unknown**: Initial state or indeterminate conditions
- **Disabled**: User-configured disabled state

## Output Layer

### StatusRenderer

```rust
pub struct StatusRenderer {
    show_details: bool,
}

```

- Formats status for statusline display
- Configurable detail level
- Theme-aware rendering

### StatusFileWriter

```rust
pub struct StatusFileWriter {
    status_file_path: PathBuf,
}

```

- Writes JSON status data for shell integration
- Atomic file operations
- Error-tolerant (fails silently)

### JsonlMonitor (Optional)

```rust
pub struct JsonlMonitor {
    config: JsonlMonitorConfig,
    last_checked_files: HashMap<PathBuf, DateTime<Utc>>,
}

```

- Parallel JSONL log monitoring
- Real-time error capture
- Independent of main monitoring loop

## Data Flow Architecture

### Startup Sequence

1. **NetworkSegment Creation**: Initialize shared state and configuration
2. **MonitoringEngine Spawn**: Create async monitoring task
3. **Credential Retrieval**: Attempt multi-source credential resolution
4. **Validation**: Test credentials with initial health check
5. **Loop Initialization**: Start main monitoring loop

### Main Monitoring Loop

```
┌─────────────────┐
│   Get Interval  │ ←──────────────────┐
│  (StateMachine) │                    │
└─────────┬───────┘                    │
          │                            │
          ▼                            │
┌─────────────────┐                    │
│  Health Check   │                    │
│  (HttpMonitor)  │                    │
└─────────┬───────┘                    │
          │                            │
          ▼                            │
┌─────────────────┐                    │
│ State Transition│                    │
│ (StateMachine)  │                    │
└─────────┬───────┘                    │
          │                            │
          ▼                            │
┌─────────────────┐                    │
│  Update Status  │                    │
│ (Shared State)  │                    │
└─────────┬───────┘                    │
          │                            │
          ▼                            │
┌─────────────────┐                    │
│   Write Status  │                    │
│ (StatusWriter)  │                    │
└─────────┬───────┘                    │
          │                            │
          ▼                            │
┌─────────────────┐                    │
│     Sleep       │ ───────────────────┘
│   (Interval)    │
└─────────────────┘

```

### Parallel Operations

- **JSONL Monitoring**: Runs independently, monitors log files for errors
- **Status Reading**: UI components read shared status asynchronously
- **File Writing**: Non-blocking status file updates

## Design Patterns

### 1. Facade Pattern

- **NetworkSegment** provides simplified interface
- **MonitoringEngine** handles complex internal logic
- Clear separation between public API and implementation

### 2. State Machine Pattern

- **Adaptive behavior** based on success/failure patterns
- **Interval optimization** for efficiency and responsiveness
- **Graceful degradation** during service issues

### 3. Observer Pattern

- **Shared state** enables multiple consumers
- **Event-driven** status updates
- **Decoupled** components through shared data structures

### 4. Strategy Pattern

- **Multiple credential sources** with fallback logic
- **Configurable monitoring** behavior
- **Pluggable components** (optional JSONL monitoring)

## Error Handling Strategy

### Credential Errors

- **Immediate termination** of monitoring on credential failure
- **Specific error types** for different failure modes
- **User-friendly messages** with resolution guidance

### Network Errors

- **State-based retry logic** with adaptive intervals
- **Error categorization** for appropriate responses
- **Graceful degradation** during service outages

### File System Errors

- **Non-blocking** status file writes
- **Silent failure** for file operations
- **Continued monitoring** despite I/O issues

## Performance Characteristics

### Memory Management

- **Bounded collections** for latency and error samples
- **Efficient state sharing** via Arc/RwLock
- **Minimal allocation** in hot paths

### Network Efficiency

- **Adaptive intervals** reduce unnecessary requests
- **Connection reuse** via HTTP client pooling
- **Timeout management** prevents resource leaks

### Concurrency Model

- **Async/await** for non-blocking operations
- **Shared state** with reader-writer locks
- **Independent tasks** for parallel monitoring

## Configuration

### NetworkConfig

- Health check endpoints and payloads
- Timeout and interval settings
- Feature flags (JSONL monitoring, debug logging)
- Credential source priorities

### Adaptive Behavior

- **Dynamic intervals** based on health status
- **Configurable thresholds** for state transitions
- **User preferences** for detail levels and display options

## Integration Points

### Shell Integration

- **Status file output** for shell prompt integration
- **JSON format** for machine readability
- **Atomic updates** to prevent partial reads

### UI Integration

- **Shared status** via Arc<RwLock<NetworkStatus>>
- **Renderer abstraction** for different display contexts
- **Real-time updates** without polling

### Logging Integration

- **Structured logging** with context
- **Debug modes** for troubleshooting
- **Performance metrics** collection

## Architecture Diagrams

The following diagrams provide different perspectives on the network monitoring architecture:

### 1. Component Architecture (Internal Structure)

**Purpose**: Shows internal component relationships within the system boundary

- Focuses on component responsibilities and dependencies
- Highlights the facade pattern (NetworkSegment → MonitoringEngine)
- No external systems shown - purely internal design view

```mermaid
graph TB
    subgraph "Network Monitoring System"
        NS[NetworkSegment<br/>Public Interface]
        ME[MonitoringEngine<br/>Core Worker]

        CM[CredentialManager<br/>Authentication]
        HM[HttpMonitor<br/>HTTP + Metrics]
        SM[StateMachine<br/>Adaptive Intervals]
        SW[StatusWriter<br/>File Output]
        SR[StatusRenderer<br/>Display]
    end

    NS --> ME
    NS --> SR
    ME --> CM
    ME --> HM
    ME --> SM
    ME --> SW

    classDef interface fill:#e1f5fe
    classDef core fill:#f3e5f5
    classDef support fill:#f1f8e9

    class NS interface
    class ME core
    class CM,HM,SM,SW,SR support

```

### 2. System Architecture (External Context)

**Purpose**: Shows the complete system including external dependencies

- Includes external systems (Claude API, File System, Shell Environment, JSONL Log Files)
- Provides the "big picture" view of how CCstatus fits into its environment
- Shows system boundaries and external integrations
- Focuses on what the system interacts with

```mermaid
flowchart TB
    subgraph subGraph0["External Systems"]
        P["Claude API"]
        Q["File System"]
        R["Shell Environment"]
        S["JSONL Log Files"]
    end

    A["CCstatus Core"] --> B["Network Segment"]
    B --> C["Monitoring Engine"]
    B --> D["Status Renderer"]

    C --> E["Credential Manager"]
    C --> F["HTTP Monitor"]
    C --> G["State Machine"]
    C --> H["Status File Writer"]
    C --> I["JsonlMonitor (Optional)"]

    E --> J["Shell Config Reader"]
    E --> R
    E --> P

    F --> K["Latency Tracker"]
    F --> L["Error Tracker"]
    F --> P

    G --> C
    H --> Q
    I --> S
    I --> C

    D --> Q
    D --> R

    %% External connections
    J --> R

    classDef core fill:#e1f5fe
    classDef segment fill:#f3e5f5
    classDef monitoring fill:#e8f5e8
    classDef support fill:#fff3e0
    classDef external fill:#ffebee

    class A core
    class B segment
    class C,F,G monitoring
    class D,E,H,I,J,K,L support
    class P,Q,R,S external

```

### 3. Data Flow (Process Sequence)

**Purpose**: Shows the step-by-step monitoring process flow

- Illustrates the main monitoring loop from startup to continuous operation
- Highlights decision points (credential validation)
- Shows the cyclical nature of health checking
- Useful for understanding operational behavior and debugging

```mermaid
flowchart TD
    Start([Start Monitoring])
    --> GetCreds[Get Credentials<br/>CredentialManager]

    GetCreds --> CredsOK{Credentials<br/>Found?}
    CredsOK -->|No| Error([Set Error Status<br/>& Exit])
    CredsOK -->|Yes| HealthCheck[Perform Health Check<br/>HttpMonitor]

    HealthCheck --> UpdateState[Update State Machine<br/>StateMachine]
    UpdateState --> SetStatus[Set Shared Status<br/>NetworkStatus]
    SetStatus --> WriteFile[Write Status File<br/>StatusWriter]
    WriteFile --> GetInterval[Get Next Interval<br/>StateMachine]
    GetInterval --> Sleep[Sleep Until<br/>Next Check]
    Sleep --> HealthCheck

    classDef process fill:#e8f5e8
    classDef decision fill:#fff3e0
    classDef endpoint fill:#ffebee

    class GetCreds,HealthCheck,UpdateState,SetStatus,WriteFile,GetInterval,Sleep process
    class CredsOK decision
    class Start,Error endpoint

```

### 4. State Machine (Adaptive Behavior)

**Purpose**: Shows the intelligent state transitions and adaptive intervals

- Illustrates how the system adapts monitoring frequency based on health
- Shows recovery paths (Failed → Degraded → Healthy)
- Highlights the smart interval management (30s → 5min, 5s recovery, 60s failed)
- Critical for understanding the system's self-optimizing behavior

```mermaid
stateDiagram-v2
    [*] --> Healthy : Initial State

    Healthy --> Healthy : Success<br/>(30s → 5min after 10 successes)
    Healthy --> Degraded : Failure or RateLimit<br/>(5s interval)

    Degraded --> Healthy : Success<br/>(30s interval)
    Degraded --> Degraded : RateLimit<br/>(5s interval)
    Degraded --> Failed : Failure for >50s<br/>(60s interval)

    Failed --> Degraded : Success<br/>(5s interval)
    Failed --> Failed : Failure or RateLimit<br/>(60s interval)

    note right of Healthy
        Adaptive intervals:
        • 30s initially
        • 5min after 10 successes
    end note

    note right of Degraded
        Fast recovery detection:
        • 5s intervals
        • Timeout to Failed after 50s
    end note

    note right of Failed
        Reduced load:
        • 60s intervals
        • Gradual recovery via Degraded
    end note

```

### 5. Runtime Architecture (Concurrency Model)

**Purpose**: Shows how the system operates across threads and async tasks

- Illustrates the separation between UI thread and background monitoring
- Shows shared state management with Arc<RwLock> for thread safety
- Highlights parallel operations (main monitoring + optional JSONL monitoring)
- Essential for understanding concurrency, performance, and thread safety

```mermaid
graph TB
    subgraph "Main Thread"
        UI[UI Components<br/>Read Status]
        NS[NetworkSegment<br/>Interface]
    end

    subgraph "Async Tasks"
        ME[MonitoringEngine<br/>Main Loop]
        JM[JsonlMonitor<br/>Log Monitoring]
    end

    subgraph "Shared State"
        Status[(Arc&lt;RwLock&lt;<br/>NetworkStatus&gt;&gt;)]
        StateData[(Arc&lt;RwLock&lt;<br/>MonitoringState&gt;&gt;)]
    end

    subgraph "File System"
        StatusFile[Status JSON File]
        LogFiles[JSONL Log Files]
    end

    UI -.->|Read| Status
    NS --> ME
    NS -.->|Read| Status

    ME -.->|Write| Status
    ME -.->|Read/Write| StateData
    ME -->|Write| StatusFile

    JM -->|Read| LogFiles
    JM -.->|Write| Status

    classDef thread fill:#e1f5fe
    classDef async fill:#f3e5f5
    classDef shared fill:#fff3e0
    classDef file fill:#f1f8e9

    class UI,NS thread
    class ME,JM async
    class Status,StateData shared
    class StatusFile,LogFiles file

```

## Conclusion

The CCstatus network monitoring system demonstrates a well-architected, resilient design with:

- **Clear separation of concerns** across multiple layers
- **Adaptive behavior** that responds intelligently to service conditions
- **Robust error handling** with graceful degradation
- **Efficient resource usage** through smart interval management
- **Comprehensive monitoring** with multiple data collection points
- **Flexible integration** supporting both UI and shell environments

The architecture successfully balances responsiveness, efficiency, and reliability while maintaining clean code organization and extensibility for future enhancements.