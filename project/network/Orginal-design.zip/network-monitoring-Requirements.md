# CCstatus - Claude Code Network Monitor Requirements Document

**Version**: 1.0  
**Date**: 2025-08-19  
**Project**: CCstatus (Fork of CCometixLine)  
**Author**: MaurUppi  

## Executive Summary

CCstatus is a Claude Code network monitoring tool that provides real-time connectivity status with visual indicators in terminal prompts. The project transforms CCometixLine into a specialized monitoring solution that tracks Claude API connectivity, measures network performance, and provides actionable diagnostics for developers using Claude Code.

### Research 
- [Monitor-research](./Monitor-research.md)

### Key Objectives
- Monitor Claude API connectivity in real-time with minimal resource usage
- Provide context-aware status indicators in terminal prompts
- Support both official Anthropic API and proxy services
- Deliver actionable diagnostic information when issues occur
- Maintain zero regression with existing CCometixLine functionality

## Functional Requirements

### FR-001: Universal API Health Monitoring
**Priority**: Critical  
**Description**: Monitor Claude API endpoint health using lightweight POST requests

**Specifications**:
- Use POST method to `{base_url}/v1/messages` with minimal payload
- Payload: `{"model":"claude-3-haiku-20240307","max_tokens":1,"messages":[{"role":"user","content":"ping"}]}`
- Support both official Anthropic API and third-party proxy services
- Detect all error types: 401, 403, 429, 500, 502, 504, connection failures

### FR-002: Adaptive Monitoring Frequency
**Priority**: High  
**Description**: Dynamically adjust monitoring frequency based on service health

**Specifications**:
- **Initial State**: 30-second intervals
- **Healthy State**: Switch to 5-minute intervals after 10 consecutive successes
- **Degraded State**: Switch to 5-second intervals when errors detected
- **Failed State**: Switch to 1-minute intervals after 10 consecutive failures
- **State Transitions**: Automatic based on response patterns

### FR-003: Smart Visual Status Display
**Priority**: High  
**Description**: Context-sensitive status indicators in terminal prompts

**Healthy Display**:
```bash
🟢  # Simple green light, no additional information
```

**Error Display**:
```bash
🔴 DNS:timeout|TCP:-|TLS:-|TTFB:-|Total:5000ms
🟡 DNS:reuse|TCP:reuse|TLS:reuse|TTFB:890ms|Total:890ms
🔴 DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms [401 Unauthorized]
```

### FR-004: Multi-Phase Latency Measurement  
**Priority**: Medium  
**Description**: Detailed network performance breakdown for diagnostic purposes

**Specifications**:
- **DNS Resolution**: Time to resolve hostname
- **TCP Connection**: Time to establish TCP connection
- **TLS Handshake**: Time to complete TLS negotiation
- **Time to First Byte (TTFB)**: Server processing time
- **Total Time**: End-to-end measured duration (not sum of parts)
- **Connection Reuse**: Display "reuse" instead of "0ms" for cached connections
- **Format**: `DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms`

### FR-005: Secure Credential Management
**Priority**: Critical  
**Description**: Read credentials from user's existing configuration without storing sensitive data

**Credential Sources** (Priority Order):
1. **Environment Variables**:
   - `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN`

2. **Shell Credentials**
   - 
   -
   
3. **Claude Code Configuration Files**:
   - `~/.claude/settings.json` (user settings)
   - `.claude/settings.local.json` (project personal)
   - `.claude/settings.json` (project shared)

**Security Constraints**:
- CCstatus NEVER stores credentials in its own configuration files
- All credential access is read-only
- No credential logging or caching

### FR-006: Minimal Error Tracking
**Priority**: Medium  
**Description**: Track error patterns without extensive logging

**Specifications**:
- Store first and last occurrence of each error type
- Error types: "API_401", "API_403", "API_429", "NETWORK_TIMEOUT", "SERVER_502", etc.
- Data structure: `HashMap<String, (DateTime, DateTime)>` for (first_time, last_time)
- Clear error log on successful recovery after 24 hours
- Write final status when ccstatus exits with Claude Code

## Non-Functional Requirements

### NFR-001: Performance
- **Response Time**: Status check completion under 50ms
- **Memory Usage**: Maximum 10MB RAM consumption
- **CPU Overhead**: Minimal impact during background monitoring
- **Battery Impact**: Considerate intervals to preserve laptop battery life

### NFR-002: Reliability
- **Uptime**: >99% availability for background monitoring process
- **Error Handling**: Graceful degradation when network unavailable
- **Process Recovery**: Automatic restart on unexpected failures
- **Network Changes**: Resilient to VPN connects/disconnects, WiFi switching

### NFR-003: Compatibility
- **Operating Systems**: macOS, Linux, Windows (including WSL)
- **Shell Support**: bash, zsh, PowerShell, with extensibility for others
- **Claude Code Versions**: Compatible with current and future Claude Code releases
- **API Endpoints**: Support official Anthropic API and third-party proxies

### NFR-004: Security
- **Credential Safety**: Zero risk of credential exposure or logging
- **Network Privacy**: No data collection or external reporting
- **Process Security**: Run with minimal required permissions
- **Audit Trail**: Transparent operations with optional debug logging

### NFR-005: Maintainability
- **Code Quality**: Clean, documented, testable Rust code
- **Architecture**: Modular design following existing CCometixLine patterns
- **Configuration**: Simple, self-documenting configuration format
- **Updates**: Easy deployment of updates without breaking existing setups

## Technical Specifications

### Network Monitoring Architecture
```rust
// Core monitoring component
pub struct NetworkSegment {
    config: NetworkConfig,
    client: HttpClient,
    state: MonitoringState,
    error_tracker: ErrorTracker,
    latency_tracker: LatencyTracker,
}

enum MonitoringState {
    Healthy { interval: Duration, successes: u32 },
    Degraded { interval: Duration },
    Failed { interval: Duration, failures: u32 },
}

struct ErrorTracker {
    errors: HashMap<String, (DateTime<Utc>, DateTime<Utc>)>,
}
```

### HTTP Client Configuration
```rust
use isahc::{HttpClient, Request, Body};
use isahc::config::{Configurable, RedirectPolicy};

let client = HttpClient::builder()
    .redirect_policy(RedirectPolicy::Follow)
    .timeout(Duration::from_secs(30))
    .connect_timeout(Duration::from_secs(10))
    .build()?;
```

### Status File Format
```json
{
  "status": "healthy|degraded|error|disabled",
  "monitoring_enabled": true,
  "api_config": {
    "endpoint": "https://api.anthropic.com/v1/messages",
    "source": "ANTHROPIC_BASE_URL"
  },
  "network": {
    "latency_ms": 156,
    "breakdown": "DNS:12ms|TCP:28ms|TLS:45ms|TTFB:71ms|Total:156ms",
    "last_error_code": null,
    "error_type": null
  },
  "monitoring_state": {
    "current": "healthy",
    "interval_seconds": 30,
    "consecutive_successes": 3,
    "consecutive_failures": 0
  },
  "timestamp": "2025-08-19T14:30:00Z"
}
```

## System Architecture

### Component Structure
```
src/core/segments/
├── battery.rs        # Existing - unchanged
├── git.rs           # Existing - unchanged  
├── network.rs       # NEW - CCstatus network monitoring
└── ...              # Other existing segments
```

### Network Segment Integration
```rust
// In src/core/segments/network.rs
pub struct NetworkSegment {
    // Implementation details
}

impl Segment for NetworkSegment {
    fn new(config: &Config) -> Result<Self> {
        // Initialize or fail silently
        NetworkSegment::initialize()
            .map_err(|_| /* Fail silent - no segment display */)
    }
    
    fn render(&self) -> String {
        match self.get_current_status() {
            Status::Healthy => "🟢".to_string(),
            Status::Degraded(details) => format!("🟡 {}", details),
            Status::Error(details) => format!("🔴 {}", details),
            Status::Unknown => "⚪".to_string(),
            Status::Disabled => String::new(), // Show nothing
        }
    }
}
```

### File System Layout
```
~/.claude/ccstatus/
├── ccstatus-monitoring.json     # Main status file (no credentials)
├── cache/                       # Session monitoring cache
└── logs/                        # Minimal error logs (optional)
```

## User Interface Requirements

### Visual Status Indicators
- **🟢 Healthy**: 200 OK response, latency < 500ms
- **🟡 Degraded**: 429 rate limit OR latency > 500ms
- **🔴 Error**: 4xx/5xx errors OR connection failures
- **⚪ Unknown**: No configuration found
- **⚫ Disabled**: Monitoring explicitly disabled (show nothing)

### Shell Integration
```bash
# Shell function integration
claude_status() {
  local status_file="$HOME/.claude/ccstatus/ccstatus-monitoring.json"
  
  if [[ ! -f "$status_file" ]]; then
    echo ""  # No display if not configured
    return
  fi
  
  # Parse and display appropriate status
  local status=$(jq -r '.status' "$status_file" 2>/dev/null)
  local breakdown=$(jq -r '.network.breakdown' "$status_file" 2>/dev/null)
  
  case $status in
    "healthy") echo "🟢" ;;
    "degraded") echo "🟡 $breakdown" ;;
    "error") echo "🔴 $breakdown" ;;
    *) echo "" ;;
  esac
}

# Usage in prompt
PS1="$(claude_status) $PS1"
```

## Integration Requirements

### Claude Code Integration
- **Zero Regression**: No modifications to existing CCometixLine functionality
- **Additive Architecture**: Network segment is purely additional
- **Configuration Compatibility**: Respect existing configuration patterns
- **Process Lifecycle**: Start/stop with Claude Code session

### Cross-Platform Shell Integration
- **macOS/Linux**: bash (`~/.bash_profile`), zsh (`~/.zshrc`)
- **Windows**: PowerShell (`$PROFILE`)
- **WSL**: Linux shell patterns within Windows environment
- **Installation**: Automated script to add shell integration

### Environment Variable Support
- **Standard Variables**: `ANTHROPIC_BASE_URL`, `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_API_KEY`
- **Platform Detection**: Automatic detection of available environment variables
- **Fallback Strategy**: Graceful fallback through configuration hierarchy

## Data Requirements

### Status Data Structure
```rust
#[derive(Serialize, Deserialize)]
pub struct StatusData {
    pub status: StatusType,
    pub monitoring_enabled: bool,
    pub api_config: ApiConfig,
    pub network: NetworkMetrics,
    pub monitoring_state: MonitoringState,
    pub timestamp: DateTime<Utc>,
}

#[derive(Serialize, Deserialize)]
pub enum StatusType {
    Healthy,
    Degraded,
    Error,
    Disabled,
}
```

### Error Tracking Data
```rust
#[derive(Serialize, Deserialize)]
pub struct ErrorLog {
    pub first_occurrence: DateTime<Utc>,
    pub last_occurrence: DateTime<Utc>,
    pub error_type: String,
    pub error_code: Option<u16>,
    pub count: u32,
}
```

### Configuration Data
```rust
#[derive(Serialize, Deserialize)]
pub struct NetworkConfig {
    pub enabled: bool,
    pub api_endpoint: Option<String>,
    pub auth_token: Option<String>,
    pub check_interval: Duration,
    pub timeout: Duration,
}
```

## Implementation Constraints

### Scope Boundaries
- **In Scope**: Core network monitoring, status display, shell integration
- **Out of Scope**: Auto-updates, installation improvements, extensive logging
- **Existing Features**: NO modifications to existing CCometixLine functionality

### Dependencies
```toml
# Additional dependencies for network monitoring
[dependencies]
isahc = { version = "1.7", features = ["json", "timing"] }
notify = "6.0"
tokio = { version = "1.0", features = ["full"] }

# Existing dependencies (unchanged)
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
clap = { version = "4.0", features = ["derive"] }
```

### Error Handling Strategy
- **Network Failures**: Graceful degradation, no crash
- **Configuration Errors**: Fail silent, disable monitoring
- **API Errors**: Track and display, continue monitoring
- **Initialization Failures**: Show nothing, no error indicators

## Success Criteria

### Primary Success Metrics
1. **Functionality**: Successfully monitor Claude API connectivity for both official and proxy endpoints
2. **Performance**: Status checks complete under 50ms, memory usage under 10MB
3. **Reliability**: >99% uptime, graceful handling of network changes
4. **User Experience**: Clear status indicators, actionable error information
5. **Security**: Zero credential exposure, no sensitive data storage

### User Acceptance Criteria
1. **Installation**: Simple setup with automated shell integration
2. **Usage**: Immediate visual feedback in terminal prompt
3. **Diagnostics**: Clear indication of connectivity issues with actionable information
4. **Compatibility**: Works across all supported platforms and shells
5. **Performance**: No noticeable impact on terminal or system performance

### Technical Validation
1. **Code Quality**: Clean, maintainable Rust code following project conventions
2. **Testing**: Comprehensive unit and integration tests
3. **Documentation**: Clear installation and usage instructions
4. **Packaging**: Easy distribution and installation process
5. **Monitoring**: Effective detection of various error scenarios and network conditions

## Implementation Timeline

### Phase 1: Core Monitoring (Week 1)
- [ ] Implement lightweight POST health check method
- [ ] Create adaptive frequency algorithm
- [ ] Build secure credential reading system
- [ ] Basic status file management

### Phase 2: Enhanced Metrics (Week 2)
- [ ] Multi-phase latency measurement and breakdown
- [ ] Connection reuse detection
- [ ] Smart visual display modes
- [ ] Error categorization and tracking

### Phase 3: Integration (Week 3)  
- [ ] Network segment integration in CCometixLine architecture
- [ ] Cross-platform shell integration scripts
- [ ] Status file format and management
- [ ] Testing across platforms

### Phase 4: Polish (Week 4)
- [ ] Performance optimization
- [ ] Comprehensive error handling
- [ ] Documentation and examples
- [ ] Final validation and testing

---

*This requirements document serves as the definitive specification for CCstatus development. All implementation decisions should align with these requirements, and any changes should be documented through formal change requests.*